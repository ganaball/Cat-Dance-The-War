const screens = [...document.querySelectorAll('[data-screen]')];
const settingsModal = document.querySelector('#settings-modal');
const warningModal = document.querySelector('#warning-modal');
const offlineReportModal = document.querySelector('#offline-report-modal');
const farmModal = document.querySelector('#farm-modal');
const hatcherModal = document.querySelector('#hatcher-modal');
const hatchMountainModal = document.querySelector('#hatch-mountain-modal');
const buildingMessageModal = document.querySelector('#building-message-modal');
const felineStocksModal = document.querySelector('#feline-stocks-modal');
const felineStockSlots = document.querySelector('#feline-stock-slots');
const felineStockPicker = document.querySelector('#feline-stock-picker');
const cubeMixerModal = document.querySelector('#cube-mixer-modal');
const mixerRowOne = document.querySelector('#mixer-row-one');
const mixerRowTwo = document.querySelector('#mixer-row-two');
const mixerSelectedOne = document.querySelector('#mixer-selected-one');
const mixerSelectedTwo = document.querySelector('#mixer-selected-two');
const catalogueModal = document.querySelector('#catalogue-modal');
const hatchTransition = document.querySelector('#hatch-transition');
const languageModal = document.querySelector('#language-modal');
const musicToggle = document.querySelector('[data-setting="music"]');
const soundToggle = document.querySelector('[data-setting="sounds"]');
const soundNote = document.querySelector('#sound-note');
const mapGrid = document.querySelector('.map-grid');
const catPanel = document.querySelector('#cat-panel');
// Keep the cat details dialog outside the mountain screen's stacking context so
// catalogue details can appear above the catalogue overlay.
document.body.append(catPanel);
const shopPanel = document.querySelector('#shop-panel');
const buyCatButton = document.querySelector('#buy-cat-button');
const languageOptions = document.querySelector('#language-options');
const preferences = {
  music: localStorage.getItem('catdance-music') !== 'off',
  sounds: localStorage.getItem('catdance-sounds') !== 'off'
};
const languages = [
  { code: 'en', name: 'English' }, { code: 'es', name: 'Español' },
  { code: 'pt', name: 'Português' }, { code: 'it', name: 'Italiano' },
  { code: 'de', name: 'Deutsch' }, { code: 'nl', name: 'Nederlands' },
  { code: 'sv', name: 'Svenska' }, { code: 'ru', name: 'Русский' },
  { code: 'zh', name: '中文 (普通话)' }, { code: 'ja', name: '日本語' },
  { code: 'ko', name: '한국어' }, { code: 'ms', name: 'Bahasa Melayu' },
  { code: 'hi', name: 'हिन्दी' }
];
const translations = {
  en: {
    play:'Play', settings:'Settings', music:'Music', game_sounds:'Game sounds', translate_game:'Translate game', choose_language:'Choose a language', level:'Level', simple:'Simple', cat_element:'Cat', earth:'Earth', move:'Move', feed_level:'Feed + level up', food:'food', sell:'Sell', silver:'silver', gold:'gold', rubies:'rubies', mountains:'Mountains', buy_mountain:'Buy a new mountain', coming_soon:'Coming soon', coming_card:'Coming<br>soon', coming_text:'There is a new feature coming to Cat Dance: The War! Please be patient!', okay:'Okay!', arid_mountain:'Arid Mountain', back_home:'Back to main menu', back_regions:'Back to regions', back_mountains:'Back to mountains', shop:'Shop', mountain_shop:'MOUNTAIN SHOP', choose_cat:'Choose a cat', shop_cat_blurb:'Strong, sweethearted, and at home in the mountains.', buy_cat:'Buy for {price} silver', silver_production:'Silver production', production_format:'1 silver every {seconds} seconds', not_enough_food:'Not enough food', not_enough_silver:'Not enough silver', already_yours:'This Rocky Cat is already yours', cat_joined:'Rocky Cat joined your island', sold_for:'Rocky Cat sold for 100 silver', choose_tile:'Choose an open tile', level_reached:'{cat name} reached level {level}', no_space:'No open space left on this island', rocky_cat:'Rocky Cat', cat_description:"This cat is very hard on the outside, but he is a sweethearted kitten inside. He loves eating and playing with his owner and is very strong. Don't annoy him thought, if you don't want scratches and rock marks all over your body!", tile_occupied:'That tile already has a cat'
  },
  es: {
    play:'Jugar', settings:'Ajustes', music:'Música', game_sounds:'Sonidos del juego', translate_game:'Traducir el juego', choose_language:'Elige un idioma', level:'Nivel', simple:'Simple', cat_element:'Gato', earth:'Tierra', move:'Mover', feed_level:'Alimentar y subir nivel', food:'comida', sell:'Vender', silver:'plata', gold:'oro', rubies:'rubíes', mountains:'Montañas', buy_mountain:'Compra una montaña nueva', coming_soon:'Próximamente', coming_card:'Próximamente', coming_text:'¡Una nueva función llegará a Cat Dance: The War! ¡Ten paciencia!', okay:'¡Vale!', arid_mountain:'Montaña Árida', back_home:'Volver al menú principal', back_regions:'Volver a las regiones', back_mountains:'Volver a las montañas', shop:'Tienda', mountain_shop:'TIENDA DE MONTAÑA', choose_cat:'Elige un gato', shop_cat_blurb:'Fuerte, cariñoso y feliz en las montañas.', buy_cat:'Comprar por {price} de plata', silver_production:'Producción de plata', production_format:'1 plata cada {seconds} segundos', not_enough_food:'No tienes suficiente comida', not_enough_silver:'No tienes suficiente plata', already_yours:'Este Gato Rocoso ya es tuyo', cat_joined:'El Gato Rocoso se unió a tu isla', sold_for:'Gato Rocoso vendido por 100 de plata', choose_tile:'Elige una casilla libre', level_reached:'Gato Rocoso alcanzó el nivel {level}', no_space:'No queda espacio libre en esta isla', rocky_cat:'Gato rocoso', cat_description:'Este gato es muy duro por fuera, pero por dentro es un gatito de gran corazón. Le encanta comer y jugar con su dueño, y es muy fuerte. ¡No lo molestes si no quieres arañazos y marcas de roca por todo el cuerpo!'
  },
  pt: {
    play:'Jogar', settings:'Configurações', music:'Música', game_sounds:'Sons do jogo', translate_game:'Traduzir o jogo', choose_language:'Escolha um idioma', level:'Nível', simple:'Simples', cat_element:'Gato', earth:'Terra', move:'Mover', feed_level:'Alimentar e subir de nível', food:'comida', sell:'Vender', silver:'prata', gold:'ouro', rubies:'rubis', mountains:'Montanhas', buy_mountain:'Compre uma nova montanha', coming_soon:'Em breve', coming_card:'Em breve', coming_text:'Uma novidade está chegando a Cat Dance: The War! Aguarde!', okay:'Tudo bem!', arid_mountain:'Montanha Árida', back_home:'Voltar ao menu principal', back_regions:'Voltar às regiões', back_mountains:'Voltar às montanhas', shop:'Loja', mountain_shop:'LOJA DA MONTANHA', choose_cat:'Escolha um gato', shop_cat_blurb:'Forte, carinhoso e feliz nas montanhas.', buy_cat:'Comprar por {price} de prata', silver_production:'Produção de prata', production_format:'1 prata a cada {seconds} segundos', not_enough_food:'Comida insuficiente', not_enough_silver:'Prata insuficiente', already_yours:'Este gato já é seu', cat_joined:'Gato de Pedra chegou à sua ilha', sold_for:'Gato de Pedra vendido por 100 de prata', choose_tile:'Escolha um espaço livre', level_reached:'Gato de Pedra chegou ao nível {level}', no_space:'Não há mais espaço livre nesta ilha', rocky_cat:'Gato de Pedra', cat_description:'Este gato é muito duro por fora, mas por dentro é um filhote de bom coração. Ele adora comer e brincar com seu dono e é muito forte. Não o irrite se não quiser arranhões e marcas de pedra pelo corpo!'
  },
  it: {
    play:'Gioca', settings:'Impostazioni', music:'Musica', game_sounds:'Suoni di gioco', translate_game:'Traduci il gioco', choose_language:'Scegli una lingua', level:'Livello', simple:'Semplice', cat_element:'Gatto', earth:'Terra', move:'Sposta', feed_level:'Nutri e sali di livello', food:'cibo', sell:'Vendi', silver:'argento', gold:'oro', rubies:'rubini', mountains:'Montagne', buy_mountain:'Compra una nuova montagna', coming_soon:'Prossimamente', coming_card:'Prossimamente', coming_text:'Una nuova funzione arriverà su Cat Dance: The War! Abbi pazienza!', okay:'Va bene!', arid_mountain:'Montagna Arida', back_home:'Torna al menu principale', back_regions:'Torna alle regioni', back_mountains:'Torna alle montagne', shop:'Negozio', mountain_shop:'NEGOZIO DI MONTAGNA', choose_cat:'Scegli un gatto', shop_cat_blurb:'Forte, affettuoso e a suo agio in montagna.', buy_cat:'Compra per {price} argento', silver_production:'Produzione d’argento', production_format:'1 argento ogni {seconds} secondi', not_enough_food:'Cibo insufficiente', not_enough_silver:'Argento insufficiente', already_yours:'Questo gatto è già tuo', cat_joined:'Il gatto si è unito alla tua isola', sold_for:'Gatto venduto per 100 argento', choose_tile:'Scegli una casella libera', level_reached:'Il gatto ha raggiunto il livello {level}', no_space:'Non c’è più spazio libero sull’isola', rocky_cat:'Gatto di roccia', cat_description:'Questo gatto è molto duro fuori, ma dentro è un gattino dal cuore tenero. Ama mangiare e giocare con il suo padrone ed è molto forte. Non farlo arrabbiare se non vuoi graffi e segni di roccia sul corpo!'
  },
  de: {
    play:'Spielen', settings:'Einstellungen', music:'Musik', game_sounds:'Spielgeräusche', translate_game:'Spiel übersetzen', choose_language:'Sprache auswählen', level:'Level', simple:'Einfach', cat_element:'Katze', earth:'Erde', move:'Bewegen', feed_level:'Füttern & aufleveln', food:'Futter', sell:'Verkaufen', silver:'Silber', gold:'Gold', rubies:'Rubine', mountains:'Berge', buy_mountain:'Einen neuen Berg kaufen', coming_soon:'Demnächst', coming_card:'Demnächst', coming_text:'Eine neue Funktion kommt zu Cat Dance: The War! Bitte hab Geduld!', okay:'Okay!', arid_mountain:'Arider Berg', back_home:'Zurück zum Hauptmenü', back_regions:'Zurück zu den Regionen', back_mountains:'Zurück zu den Bergen', shop:'Laden', mountain_shop:'BERGLADEN', choose_cat:'Katze auswählen', shop_cat_blurb:'Stark, liebevoll und in den Bergen zu Hause.', buy_cat:'Für {price} Silber kaufen', silver_production:'Silberproduktion', production_format:'1 Silber alle {seconds} Sekunden', not_enough_food:'Nicht genug Futter', not_enough_silver:'Nicht genug Silber', already_yours:'Diese Katze gehört dir bereits', cat_joined:'Die Katze ist deiner Insel beigetreten', sold_for:'Katze für 100 Silber verkauft', choose_tile:'Wähle ein freies Feld', level_reached:'Die Katze hat Level {level} erreicht', no_space:'Auf dieser Insel ist kein Platz mehr', rocky_cat:'Felskatze', cat_description:'Diese Katze ist außen sehr hart, aber innen ein Kätzchen mit einem großen Herzen. Sie frisst und spielt gern mit ihrem Besitzer und ist sehr stark. Ärger sie nicht, wenn du keine Kratzer und Felsabdrücke am ganzen Körper willst!'
  },
  nl: {
    play:'Spelen', settings:'Instellingen', music:'Muziek', game_sounds:'Spelgeluiden', translate_game:'Spel vertalen', choose_language:'Kies een taal', level:'Level', simple:'Eenvoudig', cat_element:'Kat', earth:'Aarde', move:'Verplaatsen', feed_level:'Voeren en levelen', food:'voer', sell:'Verkopen', silver:'zilver', gold:'goud', rubies:'robijnen', mountains:'Bergen', buy_mountain:'Koop een nieuwe berg', coming_soon:'Binnenkort', coming_card:'Binnenkort', coming_text:'Er komt een nieuwe functie naar Cat Dance: The War! Even geduld!', okay:'Oké!', arid_mountain:'Dorre Berg', back_home:'Terug naar hoofdmenu', back_regions:'Terug naar regio’s', back_mountains:'Terug naar bergen', shop:'Winkel', mountain_shop:'BERGWINKEL', choose_cat:'Kies een kat', shop_cat_blurb:'Sterk, lief en helemaal thuis in de bergen.', buy_cat:'Kopen voor {price} zilver', silver_production:'Zilverproductie', production_format:'1 zilver elke {seconds} seconden', not_enough_food:'Niet genoeg voer', not_enough_silver:'Niet genoeg zilver', already_yours:'Deze kat is al van jou', cat_joined:'De kat is op je eiland aangekomen', sold_for:'Kat verkocht voor 100 zilver', choose_tile:'Kies een vrij vakje', level_reached:'De kat heeft level {level} bereikt', no_space:'Geen vrije plek meer op dit eiland', rocky_cat:'Rotskat', cat_description:'Deze kat is vanbuiten erg hard, maar vanbinnen een kitten met een lief hart. Hij eet en speelt graag met zijn baasje en is heel sterk. Maak hem niet boos als je geen krassen en rotsplekken op je lichaam wilt!'
  },
  sv: {
    play:'Spela', settings:'Inställningar', music:'Musik', game_sounds:'Spelljud', translate_game:'Översätt spelet', choose_language:'Välj språk', level:'Nivå', simple:'Vanlig', cat_element:'Katt', earth:'Jord', move:'Flytta', feed_level:'Mata och gå upp en nivå', food:'mat', sell:'Sälj', silver:'silver', gold:'guld', rubies:'rubiner', mountains:'Berg', buy_mountain:'Köp ett nytt berg', coming_soon:'Kommer snart', coming_card:'Kommer snart', coming_text:'En ny funktion kommer till Cat Dance: The War! Ha tålamod!', okay:'Okej!', arid_mountain:'Torra berget', back_home:'Tillbaka till huvudmenyn', back_regions:'Tillbaka till regionerna', back_mountains:'Tillbaka till bergen', shop:'Butik', mountain_shop:'BERGBUTIK', choose_cat:'Välj en katt', shop_cat_blurb:'Stark, hjärtegod och hemma i bergen.', buy_cat:'Köp för {price} silver', silver_production:'Silverproduktion', production_format:'1 silver var {seconds}:e sekund', not_enough_food:'Inte tillräckligt med mat', not_enough_silver:'Inte tillräckligt med silver', already_yours:'Den här katten är redan din', cat_joined:'Katten har flyttat till din ö', sold_for:'Katt såld för 100 silver', choose_tile:'Välj en ledig ruta', level_reached:'Katten nådde nivå {level}', no_space:'Det finns ingen ledig plats kvar på ön', rocky_cat:'Stenkatt', cat_description:'Den här katten är hård på utsidan men en godhjärtad kattunge inuti. Den älskar att äta och leka med sin ägare och är mycket stark. Retas inte med den om du inte vill få rivsår och stenmärken över hela kroppen!'
  },
  ru: {
    play:'Играть', settings:'Настройки', music:'Музыка', game_sounds:'Звуки игры', translate_game:'Перевести игру', choose_language:'Выберите язык', level:'Уровень', simple:'Обычный', cat_element:'Кот', earth:'Земля', move:'Переместить', feed_level:'Покормить и повысить уровень', food:'еда', sell:'Продать', silver:'серебро', gold:'золото', rubies:'рубина', mountains:'Горы', buy_mountain:'Купить новую гору', coming_soon:'Скоро', coming_card:'Скоро', coming_text:'В Cat Dance: The War скоро появится новая функция! Потерпите немного!', okay:'Хорошо!', arid_mountain:'Засушливая гора', back_home:'В главное меню', back_regions:'К регионам', back_mountains:'Назад к горам', shop:'Магазин', mountain_shop:'ГОРНЫЙ МАГАЗИН', choose_cat:'Выберите кота', shop_cat_blurb:'Сильный, добросердечный и любит горы.', buy_cat:'Купить за {price} серебра', silver_production:'Добыча серебра', production_format:'1 серебро каждые {seconds} сек.', not_enough_food:'Недостаточно еды', not_enough_silver:'Недостаточно серебра', already_yours:'Этот кот уже ваш', cat_joined:'Кот поселился на вашем острове', sold_for:'Кот продан за 100 серебра', choose_tile:'Выберите свободную клетку', level_reached:'Кот достиг {level}-го уровня', no_space:'На острове больше нет свободного места', rocky_cat:'Каменный кот', cat_description:'Снаружи этот кот очень твёрдый, но внутри он добрый котёнок. Он любит есть и играть с хозяином и очень силён. Не дразните его, если не хотите царапин и каменных следов по всему телу!'
  },
  zh: {
    play:'开始游戏', settings:'设置', music:'音乐', game_sounds:'游戏音效', translate_game:'翻译游戏', choose_language:'选择语言', level:'等级', simple:'普通', cat_element:'猫', earth:'大地', move:'移动', feed_level:'喂食并升级', food:'食物', sell:'出售', silver:'银币', gold:'金币', rubies:'红宝石', mountains:'山脉', buy_mountain:'购买新山脉', coming_soon:'即将推出', coming_card:'即将推出', coming_text:'《Cat Dance: The War》即将推出新功能！敬请期待！', okay:'好的！', arid_mountain:'旱山', back_home:'返回主菜单', back_regions:'返回地区', back_mountains:'返回山脉', shop:'商店', mountain_shop:'山地商店', choose_cat:'选择一只猫', shop_cat_blurb:'强壮又贴心，最喜欢待在山里。', buy_cat:'花费 {price} 银币购买', silver_production:'银币产出', production_format:'每 {seconds} 秒产出 1 银币', not_enough_food:'食物不足', not_enough_silver:'银币不足', already_yours:'这只猫已经属于你了', cat_joined:'猫咪加入了你的岛屿', sold_for:'猫咪已售出，获得 100 银币', choose_tile:'选择一个空地块', level_reached:'猫咪升到了 {level} 级', no_space:'岛上没有空位了', rocky_cat:'岩石猫', cat_description:'这只猫外表坚硬，内心却是一只温柔的小猫。它喜欢吃东西，也喜欢和主人玩耍，而且非常强壮。别惹它生气，否则你身上会满是抓痕和石头印！'
  },
  ja: {
    play:'プレイ', settings:'設定', music:'音楽', game_sounds:'ゲーム音', translate_game:'ゲームを翻訳', choose_language:'言語を選択', level:'レベル', simple:'ノーマル', cat_element:'ネコ', earth:'大地', move:'移動', feed_level:'エサをあげてレベルアップ', food:'エサ', sell:'売る', silver:'銀', gold:'金', rubies:'ルビー', mountains:'山', buy_mountain:'新しい山を購入', coming_soon:'近日公開', coming_card:'近日公開', coming_text:'Cat Dance: The War に新機能が登場予定です。お楽しみに！', okay:'OK！', arid_mountain:'乾燥した山', back_home:'メインメニューに戻る', back_regions:'地域に戻る', back_mountains:'山に戻る', shop:'ショップ', mountain_shop:'マウンテンショップ', choose_cat:'ネコを選ぶ', shop_cat_blurb:'強くて優しい、山が大好きなネコ。', buy_cat:'銀 {price} で購入', silver_production:'銀の生産', production_format:'{seconds}秒ごとに銀1枚', not_enough_food:'エサが足りません', not_enough_silver:'銀が足りません', already_yours:'このネコはすでに仲間です', cat_joined:'ネコが島にやってきました', sold_for:'ネコを銀100で売りました', choose_tile:'空いているマスを選んでください', level_reached:'ネコがレベル{level}になりました', no_space:'島に空きスペースがありません', rocky_cat:'岩ネコ', cat_description:'外側はとても硬いけれど、内側は心優しい子猫です。食べることと飼い主と遊ぶことが大好きで、とても力持ちです。ひっかき傷や岩の跡だらけになりたくなければ、怒らせないでね！'
  },
  ko: {
    play:'플레이', settings:'설정', music:'음악', game_sounds:'게임 사운드', translate_game:'게임 번역', choose_language:'언어 선택', level:'레벨', simple:'일반', cat_element:'고양이', earth:'대지', move:'이동', feed_level:'먹이 주고 레벨 업', food:'먹이', sell:'판매', silver:'실버', gold:'골드', rubies:'루비', mountains:'산', buy_mountain:'새로운 산 구매', coming_soon:'출시 예정', coming_card:'출시 예정', coming_text:'Cat Dance: The War에 새로운 기능이 곧 추가됩니다! 조금만 기다려 주세요!', okay:'확인!', arid_mountain:'건조한 산', back_home:'메인 메뉴로 돌아가기', back_regions:'지역으로 돌아가기', back_mountains:'산으로 돌아가기', shop:'상점', mountain_shop:'산악 상점', choose_cat:'고양이 선택', shop_cat_blurb:'강하고 다정하며 산을 좋아해요.', buy_cat:'실버 {price}개로 구매', silver_production:'실버 생산', production_format:'{seconds}초마다 실버 1개', not_enough_food:'먹이가 부족해요', not_enough_silver:'실버가 부족해요', already_yours:'이미 보유한 고양이예요', cat_joined:'고양이가 섬에 합류했어요', sold_for:'고양이를 실버 100개에 판매했어요', choose_tile:'빈 타일을 선택하세요', level_reached:'고양이가 레벨 {level}에 도달했어요', no_space:'섬에 빈 공간이 없어요', rocky_cat:'바위 고양이', cat_description:'겉은 아주 단단하지만 속은 다정한 아기 고양이예요. 먹는 것과 주인과 노는 것을 좋아하고 아주 힘이 세요. 긁힌 자국과 바위 자국을 원하지 않는다면 화나게 하지 마세요!'
  },
  ms: {
    play:'Main', settings:'Tetapan', music:'Muzik', game_sounds:'Bunyi permainan', translate_game:'Terjemah permainan', choose_language:'Pilih bahasa', level:'Tahap', simple:'Biasa', cat_element:'Kucing', earth:'Bumi', move:'Pindah', feed_level:'Beri makan & naik tahap', food:'makanan', sell:'Jual', silver:'perak', gold:'emas', rubies:'delima', mountains:'Pergunungan', buy_mountain:'Beli gunung baharu', coming_soon:'Akan datang', coming_card:'Akan datang', coming_text:'Ciri baharu akan tiba di Cat Dance: The War! Harap bersabar!', okay:'Baik!', arid_mountain:'Gunung Gersang', back_home:'Kembali ke menu utama', back_regions:'Kembali ke wilayah', back_mountains:'Kembali ke gunung', shop:'Kedai', mountain_shop:'KEDAI GUNUNG', choose_cat:'Pilih kucing', shop_cat_blurb:'Kuat, penyayang dan suka tinggal di gunung.', buy_cat:'Beli dengan {price} perak', silver_production:'Penghasilan perak', production_format:'1 perak setiap {seconds} saat', not_enough_food:'Makanan tidak mencukupi', not_enough_silver:'Perak tidak mencukupi', already_yours:'Kucing ini sudah menjadi milik anda', cat_joined:'Kucing menyertai pulau anda', sold_for:'Kucing dijual dengan harga 100 perak', choose_tile:'Pilih petak kosong', level_reached:'Kucing mencapai tahap {level}', no_space:'Tiada ruang kosong lagi di pulau ini', rocky_cat:'Kucing Batu', cat_description:'Kucing ini sangat keras di luar, tetapi berhati lembut di dalam. Ia suka makan dan bermain dengan pemiliknya serta sangat kuat. Jangan ganggunya jika tidak mahu calar dan kesan batu pada seluruh badan!'
  },
  hi: {
    play:'खेलें', settings:'सेटिंग्स', music:'संगीत', game_sounds:'गेम की आवाज़ें', translate_game:'गेम का अनुवाद करें', choose_language:'भाषा चुनें', level:'स्तर', simple:'साधारण', cat_element:'बिल्ली', earth:'पृथ्वी', move:'चलाएँ', feed_level:'खिलाएँ और स्तर बढ़ाएँ', food:'खाना', sell:'बेचें', silver:'चाँदी', gold:'सोना', rubies:'माणिक', mountains:'पहाड़', buy_mountain:'नया पर्वत खरीदें', coming_soon:'जल्द आ रहा है', coming_card:'जल्द आ रहा है', coming_text:'Cat Dance: The War में एक नया फीचर जल्द आ रहा है! कृपया इंतज़ार करें!', okay:'ठीक है!', arid_mountain:'शुष्क पर्वत', back_home:'मुख्य मेन्यू पर लौटें', back_regions:'क्षेत्रों पर लौटें', back_mountains:'पहाड़ों पर लौटें', shop:'दुकान', mountain_shop:'पहाड़ी दुकान', choose_cat:'एक बिल्ली चुनें', shop_cat_blurb:'मज़बूत, प्यारी और पहाड़ों में खुश रहती है।', buy_cat:'{price} चाँदी में खरीदें', silver_production:'चाँदी का उत्पादन', production_format:'हर {seconds} सेकंड में 1 चाँदी', not_enough_food:'खाना पर्याप्त नहीं है', not_enough_silver:'चाँदी पर्याप्त नहीं है', already_yours:'यह बिल्ली पहले से आपकी है', cat_joined:'बिल्ली आपके द्वीप पर आ गई', sold_for:'बिल्ली 100 चाँदी में बेची गई', choose_tile:'खाली जगह चुनें', level_reached:'बिल्ली स्तर {level} पर पहुँच गई', no_space:'इस द्वीप पर खाली जगह नहीं बची', rocky_cat:'पत्थरीली बिल्ली', cat_description:'यह बिल्ली बाहर से बहुत कठोर है, लेकिन अंदर से प्यारे दिल वाली है। इसे खाना और अपने मालिक के साथ खेलना पसंद है और यह बहुत ताकतवर है। अगर शरीर पर खरोंच और पत्थर के निशान नहीं चाहते, तो इसे परेशान न करें!'
  }
};

const auxiliaryTranslations = {
  en: { music_on:'Music on', music_off:'Music off', sounds_on:'Game sounds on', sounds_off:'Game sounds off', tile_occupied:'That tile already has a cat', mountain_ground:'Mountain ground' },
  es: { music_on:'Música activada', music_off:'Música desactivada', sounds_on:'Sonidos activados', sounds_off:'Sonidos desactivados', tile_occupied:'Esa casilla ya tiene un gato', mountain_ground:'Terreno montañoso' },
  pt: { music_on:'Música ligada', music_off:'Música desligada', sounds_on:'Sons ligados', sounds_off:'Sons desligados', tile_occupied:'Esse espaço já tem um gato', mountain_ground:'Terreno da montanha' },
  it: { music_on:'Musica attiva', music_off:'Musica disattivata', sounds_on:'Suoni attivi', sounds_off:'Suoni disattivati', tile_occupied:'Quella casella è già occupata da un gatto', mountain_ground:'Terreno montano' },
  de: { music_on:'Musik an', music_off:'Musik aus', sounds_on:'Spielgeräusche an', sounds_off:'Spielgeräusche aus', tile_occupied:'Auf diesem Feld steht bereits eine Katze', mountain_ground:'Berggelände' },
  nl: { music_on:'Muziek aan', music_off:'Muziek uit', sounds_on:'Spelgeluiden aan', sounds_off:'Spelgeluiden uit', tile_occupied:'Op dat vakje staat al een kat', mountain_ground:'Bergterrein' },
  sv: { music_on:'Musik på', music_off:'Musik av', sounds_on:'Spelljud på', sounds_off:'Spelljud av', tile_occupied:'Rutan är redan upptagen av en katt', mountain_ground:'Bergsterräng' },
  ru: { music_on:'Музыка включена', music_off:'Музыка выключена', sounds_on:'Звуки включены', sounds_off:'Звуки выключены', tile_occupied:'Эта клетка уже занята котом', mountain_ground:'Горная местность' },
  zh: { music_on:'音乐已开启', music_off:'音乐已关闭', sounds_on:'游戏音效已开启', sounds_off:'游戏音效已关闭', tile_occupied:'这个地块上已经有一只猫', mountain_ground:'山地地面' },
  ja: { music_on:'音楽オン', music_off:'音楽オフ', sounds_on:'ゲーム音オン', sounds_off:'ゲーム音オフ', tile_occupied:'そのマスにはすでにネコがいます', mountain_ground:'山の地面' },
  ko: { music_on:'음악 켜짐', music_off:'음악 꺼짐', sounds_on:'게임 사운드 켜짐', sounds_off:'게임 사운드 꺼짐', tile_occupied:'해당 타일에는 이미 고양이가 있어요', mountain_ground:'산악 지형' },
  ms: { music_on:'Muzik dihidupkan', music_off:'Muzik dimatikan', sounds_on:'Bunyi permainan dihidupkan', sounds_off:'Bunyi permainan dimatikan', tile_occupied:'Petak itu sudah mempunyai kucing', mountain_ground:'Permukaan gunung' },
  hi: { music_on:'संगीत चालू', music_off:'संगीत बंद', sounds_on:'गेम की आवाज़ें चालू', sounds_off:'गेम की आवाज़ें बंद', tile_occupied:'उस जगह पर पहले से एक बिल्ली है', mountain_ground:'पहाड़ी भूमि' }
};

const smokireTranslations = {
  en: { fire:'Fire', burning_mountain:'Burning Mountain', smokire_blurb:'Very hot cat, temperamental but really cute. Despises cold ambients.', smokire_description:"If you love high temperatures, you'll love this cat. He is made purely of flames, basalt and magic! If you prefer the cold thought, Smokire may or may not burn you! You are safe if you don't tell him that.", gold_production:'Gold production', gold_production_format:'1 gold every {seconds} seconds', jump_and_scratch:'Jump and scratch', spontaneous_combustion:'Spontaneous combustion', magma_rocks:'Magma rocks', heavy_burns:'Heavy burns', damage_format:'{damage} damage', smokire_joined:'Smokire joined your mountain', sold_cat:'{cat} sold for {price} silver' },
  es: { fire:'Fuego', burning_mountain:'Montaña Ardiente', smokire_blurb:'Gato muy caluroso, temperamental pero muy lindo. Detesta los ambientes fríos.', smokire_description:'Si te encantan las altas temperaturas, te encantará este gato. ¡Está hecho únicamente de llamas, basalto y magia! Si prefieres el frío, puede que Smokire te queme o puede que no. Estás a salvo si no se lo dices.', gold_production:'Producción de oro', gold_production_format:'1 oro cada {seconds} segundos', jump_and_scratch:'Salto y arañazo', spontaneous_combustion:'Combustión espontánea', magma_rocks:'Rocas de magma', heavy_burns:'Quemaduras graves', damage_format:'{damage} de daño', smokire_joined:'Smokire llegó a tu montaña', sold_cat:'{cat} se vendió por {price} de plata' },
  pt: { fire:'Fogo', burning_mountain:'Montanha Ardente', smokire_blurb:'Gato muito quente, temperamental, mas muito fofo. Detesta ambientes frios.', smokire_description:'Se você adora altas temperaturas, vai adorar este gato. Ele é feito puramente de chamas, basalto e magia! Se prefere o frio, Smokire pode ou não queimar você. Você estará seguro se não contar isso a ele.', gold_production:'Produção de ouro', gold_production_format:'1 ouro a cada {seconds} segundos', jump_and_scratch:'Salto e arranhão', spontaneous_combustion:'Combustão espontânea', magma_rocks:'Rochas de magma', heavy_burns:'Queimaduras intensas', damage_format:'{damage} de dano', smokire_joined:'Smokire chegou à sua montanha', sold_cat:'{cat} vendido por {price} de prata' },
  it: { fire:'Fuoco', burning_mountain:'Montagna Ardente', smokire_blurb:'Un gatto molto caldo, irascibile ma davvero carino. Detesta gli ambienti freddi.', smokire_description:'Se ami le alte temperature, adorerai questo gatto. È fatto interamente di fiamme, basalto e magia! Se preferisci il freddo, Smokire potrebbe bruciarti oppure no. Sei al sicuro se non glielo dici.', gold_production:'Produzione d’oro', gold_production_format:'1 oro ogni {seconds} secondi', jump_and_scratch:'Salto e graffio', spontaneous_combustion:'Combustione spontanea', magma_rocks:'Rocce di magma', heavy_burns:'Ustioni gravi', damage_format:'{damage} danni', smokire_joined:'Smokire è arrivato sulla tua montagna', sold_cat:'{cat} venduto per {price} argento' },
  de: { fire:'Feuer', burning_mountain:'Brennender Berg', smokire_blurb:'Sehr heiße Katze, launisch, aber wirklich süß. Verabscheut kalte Umgebungen.', smokire_description:'Wenn du hohe Temperaturen liebst, wirst du diese Katze lieben. Sie besteht ganz aus Flammen, Basalt und Magie! Wenn du Kälte bevorzugst, verbrennt Smokire dich vielleicht, vielleicht auch nicht. Du bist sicher, solange du es ihm nicht erzählst.', gold_production:'Goldproduktion', gold_production_format:'1 Gold alle {seconds} Sekunden', jump_and_scratch:'Sprung und Kratzer', spontaneous_combustion:'Selbstentzündung', magma_rocks:'Magmafelsen', heavy_burns:'Schwere Verbrennungen', damage_format:'{damage} Schaden', smokire_joined:'Smokire ist auf deinem Berg angekommen', sold_cat:'{cat} für {price} Silber verkauft' },
  nl: { fire:'Vuur', burning_mountain:'Brandende Berg', smokire_blurb:'Een heel hete kat, temperamentvol maar erg schattig. Heeft een hekel aan koude omgevingen.', smokire_description:'Als je van hoge temperaturen houdt, zul je deze kat geweldig vinden. Hij bestaat volledig uit vlammen, basalt en magie! Als je liever kou hebt, verbrandt Smokire je misschien wel en misschien niet. Je bent veilig zolang je het hem niet vertelt.', gold_production:'Goudproductie', gold_production_format:'1 goud elke {seconds} seconden', jump_and_scratch:'Sprong en krab', spontaneous_combustion:'Zelfontbranding', magma_rocks:'Magmarotsen', heavy_burns:'Zware brandwonden', damage_format:'{damage} schade', smokire_joined:'Smokire is op je berg aangekomen', sold_cat:'{cat} verkocht voor {price} zilver' },
  sv: { fire:'Eld', burning_mountain:'Brinnande berget', smokire_blurb:'En mycket het katt, lynnig men väldigt söt. Avskyr kalla miljöer.', smokire_description:'Om du älskar höga temperaturer kommer du att älska den här katten. Den består helt av lågor, basalt och magi! Om du föredrar kyla kanske Smokire bränner dig, kanske inte. Du är säker så länge du inte berättar det för honom.', gold_production:'Guldproduktion', gold_production_format:'1 guld var {seconds}:e sekund', jump_and_scratch:'Hopp och riv', spontaneous_combustion:'Självantändning', magma_rocks:'Magmastenar', heavy_burns:'Svåra brännskador', damage_format:'{damage} skada', smokire_joined:'Smokire har flyttat in på ditt berg', sold_cat:'{cat} såldes för {price} silver' },
  ru: { fire:'Огонь', burning_mountain:'Пылающая гора', smokire_blurb:'Очень горячий кот: вспыльчивый, но очень милый. Терпеть не может холод.', smokire_description:'Если вы любите высокие температуры, вам понравится этот кот. Он целиком состоит из пламени, базальта и магии! Если вы предпочитаете холод, Smokire может обжечь вас, а может и нет. Вы в безопасности, если не расскажете ему об этом.', gold_production:'Добыча золота', gold_production_format:'1 золото каждые {seconds} секунд', jump_and_scratch:'Прыжок и царапина', spontaneous_combustion:'Самовозгорание', magma_rocks:'Магматические камни', heavy_burns:'Сильные ожоги', damage_format:'Урон: {damage}', smokire_joined:'Smokire поселился на вашей горе', sold_cat:'{cat} продан за {price} серебра' },
  zh: { fire:'火', burning_mountain:'燃烧之山', smokire_blurb:'非常炽热的猫，脾气不太好但真的很可爱。最讨厌寒冷的环境。', smokire_description:'如果你喜欢高温，一定会喜欢这只猫。它完全由火焰、玄武岩和魔法构成！如果你更喜欢寒冷，Smokire可能会烧到你，也可能不会。只要别告诉它，你就安全。', gold_production:'金币产出', gold_production_format:'每 {seconds} 秒产出 1 金币', jump_and_scratch:'跳跃抓挠', spontaneous_combustion:'自燃', magma_rocks:'岩浆石块', heavy_burns:'严重灼伤', damage_format:'造成 {damage} 点伤害', smokire_joined:'Smokire加入了你的山脉', sold_cat:'{cat}已售出，获得{price}银币' },
  ja: { fire:'火', burning_mountain:'燃える山', smokire_blurb:'とても熱い猫。気難しいけれど本当にかわいい。寒い環境が大嫌い。', smokire_description:'高温が好きなら、このネコをきっと気に入るでしょう。炎と玄武岩と魔法だけでできています！寒いほうが好きなら、Smokireに火傷させられるかもしれないし、されないかもしれません。本人に言わなければ安全です。', gold_production:'金の生産', gold_production_format:'{seconds}秒ごとに金1枚', jump_and_scratch:'ジャンプしてひっかく', spontaneous_combustion:'自然発火', magma_rocks:'マグマの岩', heavy_burns:'ひどいやけど', damage_format:'ダメージ {damage}', smokire_joined:'Smokireが山にやってきました', sold_cat:'{cat}を銀{price}で売りました' },
  ko: { fire:'불', burning_mountain:'불타는 산', smokire_blurb:'아주 뜨거운 고양이예요. 변덕스럽지만 정말 귀여워요. 추운 환경을 정말 싫어해요.', smokire_description:'높은 온도를 좋아한다면 이 고양이를 좋아할 거예요. 불꽃과 현무암, 마법만으로 만들어졌어요! 추위를 더 좋아한다면 Smokire가 당신을 태울 수도 있고 아닐 수도 있어요. 그에게 말하지 않으면 안전해요.', gold_production:'골드 생산', gold_production_format:'{seconds}초마다 골드 1개', jump_and_scratch:'점프 후 할퀴기', spontaneous_combustion:'자연 발화', magma_rocks:'마그마 바위', heavy_burns:'심한 화상', damage_format:'피해 {damage}', smokire_joined:'Smokire가 산에 합류했어요', sold_cat:'{cat}을(를) 실버 {price}개에 판매했어요' },
  ms: { fire:'Api', burning_mountain:'Gunung Membara', smokire_blurb:'Kucing yang sangat panas, cepat marah tetapi sangat comel. Benci suasana sejuk.', smokire_description:'Jika anda suka suhu tinggi, anda pasti suka kucing ini. Tubuhnya terbentuk sepenuhnya daripada api, basalt dan sihir! Jika anda lebih suka kesejukan, Smokire mungkin membakar anda, mungkin juga tidak. Anda selamat jika tidak memberitahunya.', gold_production:'Penghasilan emas', gold_production_format:'1 emas setiap {seconds} saat', jump_and_scratch:'Lompat dan cakar', spontaneous_combustion:'Pembakaran spontan', magma_rocks:'Batu magma', heavy_burns:'Lecuran teruk', damage_format:'{damage} kerosakan', smokire_joined:'Smokire menyertai gunung anda', sold_cat:'{cat} dijual dengan harga {price} perak' },
  hi: { fire:'आग', burning_mountain:'जलता हुआ पर्वत', smokire_blurb:'बहुत गर्म बिल्ली, चिड़चिड़ी लेकिन बेहद प्यारी। ठंडे माहौल से नफ़रत करती है।', smokire_description:'अगर आपको बहुत गर्म तापमान पसंद है, तो आपको यह बिल्ली पसंद आएगी। यह पूरी तरह आग की लपटों, बेसाल्ट और जादू से बनी है! अगर आपको ठंड पसंद है, तो Smokire शायद आपको जला दे, शायद नहीं। उसे न बताएं तो आप सुरक्षित हैं।', gold_production:'सोने का उत्पादन', gold_production_format:'हर {seconds} सेकंड में 1 सोना', jump_and_scratch:'कूदकर खरोंचना', spontaneous_combustion:'स्वतः दहन', magma_rocks:'मैग्मा की चट्टानें', heavy_burns:'गंभीर जलन', damage_format:'{damage} नुकसान', smokire_joined:'Smokire आपके पर्वत पर आ गया', sold_cat:'{cat} को {price} चाँदी में बेचा गया' }
};

const shopTranslations = {
  en:{smokire_name:'Smokire',cats:'Cats',buildings:'Buildings',close_shop:'Close shop',building_future_message:'This item is going to be useful in the future. Be patient!',cube_hatcher:'Cube Hatcher',cube_mixer:'Cube Mixer',feline_stocks:'Feline Stocks',farm:'Farm',building_installed:'Installed',building_owned:'Owned',building_buy:'Buy for {price} silver'},
  es:{smokire_name:'Humofuego',cats:'Gatos',buildings:'Edificios',close_shop:'Cerrar tienda',building_future_message:'Este artículo será útil en el futuro. ¡Ten paciencia!',cube_hatcher:'Incubadora de cubos',cube_mixer:'Mezclador de cubos',feline_stocks:'Reservas felinas',farm:'Granja',building_installed:'Instalado',building_owned:'Adquirido',building_buy:'Comprar por {price} de plata'},
  pt:{smokire_name:'Fumago',cats:'Gatos',buildings:'Construções',close_shop:'Fechar loja',building_future_message:'Este item será útil no futuro. Tenha paciência!',cube_hatcher:'Chocador de Cubos',cube_mixer:'Misturador de Cubos',feline_stocks:'Estoques Felinos',farm:'Fazenda',building_installed:'Instalado',building_owned:'Adquirido',building_buy:'Comprar por {price} de prata'},
  it:{smokire_name:'Fumofuoco',cats:'Gatti',buildings:'Edifici',close_shop:'Chiudi negozio',building_future_message:'Questo oggetto sarà utile in futuro. Abbi pazienza!',cube_hatcher:'Incubatrice di cubi',cube_mixer:'Miscelatore di cubi',feline_stocks:'Scorte feline',farm:'Fattoria',building_installed:'Installato',building_owned:'Acquistato',building_buy:'Compra per {price} argento'},
  de:{smokire_name:'Rauchfeuer',cats:'Katzen',buildings:'Gebäude',close_shop:'Laden schließen',building_future_message:'Dieser Gegenstand wird in Zukunft nützlich sein. Bitte hab Geduld!',cube_hatcher:'Würfelbrüter',cube_mixer:'Würfelmischer',feline_stocks:'Katzenvorräte',farm:'Farm',building_installed:'Installiert',building_owned:'Gekauft',building_buy:'Für {price} Silber kaufen'},
  nl:{smokire_name:'Rookvuur',cats:'Katten',buildings:'Gebouwen',close_shop:'Winkel sluiten',building_future_message:'Dit voorwerp komt later van pas. Heb geduld!',cube_hatcher:'Kubusbroeder',cube_mixer:'Kubusmenger',feline_stocks:'Kattenvoorraden',farm:'Boerderij',building_installed:'Geïnstalleerd',building_owned:'Gekocht',building_buy:'Kopen voor {price} zilver'},
  sv:{smokire_name:'Rökeld',cats:'Katter',buildings:'Byggnader',close_shop:'Stäng butiken',building_future_message:'Det här föremålet blir användbart i framtiden. Ha tålamod!',cube_hatcher:'Kubkläckare',cube_mixer:'Kubblandare',feline_stocks:'Kattförråd',farm:'Gård',building_installed:'Installerad',building_owned:'Köpt',building_buy:'Köp för {price} silver'},
  ru:{smokire_name:'Дымоогонь',cats:'Коты',buildings:'Постройки',close_shop:'Закрыть магазин',building_future_message:'Этот предмет пригодится в будущем. Потерпите!',cube_hatcher:'Кубический инкубатор',cube_mixer:'Кубический смеситель',feline_stocks:'Кошачьи запасы',farm:'Ферма',building_installed:'Установлено',building_owned:'Куплено',building_buy:'Купить за {price} серебра'},
  zh:{smokire_name:'烟焰',cats:'猫咪',buildings:'建筑',close_shop:'关闭商店',building_future_message:'这个物品以后会派上用场。请耐心等待！',cube_hatcher:'方块孵化器',cube_mixer:'方块混合器',feline_stocks:'猫咪储备站',farm:'农场',building_installed:'已安装',building_owned:'已购买',building_buy:'花费 {price} 银币购买'},
  ja:{smokire_name:'煙炎',cats:'ネコ',buildings:'建物',close_shop:'ショップを閉じる',building_future_message:'このアイテムは将来役立ちます。楽しみに待っていてね！',cube_hatcher:'キューブ孵化器',cube_mixer:'キューブミキサー',feline_stocks:'ネコ備蓄庫',farm:'農場',building_installed:'設置済み',building_owned:'購入済み',building_buy:'銀 {price} で購入'},
  ko:{smokire_name:'연기불',cats:'고양이',buildings:'건물',close_shop:'상점 닫기',building_future_message:'이 아이템은 앞으로 유용하게 쓰일 거예요. 조금만 기다려 주세요!',cube_hatcher:'큐브 부화기',cube_mixer:'큐브 믹서',feline_stocks:'고양이 비축소',farm:'농장',building_installed:'설치됨',building_owned:'구매함',building_buy:'실버 {price}개로 구매'},
  ms:{smokire_name:'AsapApi',cats:'Kucing',buildings:'Bangunan',close_shop:'Tutup kedai',building_future_message:'Item ini akan berguna pada masa hadapan. Harap bersabar!',cube_hatcher:'Penetas Kiub',cube_mixer:'Pengadun Kiub',feline_stocks:'Stok Kucing',farm:'Ladang',building_installed:'Dipasang',building_owned:'Dibeli',building_buy:'Beli dengan {price} perak'},
  hi:{smokire_name:'धुआँआग',cats:'बिल्लियाँ',buildings:'इमारतें',close_shop:'दुकान बंद करें',building_future_message:'यह वस्तु भविष्य में काम आएगी। कृपया धैर्य रखें!',cube_hatcher:'क्यूब हैचर',cube_mixer:'क्यूब मिक्सर',feline_stocks:'बिल्ली भंडार',farm:'खेत',building_installed:'स्थापित',building_owned:'खरीदा गया',building_buy:'{price} चाँदी में खरीदें'}
};

const interfaceTranslations = {
  en:{main_menu:'Main menu',choose_region:'Choose a region',resources:'Resources',player_level_xp:'Player level and XP',close_cat_details:'Close cat details',rarity_elements:'Rarity and elements',cat_life:'Cat health',attacks:'Attacks',cat_element_alt:'Cat element',earth_element_alt:'Earth element',unlock_level:'Unlocks at level {level}',level_short:'Lv',online_battles:'Online Battles',no_player_profiles:'No player profiles yet',check_back_players:'Check back when other players are online.',profile_title:'Online battles unlocked!',profile_intro:'Choose your player name and cat picture.',username:'Username',choose_picture:'Choose your picture',save_profile:'Save profile',level_up_title:'You leveled up!',new_level:'NEW LEVEL',unlocked:'Unlocked',continue:'Continue',close_settings:'Close settings',close_message:'Close message',battle_report:'Battle report',farm:'Farm',close_farm:'Close farm',move_farm:'Move farm',need_two_cats:'You need two cats to battle.',choose_two_cats:'Choose two cats to fight {opponent}',total_trophies:'Total: {count} trophies',opponent_lost:'{username} lost {count} trophies',opponent_gained:'{username} gained {count} trophies',farm_rate_option:'{amount} silver',farm_rate_details:'{amount} food / minute · 24 hours',farm_producing:'Producing {amount} food/min · stops in {duration}',farm_choose_rate:'Choose a 24-hour food production rate',duration_format:'{hours}h {minutes}m {seconds}s',away_singular:'While you were away, you were attacked {count} time.',away_plural:'While you were away, you were attacked {count} times.',you_won_trophies:'You won {count} trophies.',you_lost_trophies:'You lost {count} trophies.',trophy_unchanged:'Your trophy count did not change.',xp_earned:'You earned {count} XP.'},
  es:{main_menu:'Menú principal',choose_region:'Elige una región',resources:'Recursos',player_level_xp:'Nivel y XP del jugador',close_cat_details:'Cerrar detalles del gato',rarity_elements:'Rareza y elementos',cat_life:'Salud del gato',attacks:'Ataques',cat_element_alt:'Elemento de gato',earth_element_alt:'Elemento tierra',unlock_level:'Se desbloquea en el nivel {level}',level_short:'Niv.',online_battles:'Batallas en línea',no_player_profiles:'Aún no hay perfiles de jugadores',check_back_players:'Vuelve cuando haya otros jugadores en línea.',profile_title:'¡Batallas en línea desbloqueadas!',profile_intro:'Elige tu nombre de jugador y la imagen de tu gato.',username:'Nombre de usuario',choose_picture:'Elige tu imagen',save_profile:'Guardar perfil',level_up_title:'¡Subiste de nivel!',new_level:'NUEVO NIVEL',unlocked:'Desbloqueado',continue:'Continuar',close_settings:'Cerrar ajustes',close_message:'Cerrar mensaje',battle_report:'Informe de batalla',farm:'Granja',close_farm:'Cerrar granja',move_farm:'Mover granja',need_two_cats:'Necesitas dos gatos para luchar.',choose_two_cats:'Elige dos gatos para luchar contra {opponent}',total_trophies:'Total: {count} trofeos',opponent_lost:'{username} perdió {count} trofeos',opponent_gained:'{username} ganó {count} trofeos',farm_rate_option:'{amount} de plata',farm_rate_details:'{amount} de comida / minuto · 24 horas',farm_producing:'Produciendo {amount} de comida/min · termina en {duration}',farm_choose_rate:'Elige una tasa de producción de comida durante 24 horas',duration_format:'{hours} h {minutes} min {seconds} s',away_singular:'Mientras no estabas, te atacaron {count} vez.',away_plural:'Mientras no estabas, te atacaron {count} veces.',you_won_trophies:'Ganaste {count} trofeos.',you_lost_trophies:'Perdiste {count} trofeos.',trophy_unchanged:'Tu cantidad de trofeos no cambió.',xp_earned:'Ganaste {count} XP.'},
  pt:{main_menu:'Menu principal',choose_region:'Escolha uma região',resources:'Recursos',player_level_xp:'Nível e XP do jogador',close_cat_details:'Fechar detalhes do gato',rarity_elements:'Raridade e elementos',cat_life:'Vida do gato',attacks:'Ataques',cat_element_alt:'Elemento gato',earth_element_alt:'Elemento terra',unlock_level:'Desbloqueia no nível {level}',level_short:'Nv.',online_battles:'Batalhas online',no_player_profiles:'Ainda não há perfis de jogadores',check_back_players:'Volte quando outros jogadores estiverem online.',profile_title:'Batalhas online desbloqueadas!',profile_intro:'Escolha seu nome de jogador e a imagem do seu gato.',username:'Nome de usuário',choose_picture:'Escolha sua imagem',save_profile:'Salvar perfil',level_up_title:'Você subiu de nível!',new_level:'NOVO NÍVEL',unlocked:'Desbloqueado',continue:'Continuar',close_settings:'Fechar configurações',close_message:'Fechar mensagem',battle_report:'Relatório de batalha',farm:'Fazenda',close_farm:'Fechar fazenda',move_farm:'Mover fazenda',need_two_cats:'Você precisa de dois gatos para batalhar.',choose_two_cats:'Escolha dois gatos para lutar contra {opponent}',total_trophies:'Total: {count} troféus',opponent_lost:'{username} perdeu {count} troféus',opponent_gained:'{username} ganhou {count} troféus',farm_rate_option:'{amount} de prata',farm_rate_details:'{amount} comida / minuto · 24 horas',farm_producing:'Produzindo {amount} comida/min · termina em {duration}',farm_choose_rate:'Escolha uma taxa de produção de comida por 24 horas',duration_format:'{hours} h {minutes} min {seconds} s',away_singular:'Enquanto você estava fora, atacaram você {count} vez.',away_plural:'Enquanto você estava fora, atacaram você {count} vezes.',you_won_trophies:'Você ganhou {count} troféus.',you_lost_trophies:'Você perdeu {count} troféus.',trophy_unchanged:'Sua quantidade de troféus não mudou.',xp_earned:'Você ganhou {count} XP.'},
  it:{main_menu:'Menu principale',choose_region:'Scegli una regione',resources:'Risorse',player_level_xp:'Livello e XP del giocatore',close_cat_details:'Chiudi dettagli del gatto',rarity_elements:'Rarità ed elementi',cat_life:'Salute del gatto',attacks:'Attacchi',cat_element_alt:'Elemento gatto',earth_element_alt:'Elemento terra',unlock_level:'Si sblocca al livello {level}',level_short:'Liv.',online_battles:'Battaglie online',no_player_profiles:'Nessun profilo giocatore',check_back_players:'Torna quando ci saranno altri giocatori online.',profile_title:'Battaglie online sbloccate!',profile_intro:'Scegli il tuo nome giocatore e l’immagine del gatto.',username:'Nome utente',choose_picture:'Scegli la tua immagine',save_profile:'Salva profilo',level_up_title:'Hai raggiunto un nuovo livello!',new_level:'NUOVO LIVELLO',unlocked:'Sbloccato',continue:'Continua',close_settings:'Chiudi impostazioni',close_message:'Chiudi messaggio',battle_report:'Resoconto battaglia',farm:'Fattoria',close_farm:'Chiudi fattoria',move_farm:'Sposta fattoria',need_two_cats:'Servono due gatti per combattere.',choose_two_cats:'Scegli due gatti per sfidare {opponent}',total_trophies:'Totale: {count} trofei',opponent_lost:'{username} ha perso {count} trofei',opponent_gained:'{username} ha guadagnato {count} trofei',farm_rate_option:'{amount} argento',farm_rate_details:'{amount} cibo / minuto · 24 ore',farm_producing:'Produzione: {amount} cibo/min · termina tra {duration}',farm_choose_rate:'Scegli una produzione di cibo per 24 ore',duration_format:'{hours} h {minutes} min {seconds} s',away_singular:'Durante la tua assenza, sei stato attaccato {count} volta.',away_plural:'Durante la tua assenza, sei stato attaccato {count} volte.',you_won_trophies:'Hai vinto {count} trofei.',you_lost_trophies:'Hai perso {count} trofei.',trophy_unchanged:'Il tuo totale di trofei non è cambiato.',xp_earned:'Hai ottenuto {count} XP.'},
  de:{main_menu:'Hauptmenü',choose_region:'Region auswählen',resources:'Ressourcen',player_level_xp:'Spielerstufe und XP',close_cat_details:'Katzendetails schließen',rarity_elements:'Seltenheit und Elemente',cat_life:'Katzengesundheit',attacks:'Angriffe',cat_element_alt:'Katzenelement',earth_element_alt:'Element Erde',unlock_level:'Freischaltung auf Level {level}',level_short:'Lvl.',online_battles:'Onlinekämpfe',no_player_profiles:'Noch keine Spielerprofile',check_back_players:'Schau später wieder vorbei, wenn andere Spieler online sind.',profile_title:'Onlinekämpfe freigeschaltet!',profile_intro:'Wähle deinen Spielernamen und ein Katzenbild.',username:'Benutzername',choose_picture:'Bild auswählen',save_profile:'Profil speichern',level_up_title:'Du bist aufgestiegen!',new_level:'NEUES LEVEL',unlocked:'Freigeschaltet',continue:'Weiter',close_settings:'Einstellungen schließen',close_message:'Nachricht schließen',battle_report:'Kampfbericht',farm:'Farm',close_farm:'Farm schließen',move_farm:'Farm verschieben',need_two_cats:'Du brauchst zwei Katzen für einen Kampf.',choose_two_cats:'Wähle zwei Katzen für den Kampf gegen {opponent}',total_trophies:'Gesamt: {count} Trophäen',opponent_lost:'{username} hat {count} Trophäen verloren',opponent_gained:'{username} hat {count} Trophäen gewonnen',farm_rate_option:'{amount} Silber',farm_rate_details:'{amount} Futter / Minute · 24 Stunden',farm_producing:'Produktion: {amount} Futter/Min. · endet in {duration}',farm_choose_rate:'Wähle eine Futterproduktion für 24 Stunden',duration_format:'{hours} Std. {minutes} Min. {seconds} Sek.',away_singular:'Während du weg warst, wurdest du {count}-mal angegriffen.',away_plural:'Während du weg warst, wurdest du {count}-mal angegriffen.',you_won_trophies:'Du hast {count} Trophäen gewonnen.',you_lost_trophies:'Du hast {count} Trophäen verloren.',trophy_unchanged:'Deine Trophäenanzahl hat sich nicht geändert.',xp_earned:'Du hast {count} XP erhalten.'},
  nl:{main_menu:'Hoofdmenu',choose_region:'Kies een regio',resources:'Hulpbronnen',player_level_xp:'Spelerniveau en XP',close_cat_details:'Katgegevens sluiten',rarity_elements:'Zeldzaamheid en elementen',cat_life:'Gezondheid van de kat',attacks:'Aanvallen',cat_element_alt:'Katelement',earth_element_alt:'Aarde-element',unlock_level:'Ontgrendelt op level {level}',level_short:'Lvl.',online_battles:'Online gevechten',no_player_profiles:'Nog geen spelersprofielen',check_back_players:'Kom terug wanneer andere spelers online zijn.',profile_title:'Online gevechten ontgrendeld!',profile_intro:'Kies je spelersnaam en een afbeelding van je kat.',username:'Gebruikersnaam',choose_picture:'Kies je afbeelding',save_profile:'Profiel opslaan',level_up_title:'Je bent een level gestegen!',new_level:'NIEUW LEVEL',unlocked:'Ontgrendeld',continue:'Doorgaan',close_settings:'Instellingen sluiten',close_message:'Bericht sluiten',battle_report:'Gevechtsverslag',farm:'Boerderij',close_farm:'Boerderij sluiten',move_farm:'Boerderij verplaatsen',need_two_cats:'Je hebt twee katten nodig om te vechten.',choose_two_cats:'Kies twee katten om tegen {opponent} te vechten',total_trophies:'Totaal: {count} trofeeën',opponent_lost:'{username} verloor {count} trofeeën',opponent_gained:'{username} kreeg {count} trofeeën',farm_rate_option:'{amount} zilver',farm_rate_details:'{amount} voer / minuut · 24 uur',farm_producing:'Productie: {amount} voer/min · stopt over {duration}',farm_choose_rate:'Kies een voerproductie voor 24 uur',duration_format:'{hours} u {minutes} min {seconds} sec',away_singular:'Je bent {count} keer aangevallen terwijl je weg was.',away_plural:'Je bent {count} keer aangevallen terwijl je weg was.',you_won_trophies:'Je won {count} trofeeën.',you_lost_trophies:'Je verloor {count} trofeeën.',trophy_unchanged:'Je aantal trofeeën is niet veranderd.',xp_earned:'Je hebt {count} XP verdiend.'},
  sv:{main_menu:'Huvudmeny',choose_region:'Välj en region',resources:'Resurser',player_level_xp:'Spelarnivå och XP',close_cat_details:'Stäng kattinformation',rarity_elements:'Sällsynthet och element',cat_life:'Kattens hälsa',attacks:'Attacker',cat_element_alt:'Kattelement',earth_element_alt:'Jordelement',unlock_level:'Låses upp på nivå {level}',level_short:'Nivå',online_battles:'Onlinestrider',no_player_profiles:'Inga spelarprofiler ännu',check_back_players:'Titta in igen när andra spelare är online.',profile_title:'Onlinestrider upplåsta!',profile_intro:'Välj ditt spelarnamn och en kattbild.',username:'Användarnamn',choose_picture:'Välj en bild',save_profile:'Spara profil',level_up_title:'Du gick upp en nivå!',new_level:'NY NIVÅ',unlocked:'Upplåst',continue:'Fortsätt',close_settings:'Stäng inställningar',close_message:'Stäng meddelandet',battle_report:'Stridsrapport',farm:'Gård',close_farm:'Stäng gården',move_farm:'Flytta gården',need_two_cats:'Du behöver två katter för att slåss.',choose_two_cats:'Välj två katter att slåss mot {opponent} med',total_trophies:'Totalt: {count} troféer',opponent_lost:'{username} förlorade {count} troféer',opponent_gained:'{username} fick {count} troféer',farm_rate_option:'{amount} silver',farm_rate_details:'{amount} mat / minut · 24 timmar',farm_producing:'Producerar {amount} mat/min · slutar om {duration}',farm_choose_rate:'Välj en matproduktionstakt för 24 timmar',duration_format:'{hours} h {minutes} min {seconds} s',away_singular:'Du attackerades {count} gång medan du var borta.',away_plural:'Du attackerades {count} gånger medan du var borta.',you_won_trophies:'Du vann {count} troféer.',you_lost_trophies:'Du förlorade {count} troféer.',trophy_unchanged:'Ditt antal troféer ändrades inte.',xp_earned:'Du fick {count} XP.'},
  ru:{main_menu:'Главное меню',choose_region:'Выберите регион',resources:'Ресурсы',player_level_xp:'Уровень игрока и XP',close_cat_details:'Закрыть сведения о коте',rarity_elements:'Редкость и стихии',cat_life:'Здоровье кота',attacks:'Атаки',cat_element_alt:'Стихия кота',earth_element_alt:'Стихия земли',unlock_level:'Откроется на уровне {level}',level_short:'Ур.',online_battles:'Онлайн-битвы',no_player_profiles:'Профилей игроков пока нет',check_back_players:'Загляните позже, когда другие игроки будут в сети.',profile_title:'Онлайн-битвы открыты!',profile_intro:'Выберите имя игрока и изображение кота.',username:'Имя пользователя',choose_picture:'Выберите изображение',save_profile:'Сохранить профиль',level_up_title:'Новый уровень!',new_level:'НОВЫЙ УРОВЕНЬ',unlocked:'Открыто',continue:'Продолжить',close_settings:'Закрыть настройки',close_message:'Закрыть сообщение',battle_report:'Отчёт о битве',farm:'Ферма',close_farm:'Закрыть ферму',move_farm:'Переместить ферму',need_two_cats:'Для битвы нужны два кота.',choose_two_cats:'Выберите двух котов для битвы с игроком {opponent}',total_trophies:'Всего трофеев: {count}',opponent_lost:'{username} потерял трофеи: {count}',opponent_gained:'{username} получил трофеи: {count}',farm_rate_option:'{amount} серебра',farm_rate_details:'{amount} еды / мин · 24 часа',farm_producing:'Производство: {amount} еды/мин · до конца {duration}',farm_choose_rate:'Выберите скорость производства еды на 24 часа',duration_format:'{hours} ч {minutes} мин {seconds} сек',away_singular:'Пока вас не было, на вас напали {count} раз.',away_plural:'Пока вас не было, на вас напали {count} раз.',you_won_trophies:'Вы получили трофеи: {count}.',you_lost_trophies:'Вы потеряли трофеи: {count}.',trophy_unchanged:'Количество трофеев не изменилось.',xp_earned:'Вы получили {count} XP.'},
  zh:{main_menu:'主菜单',choose_region:'选择区域',resources:'资源',player_level_xp:'玩家等级与经验值',close_cat_details:'关闭猫咪详情',rarity_elements:'稀有度与元素',cat_life:'猫咪生命值',attacks:'攻击',cat_element_alt:'猫咪元素',earth_element_alt:'大地元素',unlock_level:'达到等级 {level} 解锁',level_short:'级',online_battles:'在线对战',no_player_profiles:'暂无玩家资料',check_back_players:'其他玩家上线后再来看看。',profile_title:'已解锁在线对战！',profile_intro:'选择玩家名称和猫咪头像。',username:'用户名',choose_picture:'选择头像',save_profile:'保存资料',level_up_title:'升级了！',new_level:'新等级',unlocked:'已解锁',continue:'继续',close_settings:'关闭设置',close_message:'关闭消息',battle_report:'战斗报告',farm:'农场',close_farm:'关闭农场',move_farm:'移动农场',need_two_cats:'需要两只猫咪才能对战。',choose_two_cats:'选择两只猫咪与 {opponent} 对战',total_trophies:'总计：{count} 个奖杯',opponent_lost:'{username}失去了 {count} 个奖杯',opponent_gained:'{username}获得了 {count} 个奖杯',farm_rate_option:'{amount} 银币',farm_rate_details:'每分钟 {amount} 食物 · 24小时',farm_producing:'正在生产：每分钟 {amount} 食物 · {duration} 后结束',farm_choose_rate:'选择持续24小时的食物生产速度',duration_format:'{hours}小时 {minutes}分 {seconds}秒',away_singular:'离开期间，你遭到 {count} 次攻击。',away_plural:'离开期间，你遭到 {count} 次攻击。',you_won_trophies:'你获得了 {count} 个奖杯。',you_lost_trophies:'你失去了 {count} 个奖杯。',trophy_unchanged:'奖杯数量没有变化。',xp_earned:'你获得了 {count} XP。'},
  ja:{main_menu:'メインメニュー',choose_region:'地域を選択',resources:'資源',player_level_xp:'プレイヤーレベルとXP',close_cat_details:'ネコの詳細を閉じる',rarity_elements:'レア度と属性',cat_life:'ネコの体力',attacks:'攻撃',cat_element_alt:'ネコ属性',earth_element_alt:'地属性',unlock_level:'レベル{level}で解放',level_short:'Lv.',online_battles:'オンラインバトル',no_player_profiles:'プレイヤープロフィールはまだありません',check_back_players:'他のプレイヤーがオンラインのときにまた確認してください。',profile_title:'オンラインバトルが解放されました！',profile_intro:'プレイヤー名とネコの画像を選んでください。',username:'ユーザー名',choose_picture:'画像を選択',save_profile:'プロフィールを保存',level_up_title:'レベルアップ！',new_level:'新しいレベル',unlocked:'解放',continue:'続ける',close_settings:'設定を閉じる',close_message:'メッセージを閉じる',battle_report:'バトルレポート',farm:'農場',close_farm:'農場を閉じる',move_farm:'農場を移動',need_two_cats:'バトルにはネコが2匹必要です。',choose_two_cats:'{opponent}と戦うネコを2匹選択',total_trophies:'合計：トロフィー{count}',opponent_lost:'{username}はトロフィーを{count}個失った',opponent_gained:'{username}はトロフィーを{count}個獲得した',farm_rate_option:'銀{amount}',farm_rate_details:'食料 {amount} / 分 · 24時間',farm_producing:'食料を毎分{amount}生産中 · 残り{duration}',farm_choose_rate:'24時間の食料生産量を選択',duration_format:'{hours}時間 {minutes}分 {seconds}秒',away_singular:'留守中に{count}回攻撃されました。',away_plural:'留守中に{count}回攻撃されました。',you_won_trophies:'トロフィーを{count}個獲得しました。',you_lost_trophies:'トロフィーを{count}個失いました。',trophy_unchanged:'トロフィー数に変化はありません。',xp_earned:'XPを{count}獲得しました。'},
  ko:{main_menu:'메인 메뉴',choose_region:'지역 선택',resources:'자원',player_level_xp:'플레이어 레벨 및 XP',close_cat_details:'고양이 정보 닫기',rarity_elements:'희귀도 및 속성',cat_life:'고양이 체력',attacks:'공격',cat_element_alt:'고양이 속성',earth_element_alt:'대지 속성',unlock_level:'레벨 {level}에 해제',level_short:'레벨',online_battles:'온라인 배틀',no_player_profiles:'아직 플레이어 프로필이 없어요',check_back_players:'다른 플레이어가 온라인일 때 다시 확인하세요.',profile_title:'온라인 배틀이 해제됐어요!',profile_intro:'플레이어 이름과 고양이 사진을 선택하세요.',username:'사용자 이름',choose_picture:'사진 선택',save_profile:'프로필 저장',level_up_title:'레벨이 올랐어요!',new_level:'새 레벨',unlocked:'해제됨',continue:'계속',close_settings:'설정 닫기',close_message:'메시지 닫기',battle_report:'배틀 보고서',farm:'농장',close_farm:'농장 닫기',move_farm:'농장 이동',need_two_cats:'배틀하려면 고양이 두 마리가 필요해요.',choose_two_cats:'{opponent}와 싸울 고양이 두 마리를 선택하세요',total_trophies:'총 트로피: {count}',opponent_lost:'{username} 트로피 {count}개를 잃었어요',opponent_gained:'{username} 트로피 {count}개를 얻었어요',farm_rate_option:'실버 {amount}개',farm_rate_details:'분당 먹이 {amount} · 24시간',farm_producing:'분당 먹이 {amount} 생산 중 · {duration} 후 종료',farm_choose_rate:'24시간 먹이 생산량을 선택하세요',duration_format:'{hours}시간 {minutes}분 {seconds}초',away_singular:'자리를 비운 동안 {count}번 공격받았어요.',away_plural:'자리를 비운 동안 {count}번 공격받았어요.',you_won_trophies:'트로피 {count}개를 얻었어요.',you_lost_trophies:'트로피 {count}개를 잃었어요.',trophy_unchanged:'트로피 수가 변하지 않았어요.',xp_earned:'XP {count}을(를) 얻었어요.'},
  ms:{main_menu:'Menu utama',choose_region:'Pilih wilayah',resources:'Sumber',player_level_xp:'Tahap pemain dan XP',close_cat_details:'Tutup butiran kucing',rarity_elements:'Kelangkaan dan elemen',cat_life:'Kesihatan kucing',attacks:'Serangan',cat_element_alt:'Elemen kucing',earth_element_alt:'Elemen bumi',unlock_level:'Dibuka pada tahap {level}',level_short:'Tahap',online_battles:'Pertarungan Dalam Talian',no_player_profiles:'Belum ada profil pemain',check_back_players:'Kembali apabila pemain lain berada dalam talian.',profile_title:'Pertarungan dalam talian dibuka!',profile_intro:'Pilih nama pemain dan gambar kucing anda.',username:'Nama pengguna',choose_picture:'Pilih gambar',save_profile:'Simpan profil',level_up_title:'Tahap anda meningkat!',new_level:'TAHAP BAHARU',unlocked:'Dibuka',continue:'Teruskan',close_settings:'Tutup tetapan',close_message:'Tutup mesej',battle_report:'Laporan pertarungan',farm:'Ladang',close_farm:'Tutup ladang',move_farm:'Pindahkan ladang',need_two_cats:'Anda perlukan dua ekor kucing untuk bertarung.',choose_two_cats:'Pilih dua ekor kucing untuk melawan {opponent}',total_trophies:'Jumlah: {count} trofi',opponent_lost:'{username} kehilangan {count} trofi',opponent_gained:'{username} mendapat {count} trofi',farm_rate_option:'{amount} perak',farm_rate_details:'{amount} makanan / minit · 24 jam',farm_producing:'Menghasilkan {amount} makanan/min · tamat dalam {duration}',farm_choose_rate:'Pilih kadar penghasilan makanan selama 24 jam',duration_format:'{hours} jam {minutes} min {seconds} saat',away_singular:'Semasa anda tiada, anda diserang {count} kali.',away_plural:'Semasa anda tiada, anda diserang {count} kali.',you_won_trophies:'Anda mendapat {count} trofi.',you_lost_trophies:'Anda kehilangan {count} trofi.',trophy_unchanged:'Jumlah trofi anda tidak berubah.',xp_earned:'Anda memperoleh {count} XP.'},
  hi:{main_menu:'मुख्य मेन्यू',choose_region:'क्षेत्र चुनें',resources:'संसाधन',player_level_xp:'खिलाड़ी का स्तर और XP',close_cat_details:'बिल्ली की जानकारी बंद करें',rarity_elements:'दुर्लभता और तत्व',cat_life:'बिल्ली की सेहत',attacks:'हमले',cat_element_alt:'बिल्ली तत्व',earth_element_alt:'पृथ्वी तत्व',unlock_level:'स्तर {level} पर अनलॉक होगा',level_short:'स्तर',online_battles:'ऑनलाइन लड़ाइयाँ',no_player_profiles:'अभी कोई खिलाड़ी प्रोफ़ाइल नहीं है',check_back_players:'दूसरे खिलाड़ियों के ऑनलाइन होने पर फिर आएँ।',profile_title:'ऑनलाइन लड़ाइयाँ अनलॉक हुईं!',profile_intro:'अपना खिलाड़ी नाम और बिल्ली की तस्वीर चुनें।',username:'उपयोगकर्ता नाम',choose_picture:'तस्वीर चुनें',save_profile:'प्रोफ़ाइल सहेजें',level_up_title:'आपका स्तर बढ़ गया!',new_level:'नया स्तर',unlocked:'अनलॉक हुआ',continue:'जारी रखें',close_settings:'सेटिंग बंद करें',close_message:'संदेश बंद करें',battle_report:'लड़ाई की रिपोर्ट',farm:'खेत',close_farm:'खेत बंद करें',move_farm:'खेत हटाएँ',need_two_cats:'लड़ने के लिए दो बिल्लियाँ चाहिए।',choose_two_cats:'{opponent} से लड़ने के लिए दो बिल्लियाँ चुनें',total_trophies:'कुल ट्रॉफी: {count}',opponent_lost:'{username} ने {count} ट्रॉफी खोईं',opponent_gained:'{username} को {count} ट्रॉफी मिलीं',farm_rate_option:'{amount} चाँदी',farm_rate_details:'हर मिनट {amount} खाना · 24 घंटे',farm_producing:'हर मिनट {amount} खाना बन रहा है · {duration} में समाप्त',farm_choose_rate:'24 घंटे के लिए भोजन उत्पादन दर चुनें',duration_format:'{hours} घंटे {minutes} मिनट {seconds} सेकंड',away_singular:'आपकी अनुपस्थिति में आप पर {count} बार हमला हुआ।',away_plural:'आपकी अनुपस्थिति में आप पर {count} बार हमला हुआ।',you_won_trophies:'आपने {count} ट्रॉफी जीतीं।',you_lost_trophies:'आपने {count} ट्रॉफी खोईं।',trophy_unchanged:'आपकी ट्रॉफी संख्या नहीं बदली।',xp_earned:'आपने {count} XP कमाए।'}
};

const closeLanguageLabels = {en:'Close',es:'Cerrar',pt:'Fechar',it:'Chiudi',de:'Schließen',nl:'Sluiten',sv:'Stäng',ru:'Закрыть',zh:'关闭',ja:'閉じる',ko:'닫기',ms:'Tutup',hi:'बंद करें'};

const storedLanguage = localStorage.getItem('catdance-language');
let currentLanguage = translations[storedLanguage] ? storedLanguage : 'en';
let audioContext;
let currentScreen = 'home';
let currentTrack;
let selectedCatId = null;
let movingCat = false;
let movingBuildingId = null;
let shopTab = 'cats';
let selectedBuildingId = null;
let selectedFarmUid = null;
let shopRenderSignature = '';
const mapRows = 7;
const mapColumns = 10;
const blockedTiles = new Set([
  '1,1','1,2','1,3','1,6','1,7','1,8','1,9','1,10',
  '2,1','2,2','2,6','2,7','2,8','2,9','2,10',
  '3,1','3,6','3,7','3,8','3,9','3,10',
  '4,1','4,10','5,1','5,10','6,1','6,10','7,1','7,10'
]);
const audioTracks = {
  main: document.querySelector('#main-track'),
  mountain: document.querySelector('#mountain-track'),
  metropolis: document.querySelector('#metropolis-track'),
  battle: document.querySelector('#battle-track')
};
const savedGame = (() => {
  try { return JSON.parse(localStorage.getItem('catdance-save') || 'null'); }
  catch { return null; }
})();
function cleanSavedBreeds(entries) {
  if (!Array.isArray(entries)) return [];
  const ordered = entries.filter(item => item && ['rocky','smokire','volcanic_lava','floralis','florestalis'].includes(item.type)
    && Number.isFinite(item.startedAt) && ['arid','burning','metropolis','greenfields'].includes(item.mountain))
    .map(item => ({ ...item, mixerMountain: ['arid','burning','metropolis','greenfields'].includes(item.mixerMountain) ? item.mixerMountain : item.mountain }))
    .sort((a, b) => a.startedAt - b.startedAt);
  const occupiedMixers = new Set();
  return ordered.filter(item => {
    if (occupiedMixers.has(item.mixerMountain)) return false;
    occupiedMixers.add(item.mixerMountain);
    return true;
  });
}
const now = Date.now();
const gameState = {
  silver: (Number.isFinite(savedGame?.silver) ? savedGame.silver : 500) + (savedGame?.currencySchema >= 3 ? 0 : (Number.isFinite(savedGame?.gold) ? savedGame.gold : 0)),
  rubies: Number.isFinite(savedGame?.rubies) ? savedGame.rubies : 20,
  food: Number.isFinite(savedGame?.food) ? savedGame.food : 1000,
  playerLevel: Number.isInteger(savedGame?.playerLevel) && savedGame.playerLevel > 0 ? savedGame.playerLevel : 1,
  xp: Number.isFinite(savedGame?.xp) && savedGame.xp >= 0 ? savedGame.xp : 0,
  cats: [],
  buildings: Array.isArray(savedGame?.buildings) ? savedGame.buildings.filter(item => item && typeof item.id === 'string' && typeof item.mountain === 'string') : [],
  eggs: Array.isArray(savedGame?.eggs) ? savedGame.eggs.filter(item => item && ['rocky','smokire','volcanic_lava','floralis','florestalis'].includes(item.type) && ['arid','burning','metropolis','greenfields'].includes(item.mountain) && Number.isFinite(item.startedAt)) : [],
  breeds: cleanSavedBreeds(savedGame?.breeds),
  startersCupCompleted: savedGame?.startersCupCompleted === true,
  rubyCupStage: Number.isInteger(savedGame?.rubyCupStage) ? Math.max(0, Math.min(5, savedGame.rubyCupStage)) : 0,
  metropolisCupStage: Number.isInteger(savedGame?.metropolisCupStage) ? Math.max(0, Math.min(10, savedGame.metropolisCupStage)) : 0,
  totemCupStage: Number.isInteger(savedGame?.totemCupStage) ? Math.max(0, Math.min(10, savedGame.totemCupStage)) : 0,
  loveTotemUnlocked: savedGame?.loveTotemUnlocked === true,
  mountainousMetropolisUnlocked: savedGame?.mountainousMetropolisUnlocked === true,
  onlineProfile: savedGame?.onlineProfile && typeof savedGame.onlineProfile.username === 'string'
    ? { username: savedGame.onlineProfile.username.slice(0, 20), catType: ['smokire','volcanic_lava','floralis','florestalis'].includes(savedGame.onlineProfile.catType) ? savedGame.onlineProfile.catType : 'rocky' }
    : null,
  battleRoster: Array.isArray(savedGame?.battleRoster) ? savedGame.battleRoster.filter(id => typeof id === 'string').slice(0, 2) : [],
  trophies: Number.isInteger(savedGame?.trophies) ? Math.max(0, savedGame.trophies) : 100
};
let accountSaveEnabled = false;
let accountSaveTimer = null;
let accountSaveQueue = Promise.resolve();
let mountainChoicesSignature = '';
const LEVEL_UP_REWARD = { silver: 100, rubies: 5 };
// Register future level-gated content here so level-up notices list it automatically.
const LEVEL_UNLOCKS = [{ level: 3, name: 'Online battles' }];
const pendingLevelUps = [];
const levelUpScreen = document.querySelector('#level-up-screen');
const levelUpRewards = document.querySelector('#level-up-rewards');
const mountainChoices = document.querySelector('#mountain-choices');
const battleContent = document.querySelector('#battle-content');
const onlineProfileModal = document.querySelector('#online-profile-modal');
const battleText = {
  en:{battle:'Battle',cups:'Cups',starters_cup:'Starters Cup',ruby_cup:'Ruby Cup',totem_cup:'Totem Cup',totem_cup_complete:'Totem Cup complete!',totem_stage:'Stage {number} / 10',choose_two_cats_totem:'Choose 2 cats for Totem Cup',love_totem_reward:'Love Totem',two_battles:'2 battles',five_stages:'5 stages',stage_number:'Stage {number} of 5',stage_progress:'Stage {number} · 2 cats',choose_two_cats_ruby:'Choose 2 cats for Ruby Cup',enter_ruby_cup:'Enter Ruby Cup',next_stage:'Next stage',start_cup:'Enter cup',choose_battle_cat:'Choose your cat',your_cat:'Your cat',enemy_cat:'Opponent',battle_number:'Battle {number} of 2',your_turn:'Your turn',enemy_turn:'Opponent’s turn',choose_attack:'Choose an attack',scratch:'Scratch',bite:'Bite',earthquake:'Earthquake',hay_bale:'Rolling hay bale',sandstorm:'Sandstorm',hp:'HP',fainted:'{cat} fainted!',choose_next_cat:'Choose your next cat',no_battle_cats:'You need a Rocky Cat to enter this cup. Get one from the mountain shop.',battle_win:'Battle won!',battle_loss:'Your team was defeated',cup_complete:'Starters Cup complete!',ruby_cup_complete:'Ruby Cup complete!',first_win_reward:'Battle reward: 100 XP',cup_reward:'Cup rewards: 1,000 XP and 10 rubies',continue_battle:'Next battle',retry_cup:'Try again',back_cups:'Back to cups',finish:'Finish',victory:'Victory!',defeat:'Defeat'},
  es:{battle:'Batalla',cups:'Copas',starters_cup:'Copa de principiantes',two_battles:'2 batallas',start_cup:'Entrar en la copa',choose_battle_cat:'Elige tu gato',your_cat:'Tu gato',enemy_cat:'Rival',battle_number:'Batalla {number} de 2',your_turn:'Tu turno',enemy_turn:'Turno del rival',choose_attack:'Elige un ataque',scratch:'Arañazo',bite:'Mordisco',earthquake:'Terremoto',hay_bale:'Bala de heno rodante',sandstorm:'Tormenta de arena',hp:'PS',fainted:'¡{cat} se ha debilitado!',choose_next_cat:'Elige tu siguiente gato',no_battle_cats:'Necesitas un Gato Rocoso para entrar. Consigue uno en la tienda de la montaña.',battle_win:'¡Batalla ganada!',battle_loss:'Tu equipo ha sido derrotado',cup_complete:'¡Copa de principiantes completada!',first_win_reward:'Recompensa de batalla: 100 XP',cup_reward:'Recompensas: 1.000 XP y 10 rubíes',continue_battle:'Siguiente batalla',retry_cup:'Intentar de nuevo',back_cups:'Volver a las copas',finish:'Terminar',victory:'¡Victoria!',defeat:'Derrota'},
  pt:{battle:'Batalha',cups:'Copas',starters_cup:'Copa Inicial',two_battles:'2 batalhas',start_cup:'Entrar na copa',choose_battle_cat:'Escolha seu gato',your_cat:'Seu gato',enemy_cat:'Oponente',battle_number:'Batalha {number} de 2',your_turn:'Sua vez',enemy_turn:'Vez do oponente',choose_attack:'Escolha um ataque',scratch:'Arranhão',bite:'Mordida',earthquake:'Terremoto',hay_bale:'Fardo de feno rolante',sandstorm:'Tempestade de areia',hp:'PV',fainted:'{cat} desmaiou!',choose_next_cat:'Escolha seu próximo gato',no_battle_cats:'Você precisa de um Gato Rochoso para entrar. Compre um na loja da montanha.',battle_win:'Batalha vencida!',battle_loss:'Sua equipe foi derrotada',cup_complete:'Copa Inicial concluída!',first_win_reward:'Recompensa da batalha: 100 XP',cup_reward:'Recompensas: 1.000 XP e 10 rubis',continue_battle:'Próxima batalha',retry_cup:'Tentar novamente',back_cups:'Voltar às copas',finish:'Finalizar',victory:'Vitória!',defeat:'Derrota'},
  it:{battle:'Battaglia',cups:'Coppe',starters_cup:'Coppa principianti',two_battles:'2 battaglie',start_cup:'Entra nella coppa',choose_battle_cat:'Scegli il tuo gatto',your_cat:'Il tuo gatto',enemy_cat:'Avversario',battle_number:'Battaglia {number} di 2',your_turn:'Tocca a te',enemy_turn:'Tocca all’avversario',choose_attack:'Scegli un attacco',scratch:'Graffio',bite:'Morso',earthquake:'Terremoto',hay_bale:'Rotolamento di fieno',sandstorm:'Tempesta di sabbia',hp:'PF',fainted:'{cat} è svenuto!',choose_next_cat:'Scegli il prossimo gatto',no_battle_cats:'Serve un Gatto Roccioso per partecipare. Prendine uno al negozio della montagna.',battle_win:'Battaglia vinta!',battle_loss:'La tua squadra è stata sconfitta',cup_complete:'Coppa principianti completata!',first_win_reward:'Ricompensa battaglia: 100 XP',cup_reward:'Premi: 1.000 XP e 10 rubini',continue_battle:'Battaglia successiva',retry_cup:'Riprova',back_cups:'Torna alle coppe',finish:'Fine',victory:'Vittoria!',defeat:'Sconfitta'},
  de:{battle:'Kampf',cups:'Pokale',starters_cup:'Anfängerpokal',two_battles:'2 Kämpfe',start_cup:'Pokal starten',choose_battle_cat:'Wähle deine Katze',your_cat:'Deine Katze',enemy_cat:'Gegner',battle_number:'Kampf {number} von 2',your_turn:'Du bist dran',enemy_turn:'Gegner ist dran',choose_attack:'Wähle einen Angriff',scratch:'Kratzer',bite:'Biss',earthquake:'Erdbeben',hay_bale:'Rollender Heuballen',sandstorm:'Sandsturm',hp:'LP',fainted:'{cat} ist besiegt!',choose_next_cat:'Wähle deine nächste Katze',no_battle_cats:'Du brauchst eine Felskatze für diesen Pokal. Hol dir eine im Bergladen.',battle_win:'Kampf gewonnen!',battle_loss:'Dein Team wurde besiegt',cup_complete:'Anfängerpokal abgeschlossen!',first_win_reward:'Kampfbelohnung: 100 XP',cup_reward:'Belohnungen: 1.000 XP und 10 Rubine',continue_battle:'Nächster Kampf',retry_cup:'Erneut versuchen',back_cups:'Zurück zu den Pokalen',finish:'Beenden',victory:'Sieg!',defeat:'Niederlage'},
  nl:{battle:'Gevecht',cups:'Bekers',starters_cup:'Beginnersbeker',two_battles:'2 gevechten',start_cup:'Beker starten',choose_battle_cat:'Kies je kat',your_cat:'Jouw kat',enemy_cat:'Tegenstander',battle_number:'Gevecht {number} van 2',your_turn:'Jouw beurt',enemy_turn:'Beurt van tegenstander',choose_attack:'Kies een aanval',scratch:'Krab',bite:'Beet',earthquake:'Aardbeving',hay_bale:'Rollende hooibaal',sandstorm:'Zandstorm',hp:'HP',fainted:'{cat} is uitgeschakeld!',choose_next_cat:'Kies je volgende kat',no_battle_cats:'Je hebt een Rotskat nodig. Haal er een in de bergwinkel.',battle_win:'Gevecht gewonnen!',battle_loss:'Je team is verslagen',cup_complete:'Beginnersbeker voltooid!',first_win_reward:'Gevechtsbeloning: 100 XP',cup_reward:'Beloningen: 1.000 XP en 10 robijnen',continue_battle:'Volgend gevecht',retry_cup:'Opnieuw proberen',back_cups:'Terug naar bekers',finish:'Klaar',victory:'Overwinning!',defeat:'Nederlaag'},
  sv:{battle:'Strid',cups:'Cuper',starters_cup:'Nybörjarkuppen',two_battles:'2 strider',start_cup:'Gå med i cupen',choose_battle_cat:'Välj din katt',your_cat:'Din katt',enemy_cat:'Motståndare',battle_number:'Strid {number} av 2',your_turn:'Din tur',enemy_turn:'Motståndarens tur',choose_attack:'Välj en attack',scratch:'Klo',bite:'Bet',earthquake:'Jordbävning',hay_bale:'Rullande höbal',sandstorm:'Sandstorm',hp:'HP',fainted:'{cat} svimmade!',choose_next_cat:'Välj nästa katt',no_battle_cats:'Du behöver en Stenkatt. Skaffa en i bergsbutiken.',battle_win:'Striden är vunnen!',battle_loss:'Ditt lag besegrades',cup_complete:'Nybörjarkuppen är klar!',first_win_reward:'Stridsbelöning: 100 XP',cup_reward:'Belöningar: 1 000 XP och 10 rubiner',continue_battle:'Nästa strid',retry_cup:'Försök igen',back_cups:'Tillbaka till cuper',finish:'Avsluta',victory:'Seger!',defeat:'Förlust'},
  ru:{battle:'Битва',cups:'Кубки',starters_cup:'Кубок новичков',two_battles:'2 битвы',start_cup:'Начать кубок',choose_battle_cat:'Выберите кота',your_cat:'Ваш кот',enemy_cat:'Соперник',battle_number:'Битва {number} из 2',your_turn:'Ваш ход',enemy_turn:'Ход соперника',choose_attack:'Выберите атаку',scratch:'Царапина',bite:'Укус',earthquake:'Землетрясение',hay_bale:'Катящийся тюк сена',sandstorm:'Песчаная буря',hp:'ОЗ',fainted:'{cat} потерял сознание!',choose_next_cat:'Выберите следующего кота',no_battle_cats:'Для участия нужен Каменный кот. Купите его в горном магазине.',battle_win:'Битва выиграна!',battle_loss:'Ваша команда проиграла',cup_complete:'Кубок новичков пройден!',first_win_reward:'Награда за битву: 100 XP',cup_reward:'Награды: 1 000 XP и 10 рубинов',continue_battle:'Следующая битва',retry_cup:'Повторить',back_cups:'К кубкам',finish:'Завершить',victory:'Победа!',defeat:'Поражение'},
  zh:{battle:'对战',cups:'杯赛',starters_cup:'新手杯',two_battles:'2场对战',start_cup:'进入杯赛',choose_battle_cat:'选择你的猫',your_cat:'你的猫',enemy_cat:'对手',battle_number:'第 {number} 场，共 2 场',your_turn:'你的回合',enemy_turn:'对手回合',choose_attack:'选择攻击',scratch:'抓挠',bite:'咬击',earthquake:'地震',hay_bale:'滚动草捆',sandstorm:'沙尘暴',hp:'生命',fainted:'{cat}倒下了！',choose_next_cat:'选择下一只猫',no_battle_cats:'需要拥有岩石猫才能参赛。请前往山地商店购买。',battle_win:'赢得对战！',battle_loss:'你的队伍被击败了',cup_complete:'新手杯完成！',first_win_reward:'对战奖励：100 XP',cup_reward:'杯赛奖励：1,000 XP 和 10 颗红宝石',continue_battle:'下一场',retry_cup:'再试一次',back_cups:'返回杯赛',finish:'完成',victory:'胜利！',defeat:'失败'},
  ja:{battle:'バトル',cups:'カップ',starters_cup:'スターターカップ',two_battles:'2回のバトル',start_cup:'カップに参加',choose_battle_cat:'ネコを選ぶ',your_cat:'自分のネコ',enemy_cat:'相手',battle_number:'バトル {number} / 2',your_turn:'あなたの番',enemy_turn:'相手の番',choose_attack:'攻撃を選ぶ',scratch:'ひっかく',bite:'かみつく',earthquake:'地震',hay_bale:'転がる干し草',sandstorm:'砂嵐',hp:'HP',fainted:'{cat}は倒れた！',choose_next_cat:'次のネコを選ぶ',no_battle_cats:'参加するには岩ネコが必要です。山のショップで入手してください。',battle_win:'バトルに勝利！',battle_loss:'チームは倒されました',cup_complete:'スターターカップ制覇！',first_win_reward:'バトル報酬：100 XP',cup_reward:'カップ報酬：1,000 XP とルビー10個',continue_battle:'次のバトル',retry_cup:'もう一度',back_cups:'カップに戻る',finish:'終了',victory:'勝利！',defeat:'敗北'},
  ko:{battle:'배틀',cups:'컵',starters_cup:'스타터 컵',two_battles:'2번의 배틀',start_cup:'컵 참가',choose_battle_cat:'고양이 선택',your_cat:'내 고양이',enemy_cat:'상대',battle_number:'배틀 {number} / 2',your_turn:'내 차례',enemy_turn:'상대 차례',choose_attack:'공격 선택',scratch:'할퀴기',bite:'물기',earthquake:'지진',hay_bale:'굴러가는 건초 더미',sandstorm:'모래폭풍',hp:'HP',fainted:'{cat} 기절!',choose_next_cat:'다음 고양이 선택',no_battle_cats:'참가하려면 바위 고양이가 필요해요. 산 상점에서 구입하세요.',battle_win:'배틀 승리!',battle_loss:'팀이 패배했어요',cup_complete:'스타터 컵 완료!',first_win_reward:'배틀 보상: 100 XP',cup_reward:'컵 보상: 1,000 XP 및 루비 10개',continue_battle:'다음 배틀',retry_cup:'다시 도전',back_cups:'컵으로 돌아가기',finish:'완료',victory:'승리!',defeat:'패배'},
  ms:{battle:'Pertarungan',cups:'Piala',starters_cup:'Piala Pemula',two_battles:'2 pertarungan',start_cup:'Sertai piala',choose_battle_cat:'Pilih kucing anda',your_cat:'Kucing anda',enemy_cat:'Lawan',battle_number:'Pertarungan {number} daripada 2',your_turn:'Giliran anda',enemy_turn:'Giliran lawan',choose_attack:'Pilih serangan',scratch:'Cakaran',bite:'Gigitan',earthquake:'Gempa bumi',hay_bale:'Bebola jerami bergolek',sandstorm:'Ribut pasir',hp:'HP',fainted:'{cat} pengsan!',choose_next_cat:'Pilih kucing seterusnya',no_battle_cats:'Anda perlukan Kucing Batu untuk menyertai. Dapatkannya di kedai gunung.',battle_win:'Pertarungan dimenangi!',battle_loss:'Pasukan anda tewas',cup_complete:'Piala Pemula selesai!',first_win_reward:'Ganjaran pertarungan: 100 XP',cup_reward:'Ganjaran piala: 1,000 XP dan 10 delima',continue_battle:'Pertarungan seterusnya',retry_cup:'Cuba lagi',back_cups:'Kembali ke piala',finish:'Selesai',victory:'Menang!',defeat:'Kalah'},
  hi:{battle:'लड़ाई',cups:'कप',starters_cup:'शुरुआती कप',two_battles:'2 लड़ाइयाँ',start_cup:'कप में जाएँ',choose_battle_cat:'अपनी बिल्ली चुनें',your_cat:'आपकी बिल्ली',enemy_cat:'प्रतिद्वंद्वी',battle_number:'लड़ाई {number} / 2',your_turn:'आपकी बारी',enemy_turn:'प्रतिद्वंद्वी की बारी',choose_attack:'हमला चुनें',scratch:'खरोंच',bite:'काटना',earthquake:'भूकंप',hay_bale:'लुढ़कती घास की गठरी',sandstorm:'रेत का तूफ़ान',hp:'HP',fainted:'{cat} बेहोश हो गई!',choose_next_cat:'अगली बिल्ली चुनें',no_battle_cats:'इस कप में आने के लिए रॉकी कैट चाहिए। पहाड़ी दुकान से एक लें।',battle_win:'लड़ाई जीत गए!',battle_loss:'आपकी टीम हार गई',cup_complete:'शुरुआती कप पूरा हुआ!',first_win_reward:'लड़ाई का इनाम: 100 XP',cup_reward:'कप के इनाम: 1,000 XP और 10 माणिक',continue_battle:'अगली लड़ाई',retry_cup:'फिर कोशिश करें',back_cups:'कप पर लौटें',finish:'समाप्त',victory:'जीत!',defeat:'हार'}
};
const totemCupTranslations = {
  en:{totem_cup:'Totem Cup',totem_cup_complete:'Totem Cup complete!',totem_stage:'Stage {number} / 10',choose_two_cats_totem:'Choose 2 cats for Totem Cup',love_totem_reward:'Love Totem'},
  es:{totem_cup:'Copa del Tótem',totem_cup_complete:'¡Copa del Tótem completada!',totem_stage:'Fase {number} / 10',choose_two_cats_totem:'Elige 2 gatos para la Copa del Tótem',love_totem_reward:'Tótem del amor'},
  pt:{totem_cup:'Copa do Totem',totem_cup_complete:'Copa do Totem concluída!',totem_stage:'Fase {number} / 10',choose_two_cats_totem:'Escolha 2 gatos para a Copa do Totem',love_totem_reward:'Totem do Amor'},
  it:{totem_cup:'Coppa del Totem',totem_cup_complete:'Coppa del Totem completata!',totem_stage:'Fase {number} / 10',choose_two_cats_totem:'Scegli 2 gatti per la Coppa del Totem',love_totem_reward:'Totem dell’amore'},
  de:{totem_cup:'Totem-Pokal',totem_cup_complete:'Totem-Pokal abgeschlossen!',totem_stage:'Stufe {number} / 10',choose_two_cats_totem:'Wähle 2 Katzen für den Totem-Pokal',love_totem_reward:'Liebestotem'},
  nl:{totem_cup:'Totembeker',totem_cup_complete:'Totembeker voltooid!',totem_stage:'Fase {number} / 10',choose_two_cats_totem:'Kies 2 katten voor de Totembeker',love_totem_reward:'Liefdestotem'},
  sv:{totem_cup:'Totemcupen',totem_cup_complete:'Totemcupen är klar!',totem_stage:'Steg {number} / 10',choose_two_cats_totem:'Välj 2 katter till Totemcupen',love_totem_reward:'Kärlekstotem'},
  ru:{totem_cup:'Кубок тотема',totem_cup_complete:'Кубок тотема пройден!',totem_stage:'Этап {number} / 10',choose_two_cats_totem:'Выберите 2 котов для Кубка тотема',love_totem_reward:'Тотем любви'},
  zh:{totem_cup:'图腾杯',totem_cup_complete:'图腾杯已完成！',totem_stage:'第 {number} / 10 阶段',choose_two_cats_totem:'选择2只猫参加图腾杯',love_totem_reward:'爱之图腾'},
  ja:{totem_cup:'トーテムカップ',totem_cup_complete:'トーテムカップ制覇！',totem_stage:'ステージ {number} / 10',choose_two_cats_totem:'トーテムカップに参加するネコを2匹選択',love_totem_reward:'愛のトーテム'},
  ko:{totem_cup:'토템 컵',totem_cup_complete:'토템 컵 완료!',totem_stage:'스테이지 {number} / 10',choose_two_cats_totem:'토템 컵에 참가할 고양이 2마리를 선택하세요',love_totem_reward:'사랑의 토템'},
  ms:{totem_cup:'Piala Totem',totem_cup_complete:'Piala Totem selesai!',totem_stage:'Peringkat {number} / 10',choose_two_cats_totem:'Pilih 2 ekor kucing untuk Piala Totem',love_totem_reward:'Totem Cinta'},
  hi:{totem_cup:'टोटेम कप',totem_cup_complete:'टोटेम कप पूरा हुआ!',totem_stage:'10 में से चरण {number}',choose_two_cats_totem:'टोटेम कप के लिए 2 बिल्लियाँ चुनें',love_totem_reward:'प्रेम टोटेम'}
};
Object.entries(totemCupTranslations).forEach(([language, strings]) => Object.assign(battleText[language], strings));
const nextStageTranslations = {
  en:'Next stage',es:'Siguiente fase',pt:'Próxima fase',it:'Fase successiva',de:'Nächste Stufe',nl:'Volgende fase',sv:'Nästa steg',ru:'Следующий этап',zh:'下一阶段',ja:'次のステージ',ko:'다음 스테이지',ms:'Peringkat seterusnya',hi:'अगला चरण'
};
Object.entries(nextStageTranslations).forEach(([language, label]) => { battleText[language].next_stage = label; });
// New mountains belong here with their required player level and art.
const MOUNTAIN_CATALOG = [
  { id: 'metropolis', name: 'Mountainous Metropolis', image: 'uploads/Mountainous_Metropolis.png', unlockCup: true, catType: 'rocky', largeMap: true },
  { id: 'arid', name: 'Arid Mountain', image: 'uploads/Arid_mountain.png', element: 'Earth', elementImage: 'uploads/Earth_element.png', unlockLevel: 1, catType: 'rocky' },
  { id: 'burning', name: 'Burning Mountain', image: 'uploads/BurningMountain.png', element: 'Fire', elementImage: 'Fire element.png', unlockLevel: 1, catType: 'smokire' },
  { id: 'greenfields', name: 'Greenfields Mountain', image: 'uploads/Greenfields_Mountain_.png', element: 'Plant', elementImage: 'uploads/Plant_element_.png', unlockLevel: 1, catType: 'floralis' }
];
function isCatCompatibleWithMountain(type, mountainId) {
  const mountain = MOUNTAIN_CATALOG.find(item => item.id === mountainId);
  return Boolean(mountain && (!mountain.element || CAT_CATALOG[type]?.elements.includes(mountain.element)));
}
function compatibleMountainFor(type, preferredMountain) {
  if (isCatCompatibleWithMountain(type, preferredMountain)) return preferredMountain;
  return MOUNTAIN_CATALOG.find(mountain => mountain.element && isCatCompatibleWithMountain(type, mountain.id))?.id || 'metropolis';
}
const CAT_CATALOG = {
  rocky: { name: 'Rocky Cat', image: 'uploads/Rocky_Cat.png', elements: ['Cat','Earth'], hp: 123, price: 75, sell: 100, production: 10000, resource: 'silver', attacks: [{key:'scratch',damage:350,element:'uploads/Cat_element.png'},{key:'bite',damage:500,element:'uploads/Cat_element.png'},{key:'earthquake',damage:650,element:'uploads/Earth_element.png'},{key:'hay_bale',damage:500,element:'uploads/Earth_element.png'},{key:'sandstorm',damage:550,element:'uploads/Earth_element.png'}] },
  smokire: { name: 'Smokire', image: 'uploads/Smokire.png', elements: ['Cat','Fire'], hp: 129, price: 100, sell: 125, production: 9000, resource: 'silver', attacks: [{key:'scratch',nameKey:'jump_and_scratch',damage:400,element:'uploads/Cat_element.png'},{key:'bite',damage:500,element:'uploads/Cat_element.png'},{key:'spontaneous_combustion',nameKey:'spontaneous_combustion',damage:700,element:'Fire element.png'},{key:'magma_rocks',nameKey:'magma_rocks',damage:550,element:'Fire element.png'},{key:'heavy_burns',nameKey:'heavy_burns',damage:600,element:'Fire element.png'}] },
  volcanic_lava: { name: 'Volcanic Lava Cat', image: 'uploads/Volcanic_lava_cat.png', elements: ['Cat','Earth','Fire'], hp: 212, rarity: 'Moderate', rarityWeight: 2, sell: 200, rubyPrice: 5, production: 10000, resource: 'silver', descriptionKey: 'volcanic_description', shopDescriptionKey: 'volcanic_shop_description', attacks: [{nameKey:'take_fur_out',damage:450,element:'uploads/Cat_element.png'},{nameKey:'meteorite',damage:650,element:'uploads/Earth_element.png'},{nameKey:'rolling_hay_bale',damage:600,element:'uploads/Earth_element.png'},{key:'spontaneous_combustion',nameKey:'spontaneous_combustion',damage:700,element:'Fire element.png'},{nameKey:'lava_wave',damage:750,element:'Fire element.png'}] },
  floralis: { name: 'Floralis', image: 'uploads/Floralis.png', elements: ['Cat','Plant'], hp: 146, price: 150, sell: 175, production: 10000, resource: 'silver', descriptionKey: 'floralis_description', shopDescriptionKey: 'floralis_shop_description', attacks: [{key:'bite',damage:350,element:'uploads/Cat_element.png'},{nameKey:'take_fur_out',damage:450,element:'uploads/Cat_element.png'},{nameKey:'spiky_ivy',damage:500,element:'uploads/Plant_element_.png'},{nameKey:'poisonous_roots',damage:650,element:'uploads/Plant_element_.png'},{nameKey:'suffocate_in_leaves',damage:550,element:'uploads/Plant_element_.png'}] },
  florestalis: { name: 'Florestalis', image: 'uploads/Florestalis.png', elements: ['Cat','Plant','Earth'], hp: 229, rarity: 'Moderate', rarityWeight: 2, sell: 300, rubyPrice: 7, production: 10000, resource: 'silver', descriptionKey: 'florestalis_description', shopDescriptionKey: 'florestalis_short_description', attacks: [{key:'bite',damage:300,element:'uploads/Cat_element.png'},{nameKey:'magnitude_five_earthquake',damage:700,element:'uploads/Earth_element.png'},{nameKey:'rolling_hay_bale',damage:550,element:'uploads/Earth_element.png'},{nameKey:'spiky_ivy',damage:500,element:'uploads/Plant_element_.png'},{nameKey:'poisonous_roots',damage:650,element:'uploads/Plant_element_.png'}] }
};
Object.assign(translations.en, {
  hatcher_title:'Cube Hatcher', hatcher_empty:'No cubes waiting to hatch.',
  cube_rocky:'Rocky Cat Cube', cube_smokire:'Smokire Cube',
  cube_ready:'Ready to hatch!', cube_hatches_in:'Hatches in {duration}',
  hatch_with_rubies:'Hatch now · {cost} ruby', hatch_with_rubies_plural:'Hatch now · {cost} rubies',
  hatch_no_rubies:'Not enough rubies', cube_sent_to_hatcher:'Cube added to the Hatcher!',
  catalogue_title:'Cat Catalogue', catalogue_move:'Move Hatcher',
  stocks_title:'Feline Stocks', stocks_empty:'Empty slot', stocks_add:'Add cat', stocks_locked:'Unlock · 5 rubies',
  stocks_take_out:'Take out', stocks_no_cats:'No cats available to store.', stocks_choose:'Choose a cat to store',
  stocks_not_enough:'You need 5 rubies to unlock this space.', stocks_full:'All stock spaces are unlocked.',
  volcanic_lava_cat:'Volcanic Lava Cat', moderate:'Moderate',
  floralis_name:'Floralis', cube_floralis:'Floralis Cube', floralis_shop_description:'Calm, inoffensive to humans and has a great sense of humor.',
  floralis_description:"Small cats like to hop into this cat to relax and play games. Floralis is a calm fella, one that does not hurt and does not eat humans for absolutely no reason. It's surprising how such a big and bossy being to be so friendly (he also has a great sense of humor!)",
  spiky_ivy:'Spiky ivy', poisonous_roots:'Poisonous roots', suffocate_in_leaves:'Suffocate in leaves', plant:'Plant', greenfields_mountain:'Greenfields Mountain',
  volcanic_buy:'Buy for {price} rubies',
  volcanic_shop_description:'A very nice cat. Extremely hot and might get you a third degree burn.',
  volcanic_description:"He thinks he is super cool, because he has a stone hat and because he can cause a third degree burn in even the most fire-resistent cats. However, if you throw a bucket of water at him, he'll freeze in place and become stone! Fun, right? Not for him.",
  take_fur_out:'Take fur out', meteorite:'Meteorite', lava_wave:'Lava wave',
  mixer_first_cat:'First cat', mixer_second_cat:'Second cat', mixer_choose:'Choose a cat', mixer_none:'No cats to select yet.',
  mixer_mix:'Breed cats', mixer_need_two:'Choose two different cats first.', mixer_not_enough_rubies:'You need 5 rubies to buy this cat.',
  cube_volcanic_lava:'Volcanic Lava Cat Cube', breed_in_progress:'Breeding: {name} · {duration} left', choose_hatch_mountain:'Choose a mountain for your new cat', hatch_free:'Hatch', hatch_mountain_arid:'Arid Mountain', hatch_mountain_burning:'Burning Mountain',
  breed_started:'Breeding started · check back in {duration}'
});
// Cube Mixer and Hatcher interface copy is kept in every selectable language.
const cubeFeatureTranslations = {
  en:{hatcher_title:'Cube Hatcher',hatcher_empty:'No cubes waiting to hatch.',cube_rocky:'Rocky Cat Cube',cube_smokire:'Smokire Cube',cube_volcanic_lava:'Volcanic Lava Cat Cube',cube_ready:'Ready to hatch!',cube_hatches_in:'Hatches in {duration}',hatch_with_rubies:'Hatch now · {cost} ruby',hatch_with_rubies_plural:'Hatch now · {cost} rubies',hatch_no_rubies:'Not enough rubies',mixer_first_cat:'First cat',mixer_second_cat:'Second cat',mixer_choose:'Choose a cat',mixer_none:'No cats to select yet.',mixer_mix:'Breed cats · 10 minutes',mixer_need_two:'Choose two different cats first.',breed_in_progress:'Breeding: {name} · {duration} left',choose_hatch_mountain:'Choose a mountain for your new cat',hatch_free:'Hatch',hatch_mountain_arid:'Arid Mountain',hatch_mountain_burning:'Burning Mountain',breed_started:'Breeding started · check back in 10 minutes'},
  es:{hatcher_title:'Incubadora de cubos',hatcher_empty:'No hay cubos esperando para eclosionar.',cube_rocky:'Cubo de Gato Rocoso',cube_smokire:'Cubo de Smokire',cube_volcanic_lava:'Cubo de Gato de Lava Volcánica',cube_ready:'¡Listo para eclosionar!',cube_hatches_in:'Eclosiona en {duration}',hatch_with_rubies:'Eclosionar ahora · {cost} rubí',hatch_with_rubies_plural:'Eclosionar ahora · {cost} rubíes',hatch_no_rubies:'No tienes suficientes rubíes',mixer_first_cat:'Primer gato',mixer_second_cat:'Segundo gato',mixer_choose:'Elige un gato',mixer_none:'Aún no hay gatos para elegir.',mixer_mix:'Criar gatos · 10 minutos',mixer_need_two:'Elige primero dos gatos diferentes.',breed_in_progress:'En crianza: {name} · quedan {duration}',choose_hatch_mountain:'Elige una montaña para tu nuevo gato',hatch_free:'Eclosionar',hatch_mountain_arid:'Montaña Árida',hatch_mountain_burning:'Montaña Ardiente',breed_started:'La crianza ha comenzado · vuelve en 10 minutos'},
  pt:{hatcher_title:'Chocadeira de Cubos',hatcher_empty:'Não há cubos esperando para chocar.',cube_rocky:'Cubo do Gato Rochoso',cube_smokire:'Cubo de Smokire',cube_volcanic_lava:'Cubo do Gato de Lava Vulcânica',cube_ready:'Pronto para chocar!',cube_hatches_in:'Choca em {duration}',hatch_with_rubies:'Chocar agora · {cost} rubi',hatch_with_rubies_plural:'Chocar agora · {cost} rubis',hatch_no_rubies:'Rubis insuficientes',mixer_first_cat:'Primeiro gato',mixer_second_cat:'Segundo gato',mixer_choose:'Escolha um gato',mixer_none:'Ainda não há gatos para escolher.',mixer_mix:'Cruzar gatos · 10 minutos',mixer_need_two:'Escolha dois gatos diferentes primeiro.',breed_in_progress:'Cruzamento: {name} · faltam {duration}',choose_hatch_mountain:'Escolha uma montanha para seu novo gato',hatch_free:'Chocar',hatch_mountain_arid:'Montanha Árida',hatch_mountain_burning:'Montanha Ardente',breed_started:'Cruzamento iniciado · volte em 10 minutos'},
  it:{hatcher_title:'Incubatrice di cubi',hatcher_empty:'Nessun cubo in attesa di schiudersi.',cube_rocky:'Cubo del Gatto Roccioso',cube_smokire:'Cubo di Smokire',cube_volcanic_lava:'Cubo del Gatto di Lava Vulcanica',cube_ready:'Pronto a schiudersi!',cube_hatches_in:'Si schiude tra {duration}',hatch_with_rubies:'Schiudi ora · {cost} rubino',hatch_with_rubies_plural:'Schiudi ora · {cost} rubini',hatch_no_rubies:'Rubini insufficienti',mixer_first_cat:'Primo gatto',mixer_second_cat:'Secondo gatto',mixer_choose:'Scegli un gatto',mixer_none:'Non ci sono ancora gatti da scegliere.',mixer_mix:'Accoppia i gatti · 10 minuti',mixer_need_two:'Scegli prima due gatti diversi.',breed_in_progress:'Accoppiamento: {name} · mancano {duration}',choose_hatch_mountain:'Scegli una montagna per il nuovo gatto',hatch_free:'Schiudi',hatch_mountain_arid:'Montagna Arida',hatch_mountain_burning:'Montagna Ardente',breed_started:'Accoppiamento avviato · torna tra 10 minuti'},
  de:{hatcher_title:'Würfel-Brutkasten',hatcher_empty:'Keine Würfel warten aufs Schlüpfen.',cube_rocky:'Würfel der Felskatze',cube_smokire:'Smokire-Würfel',cube_volcanic_lava:'Würfel der Vulkan-Lavakatze',cube_ready:'Schlüpfbereit!',cube_hatches_in:'Schlüpft in {duration}',hatch_with_rubies:'Jetzt schlüpfen · {cost} Rubin',hatch_with_rubies_plural:'Jetzt schlüpfen · {cost} Rubine',hatch_no_rubies:'Nicht genug Rubine',mixer_first_cat:'Erste Katze',mixer_second_cat:'Zweite Katze',mixer_choose:'Katze auswählen',mixer_none:'Noch keine Katzen zur Auswahl.',mixer_mix:'Katzen züchten · 10 Minuten',mixer_need_two:'Wähle zuerst zwei verschiedene Katzen.',breed_in_progress:'Zucht: {name} · noch {duration}',choose_hatch_mountain:'Wähle einen Berg für deine neue Katze',hatch_free:'Schlüpfen',hatch_mountain_arid:'Arider Berg',hatch_mountain_burning:'Brennender Berg',breed_started:'Zucht gestartet · schau in 10 Minuten wieder vorbei'},
  nl:{hatcher_title:'Kubusbroedmachine',hatcher_empty:'Er wachten geen kubussen om uit te komen.',cube_rocky:'Kubus van de Rotskat',cube_smokire:'Smokire-kubus',cube_volcanic_lava:'Kubus van de Vulkanische Lavakat',cube_ready:'Klaar om uit te komen!',cube_hatches_in:'Komt uit over {duration}',hatch_with_rubies:'Nu uitbroeden · {cost} robijn',hatch_with_rubies_plural:'Nu uitbroeden · {cost} robijnen',hatch_no_rubies:'Niet genoeg robijnen',mixer_first_cat:'Eerste kat',mixer_second_cat:'Tweede kat',mixer_choose:'Kies een kat',mixer_none:'Er zijn nog geen katten om te kiezen.',mixer_mix:'Katten fokken · 10 minuten',mixer_need_two:'Kies eerst twee verschillende katten.',breed_in_progress:'Aan het fokken: {name} · nog {duration}',choose_hatch_mountain:'Kies een berg voor je nieuwe kat',hatch_free:'Uitbroeden',hatch_mountain_arid:'Droge Berg',hatch_mountain_burning:'Brandende Berg',breed_started:'Het fokken is begonnen · kom over 10 minuten terug'},
  sv:{hatcher_title:'Kubkläckare',hatcher_empty:'Inga kuber väntar på att kläckas.',cube_rocky:'Stenkattens kub',cube_smokire:'Smokire-kub',cube_volcanic_lava:'Vulkaniska lavakattens kub',cube_ready:'Klar att kläckas!',cube_hatches_in:'Kläcks om {duration}',hatch_with_rubies:'Kläck nu · {cost} rubin',hatch_with_rubies_plural:'Kläck nu · {cost} rubiner',hatch_no_rubies:'Du har inte tillräckligt med rubiner',mixer_first_cat:'Första katten',mixer_second_cat:'Andra katten',mixer_choose:'Välj en katt',mixer_none:'Det finns inga katter att välja ännu.',mixer_mix:'Avla katter · 10 minuter',mixer_need_two:'Välj först två olika katter.',breed_in_progress:'Avel: {name} · {duration} kvar',choose_hatch_mountain:'Välj ett berg för din nya katt',hatch_free:'Kläck',hatch_mountain_arid:'Torra berget',hatch_mountain_burning:'Brinnande berget',breed_started:'Aveln har börjat · kom tillbaka om 10 minuter'},
  ru:{hatcher_title:'Инкубатор кубов',hatcher_empty:'Нет кубов, ожидающих вылупления.',cube_rocky:'Куб Каменного кота',cube_smokire:'Куб Smokire',cube_volcanic_lava:'Куб Вулканического лавового кота',cube_ready:'Готов к вылуплению!',cube_hatches_in:'Вылупится через {duration}',hatch_with_rubies:'Вылупить сейчас · {cost} рубин',hatch_with_rubies_plural:'Вылупить сейчас · {cost} руб.',hatch_no_rubies:'Недостаточно рубинов',mixer_first_cat:'Первый кот',mixer_second_cat:'Второй кот',mixer_choose:'Выберите кота',mixer_none:'Пока нет котов для выбора.',mixer_mix:'Скрестить котов · 10 минут',mixer_need_two:'Сначала выберите двух разных котов.',breed_in_progress:'Скрещивание: {name} · осталось {duration}',choose_hatch_mountain:'Выберите гору для нового кота',hatch_free:'Вылупить',hatch_mountain_arid:'Засушливая гора',hatch_mountain_burning:'Пылающая гора',breed_started:'Скрещивание началось · возвращайтесь через 10 минут'},
  zh:{hatcher_title:'方块孵化器',hatcher_empty:'没有等待孵化的方块。',cube_rocky:'岩石猫方块',cube_smokire:'Smokire方块',cube_volcanic_lava:'火山熔岩猫方块',cube_ready:'可以孵化了！',cube_hatches_in:'将在 {duration} 后孵化',hatch_with_rubies:'立即孵化 · {cost} 颗红宝石',hatch_with_rubies_plural:'立即孵化 · {cost} 颗红宝石',hatch_no_rubies:'红宝石不足',mixer_first_cat:'第一只猫',mixer_second_cat:'第二只猫',mixer_choose:'选择一只猫',mixer_none:'目前没有可选的猫。',mixer_mix:'繁育猫咪 · 10分钟',mixer_need_two:'请先选择两只不同的猫。',breed_in_progress:'正在繁育：{name} · 还需 {duration}',choose_hatch_mountain:'为新猫选择一座山',hatch_free:'孵化',hatch_mountain_arid:'干旱之山',hatch_mountain_burning:'燃烧之山',breed_started:'繁育已开始 · 10分钟后再来'},
  ja:{hatcher_title:'キューブ孵化器',hatcher_empty:'孵化を待つキューブはありません。',cube_rocky:'ロッキーキャットのキューブ',cube_smokire:'Smokireのキューブ',cube_volcanic_lava:'火山ラバキャットのキューブ',cube_ready:'孵化できます！',cube_hatches_in:'孵化まで {duration}',hatch_with_rubies:'今すぐ孵化 · ルビー{cost}個',hatch_with_rubies_plural:'今すぐ孵化 · ルビー{cost}個',hatch_no_rubies:'ルビーが足りません',mixer_first_cat:'1匹目のネコ',mixer_second_cat:'2匹目のネコ',mixer_choose:'ネコを選択',mixer_none:'選択できるネコはまだいません。',mixer_mix:'ネコを繁殖 · 10分',mixer_need_two:'異なるネコを2匹選んでください。',breed_in_progress:'繁殖中：{name} · 残り {duration}',choose_hatch_mountain:'新しいネコを置く山を選んでください',hatch_free:'孵化',hatch_mountain_arid:'乾燥した山',hatch_mountain_burning:'燃える山',breed_started:'繁殖を開始しました · 10分後に確認してください'},
  ko:{hatcher_title:'큐브 부화기',hatcher_empty:'부화를 기다리는 큐브가 없어요.',cube_rocky:'록키 캣 큐브',cube_smokire:'Smokire 큐브',cube_volcanic_lava:'화산 용암 고양이 큐브',cube_ready:'부화할 준비가 됐어요!',cube_hatches_in:'{duration} 후 부화',hatch_with_rubies:'지금 부화 · 루비 {cost}개',hatch_with_rubies_plural:'지금 부화 · 루비 {cost}개',hatch_no_rubies:'루비가 부족해요',mixer_first_cat:'첫 번째 고양이',mixer_second_cat:'두 번째 고양이',mixer_choose:'고양이를 선택하세요',mixer_none:'아직 선택할 고양이가 없어요.',mixer_mix:'고양이 번식 · 10분',mixer_need_two:'서로 다른 고양이 두 마리를 먼저 선택하세요.',breed_in_progress:'번식 중: {name} · {duration} 남음',choose_hatch_mountain:'새 고양이를 둘 산을 선택하세요',hatch_free:'부화',hatch_mountain_arid:'건조한 산',hatch_mountain_burning:'불타는 산',breed_started:'번식이 시작됐어요 · 10분 후에 확인하세요'},
  ms:{hatcher_title:'Penetas Kiub',hatcher_empty:'Tiada kiub yang menunggu untuk menetas.',cube_rocky:'Kiub Kucing Batu',cube_smokire:'Kiub Smokire',cube_volcanic_lava:'Kiub Kucing Lava Gunung Berapi',cube_ready:'Sedia untuk menetas!',cube_hatches_in:'Menetas dalam {duration}',hatch_with_rubies:'Tetaskan sekarang · {cost} delima',hatch_with_rubies_plural:'Tetaskan sekarang · {cost} delima',hatch_no_rubies:'Delima tidak mencukupi',mixer_first_cat:'Kucing pertama',mixer_second_cat:'Kucing kedua',mixer_choose:'Pilih kucing',mixer_none:'Belum ada kucing untuk dipilih.',mixer_mix:'Biak kucing · 10 minit',mixer_need_two:'Pilih dua ekor kucing yang berbeza dahulu.',breed_in_progress:'Sedang membiak: {name} · baki {duration}',choose_hatch_mountain:'Pilih gunung untuk kucing baharu anda',hatch_free:'Tetaskan',hatch_mountain_arid:'Gunung Gersang',hatch_mountain_burning:'Gunung Membara',breed_started:'Pembiakan bermula · kembali dalam 10 minit'},
  hi:{hatcher_title:'क्यूब हैचर',hatcher_empty:'अंडे से निकलने के लिए कोई क्यूब इंतज़ार नहीं कर रहा।',cube_rocky:'रॉकी कैट क्यूब',cube_smokire:'Smokire क्यूब',cube_volcanic_lava:'ज्वालामुखी लावा कैट क्यूब',cube_ready:'अंडे से निकलने के लिए तैयार!',cube_hatches_in:'{duration} में अंडे से निकलेगा',hatch_with_rubies:'अभी निकालें · {cost} माणिक',hatch_with_rubies_plural:'अभी निकालें · {cost} माणिक',hatch_no_rubies:'पर्याप्त माणिक नहीं हैं',mixer_first_cat:'पहली बिल्ली',mixer_second_cat:'दूसरी बिल्ली',mixer_choose:'एक बिल्ली चुनें',mixer_none:'अभी चुनने के लिए कोई बिल्ली नहीं है।',mixer_mix:'बिल्लियों का प्रजनन · 10 मिनट',mixer_need_two:'पहले दो अलग-अलग बिल्लियाँ चुनें।',breed_in_progress:'प्रजनन जारी: {name} · {duration} बाकी',choose_hatch_mountain:'अपनी नई बिल्ली के लिए पर्वत चुनें',hatch_free:'अंडे से निकालें',hatch_mountain_arid:'शुष्क पर्वत',hatch_mountain_burning:'जलता हुआ पर्वत',breed_started:'प्रजनन शुरू हुआ · 10 मिनट बाद वापस आएँ'}
};
Object.entries(cubeFeatureTranslations).forEach(([language, strings]) => Object.assign(interfaceTranslations[language], strings));
const addedCatTranslations = {
  en:{volcanic_lava_cat:'Volcanic Lava Cat',moderate:'Moderate',volcanic_buy:'Buy for {price} rubies',volcanic_shop_description:'A very nice cat. Extremely hot and might get you a third degree burn.',volcanic_description:"He thinks he is super cool, because he has a stone hat and because he can cause a third degree burn in even the most fire-resistent cats. However, if you throw a bucket of water at him, he'll freeze in place and become stone! Fun, right? Not for him.",take_fur_out:'Take fur out',meteorite:'Meteorite',rolling_hay_bale:'Rolling hay bale',lava_wave:'Lava wave',hatcher_move:'Move Hatcher',hatch_cancel:'Cancel mountain choice'},
  es:{volcanic_lava_cat:'Gato de Lava Volcánica',moderate:'Moderada',volcanic_buy:'Comprar por {price} rubíes',volcanic_shop_description:'Un gato muy simpático. Está extremadamente caliente y podría causarte quemaduras de tercer grado.',volcanic_description:'Cree que es genial porque lleva un sombrero de piedra y puede causar quemaduras de tercer grado incluso a los gatos más resistentes al fuego. Pero si le lanzas un cubo de agua, se congelará y se convertirá en piedra. ¡Divertido, ¿verdad? Para él no.',take_fur_out:'Arrancarle el pelo',meteorite:'Meteorito',rolling_hay_bale:'Rueda de heno',lava_wave:'Ola de lava',hatcher_move:'Mover incubadora',hatch_cancel:'Cancelar elección de montaña'},
  pt:{volcanic_lava_cat:'Gato de Lava Vulcânica',moderate:'Moderada',volcanic_buy:'Comprar por {price} rubis',volcanic_shop_description:'Um gato muito simpático. É extremamente quente e pode causar queimaduras de terceiro grau.',volcanic_description:'Ele se acha superlegal porque usa um chapéu de pedra e consegue causar queimaduras de terceiro grau até nos gatos mais resistentes ao fogo. Mas, se você jogar um balde de água nele, ficará congelado no lugar e virará pedra! Divertido, né? Para ele, não.',take_fur_out:'Arrancar pelos',meteorite:'Meteorito',rolling_hay_bale:'Fardo de feno rolante',lava_wave:'Onda de lava',hatcher_move:'Mover chocadeira',hatch_cancel:'Cancelar escolha da montanha'},
  it:{volcanic_lava_cat:'Gatto di Lava Vulcanica',moderate:'Moderata',volcanic_buy:'Compra per {price} rubini',volcanic_shop_description:'Un gatto molto simpatico. È caldissimo e potrebbe causarti ustioni di terzo grado.',volcanic_description:'Pensa di essere fortissimo perché porta un cappello di pietra e può causare ustioni di terzo grado anche ai gatti più resistenti al fuoco. Però, se gli lanci un secchio d’acqua, si bloccherà e diventerà pietra! Divertente, vero? Per lui no.',take_fur_out:'Strappare il pelo',meteorite:'Meteorite',rolling_hay_bale:'Balla di fieno rotolante',lava_wave:'Onda di lava',hatcher_move:'Sposta incubatrice',hatch_cancel:'Annulla scelta della montagna'},
  de:{volcanic_lava_cat:'Vulkan-Lavakatze',moderate:'Mittel',volcanic_buy:'Für {price} Rubine kaufen',volcanic_shop_description:'Eine sehr nette Katze. Sie ist extrem heiß und kann Verbrennungen dritten Grades verursachen.',volcanic_description:'Sie hält sich für supercool, weil sie einen Steinhut trägt und selbst feuerfesten Katzen Verbrennungen dritten Grades zufügen kann. Wirfst du jedoch einen Eimer Wasser auf sie, erstarrt sie und wird zu Stein! Lustig, oder? Für sie nicht.',take_fur_out:'Fell herausziehen',meteorite:'Meteorit',rolling_hay_bale:'Rollender Heuballen',lava_wave:'Lavawelle',hatcher_move:'Brutkasten verschieben',hatch_cancel:'Bergwahl abbrechen'},
  nl:{volcanic_lava_cat:'Vulkanische Lavakat',moderate:'Gemiddeld',volcanic_buy:'Kopen voor {price} robijnen',volcanic_shop_description:'Een heel aardige kat. Hij is ontzettend heet en kan je derdegraadsbrandwonden bezorgen.',volcanic_description:'Hij vindt zichzelf supercool omdat hij een stenen hoed draagt en zelfs de meest vuurvaste katten derdegraadsbrandwonden kan bezorgen. Maar als je een emmer water naar hem gooit, bevriest hij en verandert hij in steen! Leuk, hè? Voor hem niet.',take_fur_out:'Vacht uittrekken',meteorite:'Meteoriet',rolling_hay_bale:'Rollende hooibaal',lava_wave:'Lavagolf',hatcher_move:'Broedmachine verplaatsen',hatch_cancel:'Bergkeuze annuleren'},
  sv:{volcanic_lava_cat:'Vulkanisk lavakatt',moderate:'Måttlig',volcanic_buy:'Köp för {price} rubiner',volcanic_shop_description:'En väldigt trevlig katt. Den är extremt het och kan ge dig tredje gradens brännskador.',volcanic_description:'Den tycker att den är supercool eftersom den har en stenhatt och kan ge även de mest eldtåliga katterna tredje gradens brännskador. Men om du kastar en hink vatten på den fryser den fast och blir till sten! Kul, eller hur? Inte för den.',take_fur_out:'Dra ut päls',meteorite:'Meteorit',rolling_hay_bale:'Rullande höbal',lava_wave:'Lavavåg',hatcher_move:'Flytta kubkläckaren',hatch_cancel:'Avbryt bergsval'},
  ru:{volcanic_lava_cat:'Вулканический лавовый кот',moderate:'Средняя',volcanic_buy:'Купить за {price} рубинов',volcanic_shop_description:'Очень милый кот. Он невероятно горячий и может оставить ожог третьей степени.',volcanic_description:'Он считает себя очень крутым из-за каменной шляпы и способности оставлять ожоги третьей степени даже у самых огнестойких котов. Но если вы выльете на него ведро воды, он застынет и превратится в камень! Забавно, правда? Для него — нет.',take_fur_out:'Выдрать шерсть',meteorite:'Метеорит',rolling_hay_bale:'Катящийся тюк сена',lava_wave:'Лавовая волна',hatcher_move:'Переместить инкубатор',hatch_cancel:'Отменить выбор горы'},
  zh:{volcanic_lava_cat:'火山熔岩猫',moderate:'中等',volcanic_buy:'花费 {price} 颗红宝石购买',volcanic_shop_description:'一只非常友好的猫。它热得惊人，可能会让你遭受三级烧伤。',volcanic_description:'它觉得自己很酷，因为它戴着石头帽子，还能让最耐火的猫也遭受三级烧伤。不过，如果你朝它泼一桶水，它就会僵住并变成石头！很有趣，对吧？对它来说可不是。',take_fur_out:'拔毛',meteorite:'陨石',rolling_hay_bale:'滚动的干草捆',lava_wave:'熔岩浪潮',hatcher_move:'移动孵化器',hatch_cancel:'取消山脉选择'},
  ja:{volcanic_lava_cat:'火山ラバキャット',moderate:'中程度',volcanic_buy:'ルビー{price}個で購入',volcanic_shop_description:'とても感じのよいネコ。ものすごく熱く、三度のやけどを負わせるかもしれません。',volcanic_description:'石の帽子をかぶり、火に強いネコにさえ三度のやけどを負わせられるので、自分は最高にクールだと思っています。でもバケツの水をかけると、その場で凍りついて石になってしまいます！面白いでしょう？本人はそう思っていません。',take_fur_out:'毛をむしる',meteorite:'隕石',rolling_hay_bale:'転がる干し草の束',lava_wave:'溶岩の波',hatcher_move:'孵化器を移動',hatch_cancel:'山の選択をキャンセル'},
  ko:{volcanic_lava_cat:'화산 용암 고양이',moderate:'보통',volcanic_buy:'루비 {price}개로 구매',volcanic_shop_description:'아주 친근한 고양이예요. 엄청나게 뜨거워서 3도 화상을 입힐 수도 있어요.',volcanic_description:'돌 모자를 쓰고 있고 불에 가장 강한 고양이에게도 3도 화상을 입힐 수 있어서 자신이 아주 멋지다고 생각해요. 하지만 물 한 양동이를 끼얹으면 그 자리에서 얼어 돌이 되어 버려요! 재미있죠? 본인에게는 아니지만요.',take_fur_out:'털 뽑기',meteorite:'운석',rolling_hay_bale:'굴러가는 건초 더미',lava_wave:'용암 파도',hatcher_move:'큐브 부화기 이동',hatch_cancel:'산 선택 취소'},
  ms:{volcanic_lava_cat:'Kucing Lava Gunung Berapi',moderate:'Sederhana',volcanic_buy:'Beli dengan {price} delima',volcanic_shop_description:'Kucing yang sangat baik. Ia amat panas dan boleh menyebabkan lecuran tahap ketiga.',volcanic_description:'Ia fikir dirinya sangat hebat kerana memakai topi batu dan boleh menyebabkan lecuran tahap ketiga walaupun pada kucing yang paling tahan api. Namun, jika anda mencurahkan sebaldi air kepadanya, ia akan kaku dan menjadi batu! Menarik, bukan? Bukan baginya.',take_fur_out:'Cabut bulu',meteorite:'Meteorit',rolling_hay_bale:'Bebola jerami bergolek',lava_wave:'Ombak lava',hatcher_move:'Pindahkan penetas kiub',hatch_cancel:'Batalkan pilihan gunung'},
  hi:{volcanic_lava_cat:'ज्वालामुखी लावा बिल्ली',moderate:'मध्यम',volcanic_buy:'{price} माणिक में खरीदें',volcanic_shop_description:'यह बहुत प्यारी बिल्ली है। यह बेहद गर्म है और आपको तीसरी डिग्री का जला सकती है।',volcanic_description:'उसे लगता है कि वह बहुत शानदार है क्योंकि उसके पास पत्थर की टोपी है और वह आग से सबसे अधिक सुरक्षित बिल्लियों को भी तीसरी डिग्री का जला सकता है। लेकिन अगर उस पर एक बाल्टी पानी डालो, तो वह वहीं जमकर पत्थर बन जाएगा! मज़ेदार है, है ना? उसके लिए नहीं।',take_fur_out:'रोएँ खींचना',meteorite:'उल्कापिंड',rolling_hay_bale:'लुढ़कता हुआ घास का गट्ठर',lava_wave:'लावा की लहर',hatcher_move:'क्यूब हैचर हटाएँ',hatch_cancel:'पर्वत चयन रद्द करें'}
};
Object.entries(addedCatTranslations).forEach(([language, strings]) => Object.assign(interfaceTranslations[language], strings));
const featureCloseLabels = {
  en:{hatcher_close:'Close Hatcher',mixer_close:'Close Cube Mixer'},es:{hatcher_close:'Cerrar incubadora',mixer_close:'Cerrar mezclador de cubos'},pt:{hatcher_close:'Fechar chocadeira',mixer_close:'Fechar misturador de cubos'},it:{hatcher_close:'Chiudi incubatrice',mixer_close:'Chiudi miscelatore di cubi'},de:{hatcher_close:'Brutkasten schließen',mixer_close:'Würfelmischer schließen'},nl:{hatcher_close:'Broedmachine sluiten',mixer_close:'Kubusmenger sluiten'},sv:{hatcher_close:'Stäng kubkläckaren',mixer_close:'Stäng kubblandaren'},ru:{hatcher_close:'Закрыть инкубатор',mixer_close:'Закрыть кубический смеситель'},zh:{hatcher_close:'关闭孵化器',mixer_close:'关闭方块混合器'},ja:{hatcher_close:'孵化器を閉じる',mixer_close:'キューブミキサーを閉じる'},ko:{hatcher_close:'부화기 닫기',mixer_close:'큐브 믹서 닫기'},ms:{hatcher_close:'Tutup penetas kiub',mixer_close:'Tutup pengadun kiub'},hi:{hatcher_close:'क्यूब हैचर बंद करें',mixer_close:'क्यूब मिक्सर बंद करें'}
};
Object.entries(featureCloseLabels).forEach(([language, strings]) => Object.assign(interfaceTranslations[language], strings));
const breedSpeedTranslations = {
  en:{breed_speed_up:'Speed up · 1 ruby',breed_speed_success:'Breeding finished! Cube sent to the Hatcher.'},
  es:{breed_speed_up:'Acelerar · 1 rubí',breed_speed_success:'¡La crianza terminó! El cubo está en la incubadora.'},
  pt:{breed_speed_up:'Acelerar · 1 rubi',breed_speed_success:'Cruzamento concluído! O cubo está na chocadeira.'},
  it:{breed_speed_up:'Accelera · 1 rubino',breed_speed_success:'Accoppiamento completato! Il cubo è nell’incubatrice.'},
  de:{breed_speed_up:'Beschleunigen · 1 Rubin',breed_speed_success:'Zucht abgeschlossen! Der Würfel ist im Brutkasten.'},
  nl:{breed_speed_up:'Versnellen · 1 robijn',breed_speed_success:'Het fokken is klaar! De kubus staat in de broedmachine.'},
  sv:{breed_speed_up:'Snabba på · 1 rubin',breed_speed_success:'Aveln är klar! Kuben finns i kubkläckaren.'},
  ru:{breed_speed_up:'Ускорить · 1 рубин',breed_speed_success:'Скрещивание завершено! Куб помещён в инкубатор.'},
  zh:{breed_speed_up:'立即完成 · 1颗红宝石',breed_speed_success:'繁育完成！方块已放入孵化器。'},
  ja:{breed_speed_up:'早める · ルビー1個',breed_speed_success:'繁殖が完了しました！キューブは孵化器に入りました。'},
  ko:{breed_speed_up:'속도 높이기 · 루비 1개',breed_speed_success:'번식이 완료됐어요! 큐브가 부화기에 들어갔어요.'},
  ms:{breed_speed_up:'Percepatkan · 1 delima',breed_speed_success:'Pembiakan selesai! Kiub telah dimasukkan ke dalam penetas.'},
  hi:{breed_speed_up:'तेज़ करें · 1 माणिक',breed_speed_success:'प्रजनन पूरा हुआ! क्यूब हैचर में रख दिया गया है।'}
};
Object.entries(breedSpeedTranslations).forEach(([language, strings]) => Object.assign(interfaceTranslations[language], strings));
const breedDurationLabels = {
  en:{mixer_mix:'Breed cats',mixer_mix_duration:'Breed cats · {duration}',breed_started:'Breeding started · check back in {duration}'},
  es:{mixer_mix:'Criar gatos',mixer_mix_duration:'Criar gatos · {duration}',breed_started:'La crianza ha comenzado · vuelve en {duration}'},
  pt:{mixer_mix:'Cruzar gatos',mixer_mix_duration:'Cruzar gatos · {duration}',breed_started:'Cruzamento iniciado · volte em {duration}'},
  it:{mixer_mix:'Accoppia i gatti',mixer_mix_duration:'Accoppia i gatti · {duration}',breed_started:'Accoppiamento avviato · torna tra {duration}'},
  de:{mixer_mix:'Katzen züchten',mixer_mix_duration:'Katzen züchten · {duration}',breed_started:'Zucht gestartet · schau in {duration} wieder vorbei'},
  nl:{mixer_mix:'Katten fokken',mixer_mix_duration:'Katten fokken · {duration}',breed_started:'Het fokken is begonnen · kom over {duration} terug'},
  sv:{mixer_mix:'Avla katter',mixer_mix_duration:'Avla katter · {duration}',breed_started:'Aveln har börjat · kom tillbaka om {duration}'},
  ru:{mixer_mix:'Скрестить котов',mixer_mix_duration:'Скрестить котов · {duration}',breed_started:'Скрещивание началось · возвращайтесь через {duration}'},
  zh:{mixer_mix:'繁育猫咪',mixer_mix_duration:'繁育猫咪 · {duration}',breed_started:'繁育已开始 · {duration}后再来'},
  ja:{mixer_mix:'ネコを繁殖',mixer_mix_duration:'ネコを繁殖 · {duration}',breed_started:'繁殖を開始しました · {duration}後に確認してください'},
  ko:{mixer_mix:'고양이 번식',mixer_mix_duration:'고양이 번식 · {duration}',breed_started:'번식이 시작됐어요 · {duration} 후에 확인하세요'},
  ms:{mixer_mix:'Biak kucing',mixer_mix_duration:'Biak kucing · {duration}',breed_started:'Pembiakan bermula · kembali dalam {duration}'},
  hi:{mixer_mix:'बिल्लियों का प्रजनन',mixer_mix_duration:'बिल्लियों का प्रजनन · {duration}',breed_started:'प्रजनन शुरू हुआ · {duration} बाद वापस आएँ'}
};
Object.entries(breedDurationLabels).forEach(([language, strings]) => Object.assign(interfaceTranslations[language], strings));
const additionalTranslations = {
  en:{catalogue_title:'Cat Catalogue',close_catalogue:'Close cat catalogue',greenfields_mountain:'Greenfields Mountain',love_totem:'Love Totem',love_totem_description:'Boosts every cat HP by 15% and gives breeding a chance to produce rarer cats without all their elements.',love_totem_ready:'Earned · ready to place',place_love_totem:'Place Love Totem'},
  es:{catalogue_title:'Catálogo de gatos',close_catalogue:'Cerrar catálogo de gatos',greenfields_mountain:'Montaña Campos Verdes',love_totem:'Tótem del amor',love_totem_description:'Aumenta un 15 % la salud de todos tus gatos y permite que la crianza produzca gatos más raros sin todos sus elementos.',love_totem_ready:'Conseguido · listo para colocar',place_love_totem:'Colocar el tótem del amor'},
  pt:{catalogue_title:'Catálogo de Gatos',close_catalogue:'Fechar catálogo de gatos',greenfields_mountain:'Montanha Campos Verdes',love_totem:'Totem do Amor',love_totem_description:'Aumenta em 15% a vida de todos os gatos e dá à reprodução uma chance de gerar gatos mais raros sem todos os elementos.',love_totem_ready:'Conquistado · pronto para colocar',place_love_totem:'Colocar o Totem do Amor'},
  it:{catalogue_title:'Catalogo dei gatti',close_catalogue:'Chiudi il catalogo dei gatti',greenfields_mountain:'Montagna dei Campi Verdi',love_totem:'Totem dell’amore',love_totem_description:'Aumenta del 15% la salute di tutti i gatti e dà alla riproduzione la possibilità di generare gatti più rari senza tutti i loro elementi.',love_totem_ready:'Ottenuto · pronto da posizionare',place_love_totem:'Posiziona il totem dell’amore'},
  de:{catalogue_title:'Katzenkatalog',close_catalogue:'Katzenkatalog schließen',greenfields_mountain:'Grüne-Felder-Berg',love_totem:'Liebestotem',love_totem_description:'Erhöht die Gesundheit aller Katzen um 15 % und gibt der Zucht die Chance, seltenere Katzen ohne alle ihre Elemente hervorzubringen.',love_totem_ready:'Erhalten · bereit zum Aufstellen',place_love_totem:'Liebestotem aufstellen'},
  nl:{catalogue_title:'Kattencatalogus',close_catalogue:'Kattencatalogus sluiten',greenfields_mountain:'Groene Velden Berg',love_totem:'Liefdestotem',love_totem_description:'Verhoogt de gezondheid van al je katten met 15% en geeft de fokkerij kans op zeldzamere katten zonder al hun elementen.',love_totem_ready:'Verdiend · klaar om te plaatsen',place_love_totem:'Liefdestotem plaatsen'},
  sv:{catalogue_title:'Kattkatalog',close_catalogue:'Stäng kattkatalogen',greenfields_mountain:'Grönfältsberget',love_totem:'Kärlekstotem',love_totem_description:'Ökar alla katters hälsa med 15 % och ger aveln en chans att skapa ovanligare katter utan alla deras element.',love_totem_ready:'Intjänad · redo att placeras',place_love_totem:'Placera kärlekstotemet'},
  ru:{catalogue_title:'Каталог котов',close_catalogue:'Закрыть каталог котов',greenfields_mountain:'Гора Зелёных Полей',love_totem:'Тотем любви',love_totem_description:'Увеличивает здоровье всех котов на 15% и даёт шанс вывести более редкого кота без всех его стихий.',love_totem_ready:'Получен · готов к установке',place_love_totem:'Установить тотем любви'},
  zh:{catalogue_title:'猫咪图鉴',close_catalogue:'关闭猫咪图鉴',greenfields_mountain:'绿野山',love_totem:'爱之图腾',love_totem_description:'使所有猫咪的生命值提高15%，并让繁育有机会获得缺少部分元素的稀有猫咪。',love_totem_ready:'已获得 · 可以放置',place_love_totem:'放置爱之图腾'},
  ja:{catalogue_title:'ネコ図鑑',close_catalogue:'ネコ図鑑を閉じる',greenfields_mountain:'緑野の山',love_totem:'愛のトーテム',love_totem_description:'すべてのネコの体力が15%上がり、繁殖で一部の属性を持たないレアなネコが生まれる可能性が高まります。',love_totem_ready:'獲得済み · 設置できます',place_love_totem:'愛のトーテムを設置'},
  ko:{catalogue_title:'고양이 도감',close_catalogue:'고양이 도감 닫기',greenfields_mountain:'초록 들판 산',love_totem:'사랑의 토템',love_totem_description:'모든 고양이의 체력을 15% 높이고, 번식 시 일부 속성이 없는 더 희귀한 고양이가 태어날 확률을 높여요.',love_totem_ready:'획득 완료 · 배치 가능',place_love_totem:'사랑의 토템 배치'},
  ms:{catalogue_title:'Katalog Kucing',close_catalogue:'Tutup katalog kucing',greenfields_mountain:'Gunung Padang Hijau',love_totem:'Totem Cinta',love_totem_description:'Meningkatkan kesihatan semua kucing sebanyak 15% dan memberi peluang pembiakan menghasilkan kucing yang lebih jarang tanpa semua elemennya.',love_totem_ready:'Diperoleh · sedia untuk diletakkan',place_love_totem:'Letakkan Totem Cinta'},
  hi:{catalogue_title:'बिल्ली सूची',close_catalogue:'बिल्ली सूची बंद करें',greenfields_mountain:'हरी घाटी का पर्वत',love_totem:'प्रेम टोटेम',love_totem_description:'सभी बिल्लियों का स्वास्थ्य 15% बढ़ाता है और प्रजनन से कुछ तत्वों के बिना दुर्लभ बिल्ली मिलने की संभावना देता है।',love_totem_ready:'मिल गया · रखने के लिए तैयार',place_love_totem:'प्रेम टोटेम रखें'}
};
Object.entries(additionalTranslations).forEach(([language, strings]) => Object.assign(translations[language], strings));
const creatureTranslations = {
  en:{floralis_name:'Floralis',floralis_description:"Small cats like to hop into this cat to relax and play games. Floralis is a calm, friendly fellow who never hurts people or eats them for no reason. It's surprising how such a big, bossy creature can be so friendly (and have such a great sense of humor)!",floralis_shop_description:'Calm, harmless to humans, and blessed with a great sense of humor.',take_fur_out:'Take fur out',spiky_ivy:'Spiky ivy',poisonous_roots:'Poisonous roots',suffocate_in_leaves:'Suffocate in leaves',magnitude_five_earthquake:'Magnitude five earthquake',florestalis_name:'Florestalis',florestalis_short_description:'Its tail is very long. Hop on it and feel like you are in the forest!',florestalis_description:'If you are in a forest and see a very huge tail in the distance, you are probably not in the forest, but looking at a magnificent Florestalis! A powerful cat, though very loving toward its owner.',love_totem_description:'For 1 ruby, boosts every cat\'s HP by 15% and gives breeding a chance to produce rarer cats without all their elements for 6 hours. Cooldown: 17 hours.',love_totem_activate:'Activate · 1 ruby · 6 hours',love_totem_boost_active:'Love Totem active · {duration} left',love_totem_cooldown:'Ready in {duration}',love_totem_started:'Love Totem activated for 6 hours!',love_totem_no_rubies:'Activate · need 1 ruby'},
  es:{floralis_name:'Floralis',floralis_description:'A los gatitos les encanta subirse a este gato para relajarse y jugar. Floralis es tranquilo y amable: nunca hace daño a las personas ni se las come sin motivo. ¡Sorprende que un ser tan grande y mandón sea tan simpático (y tenga tanto sentido del humor)!',floralis_shop_description:'Tranquilo, inofensivo para las personas y con un gran sentido del humor.',take_fur_out:'Arrancar pelo',spiky_ivy:'Hiedra espinosa',poisonous_roots:'Raíces venenosas',suffocate_in_leaves:'Asfixia entre hojas',magnitude_five_earthquake:'Terremoto de magnitud cinco',florestalis_name:'Florestalis',florestalis_short_description:'Su cola es muy larga. ¡Súbete y siéntete en medio del bosque!',florestalis_description:'Si estás en un bosque y ves una cola enorme a lo lejos, quizá no estés en el bosque, ¡sino contemplando a un magnífico Florestalis! Un gato poderoso, aunque muy cariñoso con su dueño.',love_totem_description:'Por 1 rubí, aumenta un 15 % la salud de todos los gatos y da a la crianza la posibilidad de producir gatos más raros sin todos sus elementos durante 6 horas. Enfriamiento: 17 horas.',love_totem_activate:'Activar · 1 rubí · 6 horas',love_totem_boost_active:'Tótem del amor activo · quedan {duration}',love_totem_cooldown:'Disponible en {duration}',love_totem_started:'¡Tótem del amor activado durante 6 horas!',love_totem_no_rubies:'Activar · necesitas 1 rubí'},
  pt:{floralis_name:'Floralis',floralis_description:'Gatinhos gostam de subir neste gato para relaxar e brincar. Floralis é calmo e amigável: nunca machuca pessoas nem as come sem motivo. É surpreendente que uma criatura tão grande e mandona seja tão simpática (e tenha tanto senso de humor)!',floralis_shop_description:'Calmo, inofensivo para humanos e com um ótimo senso de humor.',take_fur_out:'Arrancar pelos',spiky_ivy:'Hera espinhosa',poisonous_roots:'Raízes venenosas',suffocate_in_leaves:'Sufocar em folhas',magnitude_five_earthquake:'Terremoto de magnitude cinco',florestalis_name:'Florestalis',florestalis_short_description:'Sua cauda é muito longa. Suba nela e sinta-se na floresta!',florestalis_description:'Se você está numa floresta e vê uma cauda enorme ao longe, talvez não esteja na floresta, mas diante de um magnífico Florestalis! Um gato poderoso, mas muito carinhoso com seu dono.',love_totem_description:'Por 1 rubi, aumenta em 15% a vida de todos os gatos e dá à reprodução a chance de gerar gatos mais raros sem todos os elementos por 6 horas. Recarga: 17 horas.',love_totem_activate:'Ativar · 1 rubi · 6 horas',love_totem_boost_active:'Totem do Amor ativo · restam {duration}',love_totem_cooldown:'Disponível em {duration}',love_totem_started:'Totem do Amor ativado por 6 horas!',love_totem_no_rubies:'Ativar · é preciso 1 rubi'},
  it:{floralis_name:'Floralis',floralis_description:'I gattini adorano saltare su questo gatto per rilassarsi e giocare. Floralis è tranquillo e amichevole: non fa mai del male alle persone e non le mangia senza motivo. È sorprendente che una creatura così grande e autoritaria sia tanto simpatica (e abbia un grande senso dell’umorismo)!',floralis_shop_description:'Tranquillo, innocuo per le persone e dotato di un grande senso dell’umorismo.',take_fur_out:'Strappare il pelo',spiky_ivy:'Edera spinosa',poisonous_roots:'Radici velenose',suffocate_in_leaves:'Soffocare tra le foglie',magnitude_five_earthquake:'Terremoto di magnitudo cinque',florestalis_name:'Florestalis',florestalis_short_description:'La sua coda è lunghissima. Saltaci sopra e sentiti nella foresta!',florestalis_description:'Se sei in una foresta e vedi una coda enorme in lontananza, forse non sei nella foresta, ma davanti a uno splendido Florestalis! Un gatto potente, ma molto affettuoso con il suo padrone.',love_totem_description:'Con 1 rubino, aumenta del 15% la salute di tutti i gatti e per 6 ore dà alla riproduzione la possibilità di generare gatti più rari senza tutti i loro elementi. Ricarica: 17 ore.',love_totem_activate:'Attiva · 1 rubino · 6 ore',love_totem_boost_active:'Totem dell’amore attivo · restano {duration}',love_totem_cooldown:'Disponibile tra {duration}',love_totem_started:'Totem dell’amore attivato per 6 ore!',love_totem_no_rubies:'Attiva · serve 1 rubino'},
  de:{floralis_name:'Floralis',floralis_description:'Kleine Katzen springen gern auf diesen Kater, um sich auszuruhen und zu spielen. Floralis ist ruhig und freundlich: Er tut Menschen nichts und frisst sie nicht grundlos. Erstaunlich, dass ein so großes, herrisches Wesen so liebenswürdig ist (und so viel Humor hat)!',floralis_shop_description:'Ruhig, für Menschen harmlos und mit großartigem Humor.',take_fur_out:'Fell herausziehen',spiky_ivy:'Stacheliger Efeu',poisonous_roots:'Giftige Wurzeln',suffocate_in_leaves:'Zwischen Blättern ersticken',magnitude_five_earthquake:'Erdbeben der Stärke fünf',florestalis_name:'Florestalis',florestalis_short_description:'Sein Schwanz ist sehr lang. Spring hinauf und fühl dich wie im Wald!',florestalis_description:'Wenn du im Wald in der Ferne einen riesigen Schwanz siehst, bist du vielleicht gar nicht im Wald, sondern blickst auf einen prächtigen Florestalis! Eine mächtige Katze, die ihren Besitzer sehr lieb hat.',love_totem_description:'Für 1 Rubin erhalten alle Katzen 6 Stunden lang 15 % mehr HP. Außerdem kann die Zucht seltenere Katzen ohne alle Elemente hervorbringen. Abklingzeit: 17 Stunden.',love_totem_activate:'Aktivieren · 1 Rubin · 6 Stunden',love_totem_boost_active:'Liebestotem aktiv · noch {duration}',love_totem_cooldown:'Verfügbar in {duration}',love_totem_started:'Liebestotem für 6 Stunden aktiviert!',love_totem_no_rubies:'Aktivieren · 1 Rubin nötig'},
  nl:{floralis_name:'Floralis',floralis_description:'Kleine katten springen graag op deze kat om te ontspannen en te spelen. Floralis is rustig en vriendelijk: hij doet mensen geen kwaad en eet ze niet zomaar op. Het is bijzonder dat zo’n groot, bazig wezen zo aardig is (en zo’n goed gevoel voor humor heeft)!',floralis_shop_description:'Rustig, ongevaarlijk voor mensen en met een geweldig gevoel voor humor.',take_fur_out:'Vacht uittrekken',spiky_ivy:'Stekelige klimop',poisonous_roots:'Giftige wortels',suffocate_in_leaves:'Stikken in bladeren',magnitude_five_earthquake:'Aardbeving met kracht vijf',florestalis_name:'Florestalis',florestalis_short_description:'Zijn staart is heel lang. Klim erop en waan je in het bos!',florestalis_description:'Zie je in een bos in de verte een enorme staart, dan ben je misschien niet in het bos maar kijk je naar een prachtige Florestalis! Een sterke kat die heel lief is voor zijn baasje.',love_totem_description:'Voor 1 robijn krijgen alle katten 6 uur lang 15% meer HP en kan de fokkerij zeldzamere katten zonder al hun elementen opleveren. Afkoeltijd: 17 uur.',love_totem_activate:'Activeren · 1 robijn · 6 uur',love_totem_boost_active:'Liefdestotem actief · nog {duration}',love_totem_cooldown:'Beschikbaar over {duration}',love_totem_started:'Liefdestotem 6 uur geactiveerd!',love_totem_no_rubies:'Activeren · 1 robijn nodig'},
  sv:{floralis_name:'Floralis',floralis_description:'Små katter hoppar gärna upp på den här katten för att vila och leka. Floralis är lugn och vänlig: den skadar aldrig människor eller äter upp dem utan anledning. Det är förvånande att en så stor och bossig varelse kan vara så snäll (och ha så bra humor)!',floralis_shop_description:'Lugn, ofarlig för människor och med en fantastisk humor.',take_fur_out:'Dra ut päls',spiky_ivy:'Taggig murgröna',poisonous_roots:'Giftiga rötter',suffocate_in_leaves:'Kvävas bland löv',magnitude_five_earthquake:'Jordbävning med magnitud fem',florestalis_name:'Florestalis',florestalis_short_description:'Svansen är jättelång. Hoppa upp och känn dig som i skogen!',florestalis_description:'Om du är i en skog och ser en jättelik svans långt borta tittar du kanske inte ut i skogen, utan på en magnifik Florestalis! En mäktig katt som är mycket kärleksfull mot sin ägare.',love_totem_description:'För 1 rubin får alla katter 15 % mer HP i 6 timmar, och aveln kan ge ovanligare katter utan alla deras element. Nedkylning: 17 timmar.',love_totem_activate:'Aktivera · 1 rubin · 6 timmar',love_totem_boost_active:'Kärlekstotemet aktivt · {duration} kvar',love_totem_cooldown:'Redo om {duration}',love_totem_started:'Kärlekstotemet aktiverat i 6 timmar!',love_totem_no_rubies:'Aktivera · 1 rubin behövs'},
  ru:{floralis_name:'Флоралис',floralis_description:'Маленькие котята любят забираться на этого кота, чтобы отдыхать и играть. Флоралис спокоен и дружелюбен: он не обижает людей и не ест их без причины. Удивительно, что такое большое и властное существо может быть таким милым (и обладать отличным чувством юмора)!',floralis_shop_description:'Спокойный, безвредный для людей и с отличным чувством юмора.',take_fur_out:'Выдрать шерсть',spiky_ivy:'Колючий плющ',poisonous_roots:'Ядовитые корни',suffocate_in_leaves:'Задушить листьями',magnitude_five_earthquake:'Землетрясение магнитудой пять',florestalis_name:'Флорасталис',florestalis_short_description:'У него очень длинный хвост. Запрыгни и почувствуй себя в лесу!',florestalis_description:'Если в лесу вдали виднеется огромный хвост, возможно, вы смотрите не в лес, а на великолепного Флорасталиса! Могучий кот, который очень любит своего хозяина.',love_totem_description:'За 1 рубин все коты получают на 15% больше здоровья на 6 часов, а при разведении может появиться более редкий кот без всех его стихий. Перезарядка: 17 часов.',love_totem_activate:'Активировать · 1 рубин · 6 часов',love_totem_boost_active:'Тотем любви действует · осталось {duration}',love_totem_cooldown:'Будет готов через {duration}',love_totem_started:'Тотем любви активирован на 6 часов!',love_totem_no_rubies:'Активировать · нужен 1 рубин'},
  zh:{floralis_name:'弗洛拉利斯',floralis_description:'小猫喜欢跳到这只猫身上休息和玩耍。弗洛拉利斯性情平和、十分友善，从不无故伤害或吃掉人类。很难想象如此庞大又威风的家伙竟然这么亲切（而且很有幽默感）！',floralis_shop_description:'性情温和，对人无害，而且很有幽默感。',take_fur_out:'拔毛',spiky_ivy:'带刺常春藤',poisonous_roots:'毒根',suffocate_in_leaves:'落叶窒息',magnitude_five_earthquake:'五级地震',florestalis_name:'弗洛雷斯塔利斯',florestalis_short_description:'它的尾巴非常长。跳上去，感受森林的气息！',florestalis_description:'如果你在森林里看见远处有一条巨大的尾巴，你看到的可能不是森林，而是一只壮丽的弗洛雷斯塔利斯！它强大无比，却对主人十分温柔。',love_totem_description:'花费1颗红宝石，使所有猫咪的生命值提高15%，持续6小时；繁育也有机会获得缺少部分元素的稀有猫咪。冷却时间：17小时。',love_totem_activate:'激活 · 1颗红宝石 · 6小时',love_totem_boost_active:'爱之图腾生效中 · 剩余{duration}',love_totem_cooldown:'{duration}后可用',love_totem_started:'爱之图腾已激活6小时！',love_totem_no_rubies:'激活 · 需要1颗红宝石'},
  ja:{floralis_name:'フロラリス',floralis_description:'小さなネコたちは、くつろいだり遊んだりするためにこのネコによく飛び乗ります。フロラリスは穏やかで友好的。理由もなく人を傷つけたり食べたりしません。こんなに大きくて威厳のある存在が、とても親切でユーモアまであるなんて驚きです！',floralis_shop_description:'穏やかで人に危害を加えず、ユーモアたっぷり。',take_fur_out:'毛をむしる',spiky_ivy:'トゲのあるツタ',poisonous_roots:'毒の根',suffocate_in_leaves:'葉に埋もれて窒息',magnitude_five_earthquake:'マグニチュード5の地震',florestalis_name:'フロレスタリス',florestalis_short_description:'とても長いしっぽ。飛び乗って森の気分を味わおう！',florestalis_description:'森の中で遠くに巨大なしっぽが見えたら、それは森ではなく、壮大なフロレスタリスかもしれません！力強いのに、飼い主にはとても優しいネコです。',love_totem_description:'ルビー1個で全ネコのHPが15%上昇し、繁殖で一部の属性を持たないレアなネコが生まれる可能性が高まります（6時間）。クールダウン：17時間。',love_totem_activate:'発動 · ルビー1個 · 6時間',love_totem_boost_active:'愛のトーテム発動中 · 残り{duration}',love_totem_cooldown:'{duration}後に使用可能',love_totem_started:'愛のトーテムが6時間発動しました！',love_totem_no_rubies:'発動 · ルビー1個が必要'},
  ko:{floralis_name:'플로랄리스',floralis_description:'작은 고양이들은 쉬고 놀기 위해 이 고양이 위에 올라타는 것을 좋아해요. 플로랄리스는 차분하고 친근해서 이유 없이 사람을 해치거나 잡아먹지 않아요. 이렇게 크고 위엄 있는 존재가 다정하고 유머 감각까지 있다는 게 놀랍죠!',floralis_shop_description:'차분하고 사람에게 해를 끼치지 않으며 유머 감각도 뛰어나요.',take_fur_out:'털 뽑기',spiky_ivy:'가시 덩굴',poisonous_roots:'독이 있는 뿌리',suffocate_in_leaves:'나뭇잎에 질식시키기',magnitude_five_earthquake:'규모 5 지진',florestalis_name:'플로레스탈리스',florestalis_short_description:'꼬리가 아주 길어요. 올라타서 숲속 기분을 느껴 보세요!',florestalis_description:'숲에서 멀리 아주 커다란 꼬리가 보인다면 숲이 아니라 멋진 플로레스탈리스를 보고 있는 걸지도 몰라요! 강력하지만 주인에게는 정말 다정한 고양이예요.',love_totem_description:'루비 1개로 모든 고양이의 HP가 15% 증가하고, 번식 시 일부 속성이 없는 희귀 고양이가 태어날 가능성이 생겨요. 지속 시간은 6시간, 재사용 대기시간은 17시간이에요.',love_totem_activate:'활성화 · 루비 1개 · 6시간',love_totem_boost_active:'사랑의 토템 활성화 · {duration} 남음',love_totem_cooldown:'{duration} 후 사용 가능',love_totem_started:'사랑의 토템이 6시간 동안 활성화됐어요!',love_totem_no_rubies:'활성화 · 루비 1개 필요'},
  ms:{floralis_name:'Floralis',floralis_description:'Kucing kecil suka melompat ke atas kucing ini untuk berehat dan bermain. Floralis tenang dan mesra: ia tidak mencederakan atau memakan manusia tanpa sebab. Memang mengagumkan makhluk yang besar dan garang ini begitu baik hati (serta mempunyai selera humor yang hebat)!',floralis_shop_description:'Tenang, tidak berbahaya kepada manusia dan mempunyai selera humor yang hebat.',take_fur_out:'Cabut bulu',spiky_ivy:'Ivy berduri',poisonous_roots:'Akar beracun',suffocate_in_leaves:'Lemas dalam daun',magnitude_five_earthquake:'Gempa bumi bermagnitud lima',florestalis_name:'Florestalis',florestalis_short_description:'Ekornya sangat panjang. Naiklah dan rasai suasana hutan!',florestalis_description:'Jika anda berada di hutan dan nampak ekor yang sangat besar di kejauhan, mungkin anda sedang melihat Florestalis yang hebat! Kucing yang kuat tetapi sangat penyayang terhadap pemiliknya.',love_totem_description:'Dengan 1 delima, HP semua kucing meningkat 15% dan pembiakan berpeluang menghasilkan kucing yang lebih jarang tanpa semua elemennya selama 6 jam. Tempoh bertenang: 17 jam.',love_totem_activate:'Aktifkan · 1 delima · 6 jam',love_totem_boost_active:'Totem Cinta aktif · berbaki {duration}',love_totem_cooldown:'Sedia dalam {duration}',love_totem_started:'Totem Cinta aktif selama 6 jam!',love_totem_no_rubies:'Aktifkan · perlukan 1 delima'},
  hi:{floralis_name:'फ्लोरालिस',floralis_description:'छोटी बिल्लियाँ आराम करने और खेलने के लिए इस बिल्ली पर चढ़ना पसंद करती हैं। फ्लोरालिस शांत और दोस्ताना है; वह बिना वजह इंसानों को चोट नहीं पहुँचाता या उन्हें खाता नहीं। इतना बड़ा और रौबदार जीव इतना प्यारा (और मज़ाकिया) हो सकता है, यह हैरान करता है!',floralis_shop_description:'शांत, इंसानों के लिए हानिरहित और शानदार हास्य-बोध वाली।',take_fur_out:'रोएँ खींचना',spiky_ivy:'काँटेदार आइवी',poisonous_roots:'ज़हरीली जड़ें',suffocate_in_leaves:'पत्तों में दम घोंटना',magnitude_five_earthquake:'तीव्रता पाँच का भूकंप',florestalis_name:'फ्लोरेस्टालिस',florestalis_short_description:'इसकी पूँछ बहुत लंबी है। उस पर चढ़ें और जंगल जैसा महसूस करें!',florestalis_description:'अगर जंगल में दूर एक बहुत बड़ी पूँछ दिखे, तो शायद आप जंगल नहीं, बल्कि शानदार फ्लोरेस्टालिस को देख रहे हैं! यह शक्तिशाली बिल्ली अपने मालिक से बहुत प्यार करती है।',love_totem_description:'1 माणिक में सभी बिल्लियों का HP 15% बढ़ता है और 6 घंटे तक प्रजनन से कुछ तत्वों के बिना दुर्लभ बिल्ली मिलने की संभावना रहती है। कूलडाउन: 17 घंटे।',love_totem_activate:'सक्रिय करें · 1 माणिक · 6 घंटे',love_totem_boost_active:'प्रेम टोटेम सक्रिय · {duration} शेष',love_totem_cooldown:'{duration} में तैयार',love_totem_started:'प्रेम टोटेम 6 घंटे के लिए सक्रिय हुआ!',love_totem_no_rubies:'सक्रिय करें · 1 माणिक चाहिए'}
};
Object.entries(creatureTranslations).forEach(([language, strings]) => Object.assign(translations[language], strings));
const namedTranslationCoverage = {"en":{"catalogue_title":"Cat Catalogue","greenfields_mountain":"Greenfields Mountain","totem_cup":"Totem Cup"},"es":{"catalogue_title":"Catálogo de gatos","greenfields_mountain":"Montaña de los Campos Verdes","totem_cup":"Copa del Tótem"},"pt":{"catalogue_title":"Catálogo de Gatos","greenfields_mountain":"Montanha dos Campos Verdes","totem_cup":"Copa do Totem"},"it":{"catalogue_title":"Catalogo dei gatti","greenfields_mountain":"Montagna dei Campi Verdi","totem_cup":"Coppa del Totem"},"de":{"catalogue_title":"Katzenkatalog","greenfields_mountain":"Grüne-Felder-Berg","totem_cup":"Totem-Pokal"},"nl":{"catalogue_title":"Kattencatalogus","greenfields_mountain":"Groene Velden Berg","totem_cup":"Totembeker"},"sv":{"catalogue_title":"Kattkatalog","greenfields_mountain":"Grönfältsberget","totem_cup":"Totemcupen"},"ru":{"catalogue_title":"Каталог котов","greenfields_mountain":"Гора Зелёных Полей","totem_cup":"Кубок тотема"},"zh":{"catalogue_title":"猫咪图鉴","greenfields_mountain":"绿野山","totem_cup":"图腾杯"},"ja":{"catalogue_title":"ネコ図鑑","greenfields_mountain":"緑野の山","totem_cup":"トーテムカップ"},"ko":{"catalogue_title":"고양이 도감","greenfields_mountain":"초록 들판 산","totem_cup":"토템 컵"},"ms":{"catalogue_title":"Katalog Kucing","greenfields_mountain":"Gunung Padang Hijau","totem_cup":"Piala Totem"},"hi":{"catalogue_title":"बिल्ली सूची","greenfields_mountain":"हरी घाटी का पर्वत","totem_cup":"टोटेम कप"}};
Object.entries(namedTranslationCoverage).forEach(([language, strings]) => Object.assign(translations[language], strings));
Object.entries({ en:'Florestalis Cube', es:'Cubo de Florestalis', pt:'Cubo de Florestalis', it:'Cubo di Florestalis', de:'Florestalis-Würfel', nl:'Florestalis-kubus', sv:'Florestalis-kub', ru:'Куб Флорасталиса', zh:'弗洛雷斯塔利斯方块', ja:'フロレスタリスのキューブ', ko:'플로레스탈리스 큐브', ms:'Kiub Florestalis', hi:'फ्लोरेस्टालिस क्यूब' }).forEach(([language, label]) => { translations[language].cube_florestalis = label; });

const BUILDING_CATALOG = [
  { id:'cube_hatcher', image:'CubeHatcher.png', price:0, installed:true },
  { id:'cube_mixer', image:'CubeMixer.png', price:50 },
  { id:'feline_stocks', image:'FelineStocks.png', price:1500 },
  { id:'gym', image:'uploads/Gym.png', price:12000 },
  { id:'farm', image:'1000084739.png', price:600 },
  { id:'love_totem', image:'uploads/Love_Totem.png', price:0 }
];
let activeMountainId = 'arid';
let cataloguePreviewOnly = false;
let hatchTransitionBusy = false;
let pendingHatchEggId = null;
let mountainZoom = 1;
let mixerSelection = [null, null];
let activeMixerMountain = 'arid';
gameState.buildings.forEach((building, index) => { building.uid ||= `${building.id}-${building.mountain}-${index}`; });
gameState.buildings.filter(building => building.id === 'feline_stocks').forEach(building => {
  building.unlockedSlots = Math.max(5, Math.min(15, Number.isInteger(building.unlockedSlots) ? building.unlockedSlots : 5));
  building.stockedCats = Array.isArray(building.stockedCats) ? building.stockedCats.slice(0, 15) : [];
});
let selectedStockSlot = null;

function isWalkable(row, column) {
  if (activeMountainId === 'metropolis') return row >= 3 && row <= 13 && column >= 2 && column <= 19;
  return row >= 1 && row <= mapRows && column >= 1 && column <= mapColumns && !blockedTiles.has(row + ',' + column);
}
function occupied(row, column, exceptId = null) {
  return gameState.cats.some(cat => !cat.storedIn && cat.id !== exceptId && (cat.mountain || 'arid') === activeMountainId && cat.row === row && cat.column === column)
    || gameState.buildings.some(building => building.uid !== exceptId && building.id !== exceptId && building.mountain === activeMountainId && building.row === row && building.column === column);
}
function findAvailableTile(preferredRow = 4, preferredColumn = 4) {
  const candidates = [];
  const rows = activeMountainId === 'metropolis' ? 14 : mapRows;
  const columns = activeMountainId === 'metropolis' ? 20 : mapColumns;
  for (let row = 1; row <= rows; row++) {
    for (let column = 1; column <= columns; column++) candidates.push([row, column]);
  }
  candidates.sort((a, b) => Math.abs(a[0] - preferredRow) + Math.abs(a[1] - preferredColumn) - Math.abs(b[0] - preferredRow) - Math.abs(b[1] - preferredColumn));
  return candidates.find(([row, column]) => isWalkable(row, column) && !occupied(row, column)) || null;
}
function ensureMountainBuildings() {
  const previousMountain = activeMountainId;
  for (const mountain of MOUNTAIN_CATALOG) {
    activeMountainId = mountain.id;
    if (!gameState.buildings.some(building => building.id === 'cube_hatcher' && building.mountain === mountain.id)) {
      gameState.buildings.push({ id: 'cube_hatcher', uid: `cube_hatcher-${mountain.id}`, mountain: mountain.id });
    }
    gameState.buildings.filter(building => building.mountain === mountain.id).forEach(building => {
      building.uid ||= `${building.id}-${building.mountain}-${Math.random().toString(36).slice(2,8)}`;
      const hasValidTile = Number.isInteger(building.row) && Number.isInteger(building.column)
        && isWalkable(building.row, building.column)
        && !gameState.cats.some(cat => (cat.mountain || 'arid') === mountain.id && cat.row === building.row && cat.column === building.column)
        && !gameState.buildings.some(other => other !== building && other.mountain === mountain.id && other.row === building.row && other.column === building.column);
      if (hasValidTile) return;
      const tile = findAvailableTile(2, 4);
      if (tile) [building.row, building.column] = tile;
    });
  }
  activeMountainId = previousMountain;
}
const savedCats = Array.isArray(savedGame?.cats)
  ? savedGame.cats
  : savedGame?.catOwned === false
    ? []
    : [{ id: 'rocky-legacy', level: savedGame?.catLevel, row: 4, column: 4, lastProducedAt: now }];
savedCats.forEach((savedCat, index) => {
  activeMountainId = compatibleMountainFor(CAT_CATALOG[savedCat?.type] ? savedCat.type : 'rocky', MOUNTAIN_CATALOG.some(item => item.id === savedCat?.mountain) ? savedCat.mountain : 'arid');
  const level = Number.isInteger(savedCat?.level) && savedCat.level > 0 ? savedCat.level : 1;
  const preferredRow = Number.isInteger(savedCat?.row) ? savedCat.row : 4;
  const preferredColumn = Number.isInteger(savedCat?.column) ? savedCat.column : 4;
  let row = preferredRow;
  let column = preferredColumn;
  if (!(savedCat?.storedIn && activeMountainId === savedCat?.mountain) && (!isWalkable(row, column) || occupied(row, column))) {
    const free = findAvailableTile(preferredRow, preferredColumn);
    if (!free) return;
    [row, column] = free;
  }
  gameState.cats.push({
    id: typeof savedCat?.id === 'string' ? savedCat.id : 'rocky-' + index,
    type: CAT_CATALOG[savedCat?.type] ? savedCat.type : 'rocky',
    mountain: activeMountainId,
    storedIn: activeMountainId === savedCat?.mountain && typeof savedCat?.storedIn === 'string' ? savedCat.storedIn : null,
    storedSlot: activeMountainId === savedCat?.mountain && Number.isInteger(savedCat?.storedSlot) ? savedCat.storedSlot : undefined,
    level,
    rarity: CAT_CATALOG[savedCat?.type]?.rarity || 'Simple',
    rarityWeight: CAT_CATALOG[savedCat?.type]?.rarityWeight || 1,
    row,
    column,
    lastProducedAt: Number.isFinite(savedCat?.lastProducedAt) ? savedCat.lastProducedAt : now
  });
});
activeMountainId = 'arid';
// Give every installed or owned structure a persistent tile, including after
// account saves replace the in-memory building list.
ensureMountainBuildings();
activeMountainId = 'arid';
function t(key, values = {}) {
  let text = translations[currentLanguage]?.[key] ?? auxiliaryTranslations[currentLanguage]?.[key] ?? smokireTranslations[currentLanguage]?.[key] ?? shopTranslations[currentLanguage]?.[key] ?? battleText[currentLanguage]?.[key] ?? interfaceTranslations[currentLanguage]?.[key] ?? (key === 'close_languages' ? closeLanguageLabels[currentLanguage] : undefined) ?? translations.en[key] ?? auxiliaryTranslations.en[key] ?? smokireTranslations.en[key] ?? shopTranslations.en[key] ?? battleText.en[key] ?? interfaceTranslations.en[key] ?? (key === 'close_languages' ? closeLanguageLabels.en : undefined) ?? key;
  Object.entries(values).forEach(([name, value]) => { text = text.replaceAll('{' + name + '}', value); });
  return text;
}
function formatNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return String(value);
  const compact = (divisor, suffix) => (number / divisor).toFixed(number / divisor < 10 ? 1 : 0).replace(/\.0$/, '') + suffix;
  if (number >= 1_000_000_000) return compact(1_000_000_000, 'b');
  if (number >= 1_000_000) return compact(1_000_000, 'm');
  if (number >= 1_000) return compact(1_000, 'k');
  return String(number);
}
function catData(cat = getSelectedCat()) { return CAT_CATALOG[cat?.type] || CAT_CATALOG.rocky; }
function catName(cat = getSelectedCat()) { return cat?.type === 'florestalis' ? t('florestalis_name') : cat?.type === 'floralis' ? t('floralis_name') : cat?.type === 'volcanic_lava' ? t('volcanic_lava_cat') : cat?.type === 'smokire' ? t('smokire_name') : t('rocky_cat'); }
function catDescription(cat = getSelectedCat()) {
  if (cat?.type === 'florestalis') return t('florestalis_description');
  if (cat?.type === 'floralis') return t('floralis_description');
  if (cat?.type === 'volcanic_lava') return t('volcanic_description');
  return cat?.type === 'smokire' ? t('smokire_description').replaceAll('Smokire', t('smokire_name')) : t('cat_description');
}
function hasLoveTotem() { return gameState.buildings.some(building => building.id === 'love_totem'); }
function loveTotemBoostActive(now = Date.now()) {
  const totem = gameState.buildings.find(building => building.id === 'love_totem');
  return Boolean(totem && Number.isFinite(totem.activeUntil) && totem.activeUntil > now);
}
function productionInterval(cat) {
  const speedBonus = cat.type === 'smokire' ? 1 + (cat.level - 1) * 0.25 : 1 + Math.floor(cat.level / 2) * 0.25;
  return catData(cat).production / speedBonus;
}
function productionText(cat) {
  const seconds = (productionInterval(cat) / 1000).toFixed(1).replace(/\.0$/, '');
  return t('production_format', { seconds });
}
function getSelectedCat() {
  return gameState.cats.find(cat => cat.id === selectedCatId) || null;
}
function shopCatType() {
  if (activeMountainId === 'greenfields') return 'floralis';
  return activeMountainId === 'burning' || activeMountainId === 'metropolis' ? 'smokire' : 'rocky';
}
function saveGame() {
  const snapshot = {
    silver: gameState.silver, currencySchema: 3, rubies: gameState.rubies, food: gameState.food,
    playerLevel: gameState.playerLevel, xp: gameState.xp,
    cats: gameState.cats,
    buildings: gameState.buildings, eggs: gameState.eggs, breeds: gameState.breeds,
    startersCupCompleted: gameState.startersCupCompleted,
    rubyCupStage: gameState.rubyCupStage,
    metropolisCupStage: gameState.metropolisCupStage,
    totemCupStage: gameState.totemCupStage,
    loveTotemUnlocked: gameState.loveTotemUnlocked,
    mountainousMetropolisUnlocked: gameState.mountainousMetropolisUnlocked,
    onlineProfile: gameState.onlineProfile, trophies: gameState.trophies, battleRoster: gameState.battleRoster
  };
  localStorage.setItem('catdance-save', JSON.stringify(snapshot));
  if (!accountSaveEnabled) return;
  clearTimeout(accountSaveTimer);
  accountSaveTimer = window.setTimeout(() => {
    accountSaveQueue = accountSaveQueue.catch(() => {}).then(async () => {
      const response = await fetch('/api/save', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(snapshot)
      });
      if (!response.ok) throw new Error('Save request returned ' + response.status);
    }).catch(error => {
      console.warn('Account save could not be synced.', error);
    });
  }, 450);
}
function renderCatPanel(catOverride = null) {
  const cat = catOverride || getSelectedCat();
  if (!cat) return;
  const data = catData(cat);
  document.querySelectorAll('[data-cat-name]').forEach(node => node.textContent = catName(cat));
  document.querySelector('[data-cat-description]').textContent = catDescription(cat);
  const art = document.querySelector('.panel-cat-art');
  art.src = data.image;
  art.alt = catName(cat);
  const rarity = data.rarity || cat.rarity || 'Simple';
  const rarityIcon = rarity === 'Moderate' ? 'uploads/Moderate_rarity.png' : 'uploads/Simple_rarity.png';
  document.querySelector('.cat-traits').innerHTML = `<span class="detail-chip rarity-detail"><img src="${rarityIcon}" alt=""><span>${t(rarity === 'Moderate' ? 'moderate' : 'simple')}</span></span>${data.elements.map(element => `<span class="detail-chip"><img src="${element === 'Plant' ? 'uploads/Plant_element_.png' : element === 'Fire' ? 'Fire element.png' : element === 'Earth' ? 'uploads/Earth_element.png' : 'uploads/Cat_element.png'}" alt=""><span>${element === 'Cat' ? t('cat_element') : element === 'Earth' ? t('earth') : element === 'Plant' ? t('plant') : t('fire')}</span></span>`).join('')}`;
  document.querySelector('[data-cat-level]').textContent = cat.level;
  document.querySelector('[data-cat-life]').textContent = Math.round(data.hp * cat.level * (loveTotemBoostActive() ? 1.15 : 1));
  document.querySelector('.cat-attacks').innerHTML = data.attacks.map(attack => `<button class="attack-button" type="button"><img src="${attack.element}" alt=""><span>${attack.nameKey ? t(attack.nameKey) : attack.name || t(attack.key)}</span><small>${t('damage_format', { damage: attack.damage })}</small></button>`).join('');
  document.querySelector('.cat-production [data-i18n="silver_production"]').textContent = t('silver_production');
  document.querySelector('[data-cat-rate]').textContent = productionText(cat);
  document.querySelector('.sell-action small').innerHTML = `${formatNumber(data.sell)} <span>${t('silver')}</span>`;
  document.querySelector('[data-food-cost]').textContent = 5 * 2 ** (cat.level - 1);
  document.querySelector('.cat-actions').hidden = cataloguePreviewOnly || Boolean(cat.storedIn);
}
function renderGameState() {
  ['silver', 'rubies', 'food'].forEach(resource => {
    document.querySelectorAll('[data-resource="' + resource + '"]').forEach(node => node.textContent = formatNumber(gameState[resource]));
  });
  document.querySelectorAll('[data-player-level]').forEach(node => { node.textContent = t('level_short') + ' ' + gameState.playerLevel; });
  const xpToNext = 500 * (2 ** (gameState.playerLevel - 1));
  document.querySelectorAll('[data-player-xp]').forEach(node => { node.textContent = formatNumber(gameState.xp) + ' / ' + formatNumber(xpToNext) + ' XP'; });
  renderMountainChoices();
  renderShop();
  renderCatPanel();
  if (!catalogueModal.hidden) renderCatalogue();
  if (!felineStocksModal.hidden) renderFelineStocks();
}
const CAT_STICKERS = [
  { id: 'rocky', number: 1, type: 'rocky' },
  { id: 'smokire', number: 2, type: 'smokire' },
  { id: 'volcanic_lava', number: 3, type: 'volcanic_lava' },
  { id: 'floralis', number: 4, type: 'floralis' },
  { id: 'florestalis', number: 5, type: 'florestalis' }
];
function renderCatalogue() {
  document.querySelector('#catalogue-title').textContent = t('catalogue_title');
  const stickers = document.querySelector('#catalogue-stickers');
  stickers.replaceChildren();
  CAT_STICKERS.forEach(entry => {
    const owned = gameState.cats.some(cat => cat.type === entry.type);
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'catalogue-sticker' + (owned ? ' is-owned' : ' is-locked');
    button.dataset.action = 'catalogue-cat'; button.dataset.catType = entry.type;
    const number = document.createElement('span'); number.className = 'sticker-number'; number.textContent = entry.number;
    const data = CAT_CATALOG[entry.type];
    const name = document.createElement('b'); name.className = 'sticker-name'; name.textContent = catName({ type: entry.type });
    const art = document.createElement('img'); art.className = 'sticker-cat-art'; art.src = data.image; art.alt = name.textContent;
    const rarity = data.rarity || 'Simple';
    const rarityIcon = document.createElement('img');
    rarityIcon.className = 'sticker-rarity-icon';
    rarityIcon.src = rarity === 'Moderate' ? 'uploads/Moderate_rarity.png' : 'uploads/Simple_rarity.png';
    rarityIcon.alt = '';
    const traits = document.createElement('span'); traits.className = 'sticker-elements';
    const elementNames = { Cat: 'cat_element', Earth: 'earth', Fire: 'fire', Plant: 'plant' };
    const elementImages = { Cat: 'uploads/Cat_element.png', Earth: 'uploads/Earth_element.png', Fire: 'Fire element.png', Plant: 'uploads/Plant_element_.png' };
    data.elements.forEach(element => {
      const icon = document.createElement('img');
      icon.src = elementImages[element] || elementImages.Cat;
      icon.alt = '';
      traits.append(icon);
    });
    const rarityName = t(rarity === 'Moderate' ? 'moderate' : 'simple');
    button.setAttribute('aria-label', `${name.textContent} · ${rarityName} · ${data.elements.map(element => t(elementNames[element] || 'cat_element')).join(', ')}`);
    button.append(number, name, art, traits, rarityIcon); stickers.append(button);
  });
}
function openCatalogue() {
  closeCatPanel(); closeShop(); closeHatcher();
  document.querySelector('#catalogue-title').textContent = t('catalogue_title');
  renderCatalogue(); catalogueModal.hidden = false;
}
function openBuildingMessage(buildingId, buildingUid) {
  document.querySelector('#building-message-title').textContent = t(buildingId);
  document.querySelector('.building-message-move').textContent = t('move') + ' ' + t(buildingId);
  document.querySelector('.building-message-move').dataset.buildingUid = buildingUid || '';
  document.querySelector('.building-message-open').hidden = buildingId !== 'cube_hatcher';
  const gymButton = document.querySelector('.building-message-gym');
  gymButton.hidden = !['gym','love_totem'].includes(buildingId);
  gymButton.dataset.action = buildingId === 'gym' ? 'activate-gym' : 'activate-love-totem';
  buildingMessageModal.dataset.buildingId = buildingId;
  buildingMessageModal.dataset.buildingUid = buildingUid || '';
  buildingMessageModal.querySelector('p').textContent = buildingId === 'gym' ? t('gym_description') : buildingId === 'love_totem' ? t('love_totem_description') : t('building_future_message');
  if (buildingId === 'gym') renderGymMessage();
  if (buildingId === 'love_totem') renderLoveTotemMessage();
  buildingMessageModal.hidden = false;
}
function closeBuildingMessage() { buildingMessageModal.hidden = true; }
function openFelineStocks(buildingUid) {
  const building = gameState.buildings.find(item => item.uid === buildingUid && item.id === 'feline_stocks' && item.mountain === activeMountainId);
  if (!building) return;
  building.unlockedSlots = Math.max(5, Math.min(15, Number.isInteger(building.unlockedSlots) ? building.unlockedSlots : 5));
  building.stockedCats = Array.isArray(building.stockedCats) ? building.stockedCats : [];
  felineStocksModal.dataset.buildingUid = building.uid;
  felineStocksModal.querySelector('.feline-stocks-modal').classList.toggle('is-burning', building.mountain === 'burning');
  felineStocksModal.querySelector('#feline-stocks-title').textContent = t('stocks_title');
  selectedStockSlot = null;
  renderFelineStocks();
  felineStocksModal.hidden = false;
}
function renderFelineStocks() {
  const building = gameState.buildings.find(item => item.uid === felineStocksModal.dataset.buildingUid && item.id === 'feline_stocks');
  if (!building) return;
  const slots = [];
  for (let index = 0; index < 15; index++) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'feline-stock-slot';
    const catId = building.stockedCats[index];
    const cat = catId && gameState.cats.find(item => item.id === catId && item.storedIn === building.uid);
    if (cat) {
      button.classList.add('has-cat');
      button.dataset.action = 'stock-take-out';
      button.dataset.stockSlot = index;
      const image = document.createElement('img'); image.src = catData(cat).image; image.alt = '';
      const name = document.createElement('b'); name.textContent = catName(cat);
      const take = document.createElement('small'); take.textContent = t('stocks_take_out');
      button.append(image, name, take);
    } else if (index < building.unlockedSlots) {
      button.classList.add('is-empty');
      button.dataset.action = 'stock-add';
      button.dataset.stockSlot = index;
      button.textContent = '+ ' + t('stocks_add');
    } else {
      button.classList.add('is-locked');
      button.dataset.action = 'stock-unlock';
      button.dataset.stockSlot = index;
      button.innerHTML = `<span>🔒</span><b>${t('stocks_locked')}</b>`;
    }
    slots.push(button);
  }
  felineStockSlots.replaceChildren(...slots);
  if (selectedStockSlot === null) {
    felineStockPicker.hidden = true;
    felineStockPicker.replaceChildren();
    return;
  }
  const availableCats = gameState.cats.filter(cat => (cat.mountain || 'arid') === building.mountain && !cat.storedIn);
  if (!availableCats.length) {
    felineStockPicker.textContent = t('stocks_no_cats');
    felineStockPicker.hidden = false;
    return;
  }
  const title = document.createElement('b'); title.className = 'feline-stock-picker-title'; title.textContent = t('stocks_choose');
  const choices = availableCats.map(cat => {
    const choice = document.createElement('button'); choice.type = 'button'; choice.className = 'feline-stock-choice';
    choice.dataset.action = 'stock-select-cat'; choice.dataset.catId = cat.id;
    const image = document.createElement('img'); image.src = catData(cat).image; image.alt = '';
    const name = document.createElement('span'); name.textContent = catName(cat);
    choice.append(image, name); return choice;
  });
  felineStockPicker.replaceChildren(title, ...choices);
  felineStockPicker.hidden = false;
}
function closeFelineStocks() {
  felineStocksModal.hidden = true;
  selectedStockSlot = null;
}
function openCubeMixer(mountain = activeMountainId) {
  activeMixerMountain = ['arid','burning','metropolis','greenfields'].includes(mountain) ? mountain : 'arid';
  mixerSelection = [null, null];
  renderCubeMixer();
  cubeMixerModal.hidden = false;
}
function closeCubeMixer() {
  cubeMixerModal.hidden = true;
  mixerSelection = [null, null];
}
function renderMixerParentRow(container, parentIndex) {
  const otherId = mixerSelection[parentIndex === 0 ? 1 : 0];
  const cats = [...gameState.cats].sort((a, b) => catName(a).localeCompare(catName(b)) || a.id.localeCompare(b.id));
  if (!cats.length) {
    const empty = document.createElement('p'); empty.className = 'mixer-empty'; empty.textContent = t('mixer_none');
    container.replaceChildren(empty);
    return;
  }
  const buttons = cats.map(cat => {
    const choice = document.createElement('button');
    choice.type = 'button';
    choice.className = 'mixer-cat-choice' + (mixerSelection[parentIndex] === cat.id ? ' is-selected' : '');
    choice.dataset.action = 'mixer-select-cat';
    choice.dataset.parentIndex = parentIndex;
    choice.dataset.catId = cat.id;
    choice.disabled = cat.id === otherId;
    const image = document.createElement('img'); image.src = catData(cat).image; image.alt = '';
    const name = document.createElement('b'); name.textContent = catName(cat);
    const location = document.createElement('small'); location.textContent = cat.mountain === 'burning' ? t('burning_mountain') : t('arid_mountain');
    choice.append(image, name, location);
    return choice;
  });
  container.replaceChildren(...buttons);
}
function renderMixerSelected(container, cat) {
  container.replaceChildren();
  if (!cat) {
    container.classList.add('is-empty');
    container.textContent = t('mixer_choose');
    return;
  }
  container.classList.remove('is-empty');
  const image = document.createElement('img'); image.src = catData(cat).image; image.alt = catName(cat);
  const name = document.createElement('b'); name.textContent = catName(cat);
  container.append(image, name);
}
function renderCubeMixer() {
  cubeMixerModal.querySelector('#cube-mixer-title').textContent = t('cube_mixer');
  cubeMixerModal.querySelector('.modal-close').setAttribute('aria-label', t('mixer_close'));
  const headings = cubeMixerModal.querySelectorAll('.mixer-parent-options h3');
  headings[0].textContent = t('mixer_first_cat');
  headings[1].textContent = t('mixer_second_cat');
  renderMixerParentRow(mixerRowOne, 0);
  renderMixerParentRow(mixerRowTwo, 1);
  renderMixerSelected(mixerSelectedOne, gameState.cats.find(cat => cat.id === mixerSelection[0]));
  renderMixerSelected(mixerSelectedTwo, gameState.cats.find(cat => cat.id === mixerSelection[1]));
  const activeBreed = gameState.breeds.find(breed => (breed.mixerMountain || breed.mountain) === activeMixerMountain);
  const breedButton = cubeMixerModal.querySelector('[data-action="breed-cats"]');
  const selectedParents = mixerSelection.map(id => gameState.cats.find(cat => cat.id === id));
  const selectedOffspring = selectedParents[0] && selectedParents[1] && selectedParents[0].id !== selectedParents[1].id
    ? offspringType(selectedParents[0], selectedParents[1]) : null;
  breedButton.textContent = selectedOffspring
    ? t('mixer_mix_duration', { duration: formatDuration(getBreedDuration(selectedOffspring)) })
    : t('mixer_mix');
  breedButton.disabled = Boolean(activeBreed) || !mixerSelection[0] || !mixerSelection[1] || mixerSelection[0] === mixerSelection[1];
  const queue = cubeMixerModal.querySelector('#mixer-breeding-queue');
  queue.replaceChildren();
  gameState.breeds.filter(breed => (breed.mixerMountain || breed.mountain) === activeMixerMountain).forEach(breed => {
    const remaining = Math.max(0, getBreedDuration(breed.type) - (Date.now() - breed.startedAt));
    const row = document.createElement('div'); row.className = 'mixer-breed-row';
    const line = document.createElement('p'); line.className = 'mixer-breed-timer';
    line.textContent = t('breed_in_progress', { name: catName({ type: breed.type }), duration: formatDuration(remaining) });
    const speed = document.createElement('button'); speed.type = 'button'; speed.className = 'cat-action mixer-speed-up';
    speed.dataset.action = 'speed-up-breeding'; speed.dataset.breedId = breed.id;
    speed.disabled = gameState.rubies < 1 && remaining > 0;
    speed.innerHTML = `<img class="currency-icon" src="Ruby.png" alt="">${t('breed_speed_up')}`;
    row.append(line, speed); queue.append(row);
  });
}
function createOwnedCat(type, mountain = activeMountainId) {
  if (!isCatCompatibleWithMountain(type, mountain)) return null;
  const previousMountain = activeMountainId;
  activeMountainId = mountain;
  const tile = findAvailableTile();
  activeMountainId = previousMountain;
  if (!tile || !CAT_CATALOG[type]) return null;
  const data = CAT_CATALOG[type];
  const cat = {
    id: `${type}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    type, mountain, level: 1, rarity: data.rarity || 'Simple', rarityWeight: data.rarityWeight || 1,
    row: tile[0], column: tile[1], lastProducedAt: Date.now()
  };
  gameState.cats.push(cat);
  return cat;
}
function offspringType(first, second) {
  if (first.type === second.type) return first.type;
  const elements = [...new Set([...catData(first).elements, ...catData(second).elements])].sort();
  const match = Object.entries(CAT_CATALOG).find(([, data]) => [...data.elements].sort().join('|') === elements.join('|'));
  if (match) return match[0];
  const rareCats = Object.entries(CAT_CATALOG).filter(([, data]) => (data.rarityWeight || 1) > 1);
  if (loveTotemBoostActive() && rareCats.length && Math.random() < .25) return rareCats[Math.floor(Math.random() * rareCats.length)][0];
  return Math.random() < .5 ? first.type : second.type;
}
function breedSelectedCats() {
  const [first, second] = mixerSelection.map(id => gameState.cats.find(cat => cat.id === id));
  if (!first || !second || first.id === second.id) return;
  const type = offspringType(first, second);
  const duration = getBreedDuration(type);
  if (gameState.breeds.some(breed => (breed.mixerMountain || breed.mountain) === activeMixerMountain)) return;
  gameState.breeds.push({ id: `breed-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type, mountain: activeMixerMountain, mixerMountain: activeMixerMountain, startedAt: Date.now() });
  mixerSelection = [null, null];
  saveAndRender();
  renderCubeMixer();
  flashSoundNote(t('breed_started', { duration: formatDuration(duration) }));
}
function speedUpBreeding(breedId) {
  const breed = gameState.breeds.find(item => item.id === breedId);
  if (!breed) return;
  const finishedNaturally = Date.now() - breed.startedAt >= getBreedDuration(breed.type);
  const cost = finishedNaturally ? 0 : 1;
  if (gameState.rubies < cost) { flashSoundNote(t('hatch_no_rubies')); return; }
  gameState.rubies -= cost;
  gameState.breeds = gameState.breeds.filter(item => item.id !== breed.id);
  addCube(breed.type, breed.mountain);
  saveAndRender();
  renderCubeMixer();
  if (!hatcherModal.hidden) renderHatcher();
  flashSoundNote(t('breed_speed_success'));
}
function closeCatalogue() { catalogueModal.hidden = true; }
function openCatalogueCat(type) {
  const entry = CAT_STICKERS.find(item => item.type === type);
  if (!entry) return;
  const ownedCat = gameState.cats.find(cat => cat.type === type);
  cataloguePreviewOnly = !ownedCat;
  selectedCatId = ownedCat?.id || null;
  const preview = ownedCat || { type, level: 1 };
  renderCatPanel(preview);
  catPanel.hidden = false;
}
function buildingIsOwned(building, mountain = activeMountainId) {
  if (building.id === 'love_totem') return hasLoveTotem();
  if (building.id === 'farm') return gameState.buildings.filter(item => item.id === 'farm' && item.mountain === mountain).length >= 2;
  if (building.id === 'gym') return gameState.buildings.some(item => item.id === 'gym');
  return building.installed === true || gameState.buildings.some(item => item.id === building.id && item.mountain === mountain);
}
function gymBoostActive(now = Date.now()) {
  const gym = gameState.buildings.find(item => item.id === 'gym');
  return Boolean(gym && Number.isFinite(gym.activeUntil) && gym.activeUntil > now);
}
function renderGymMessage() {
  const gym = gameState.buildings.find(item => item.id === 'gym');
  const button = document.querySelector('.building-message-gym');
  if (!gym || !button) return;
  const now = Date.now();
  button.disabled = true;
  if (gym.activeUntil > now) {
    button.textContent = t('gym_boost_active', { duration: formatDuration(gym.activeUntil - now) });
  } else if (gym.readyAt > now) {
    button.textContent = t('gym_cooldown', { duration: formatDuration(gym.readyAt - now) });
  } else {
    button.textContent = t('gym_activate');
    button.disabled = false;
  }
}
function renderLoveTotemMessage() {
  const totem = gameState.buildings.find(item => item.id === 'love_totem');
  const button = document.querySelector('.building-message-gym');
  if (!totem || !button) return;
  const now = Date.now();
  button.disabled = true;
  if (totem.activeUntil > now) {
    button.textContent = t('love_totem_boost_active', { duration: formatDuration(totem.activeUntil - now) });
  } else if (totem.readyAt > now) {
    button.textContent = t('love_totem_cooldown', { duration: formatDuration(totem.readyAt - now) });
  } else {
    button.textContent = t(gameState.rubies >= 1 ? 'love_totem_activate' : 'love_totem_no_rubies');
    button.disabled = gameState.rubies < 1;
  }
}
function renderShop() {
  const offeredType = shopCatType();
  const offered = CAT_CATALOG[offeredType];
  const catNameText = catName({ type: offeredType });
  document.querySelector('.shop-cat-art').src = offered.image;
  document.querySelector('.shop-cat-art').alt = catNameText;
  document.querySelector('.shop-cat-info h3').textContent = catNameText;
  const offeredRarity = offered.rarity || 'Simple';
  document.querySelector('.shop-cat-info .detail-chip').innerHTML = `<img src="${offeredRarity === 'Moderate' ? 'uploads/Moderate_rarity.png' : 'uploads/Simple_rarity.png'}" alt=""><span>${t(offeredRarity === 'Moderate' ? 'moderate' : 'simple')}</span>`;
  document.querySelector('.shop-cat-info p').textContent = offeredType === 'floralis' ? t('floralis_shop_description') : offeredType === 'smokire' ? t('smokire_blurb') : t('shop_cat_blurb');
  buyCatButton.textContent = t('buy_cat', { price: formatNumber(offered.price) });
  const showMetropolisRocky = activeMountainId === 'metropolis';
  document.querySelector('#metropolis-rocky-card').hidden = !showMetropolisRocky;
  const metropolisRockyButton = document.querySelector('#buy-metropolis-rocky-button');
  metropolisRockyButton.hidden = !showMetropolisRocky;
  metropolisRockyButton.textContent = t('buy_cat', { price: formatNumber(CAT_CATALOG.rocky.price) });
  const metropolisFloralisCard = document.querySelector('#metropolis-floralis-card');
  const metropolisFloralisButton = document.querySelector('#buy-metropolis-floralis-button');
  metropolisFloralisCard.hidden = !showMetropolisRocky;
  metropolisFloralisButton.hidden = !showMetropolisRocky;
  metropolisFloralisButton.textContent = t('buy_cat', { price: formatNumber(CAT_CATALOG.floralis.price) });
  const volcanicBuyButton = document.querySelector('#buy-volcanic-cat-button');
  const volcanicAvailable = isCatCompatibleWithMountain('volcanic_lava', activeMountainId);
  document.querySelector('.volcanic-shop-card').hidden = !volcanicAvailable;
  volcanicBuyButton.hidden = !volcanicAvailable;
  volcanicBuyButton.textContent = t('volcanic_buy', { price: formatNumber(CAT_CATALOG.volcanic_lava.rubyPrice) });
  volcanicBuyButton.disabled = gameState.rubies < CAT_CATALOG.volcanic_lava.rubyPrice;
  const florestalisAvailable = isCatCompatibleWithMountain('florestalis', activeMountainId);
  const florestalisBuyButton = document.querySelector('#buy-florestalis-cat-button');
  document.querySelector('.florestalis-shop-card').hidden = !florestalisAvailable;
  florestalisBuyButton.hidden = !florestalisAvailable;
  florestalisBuyButton.textContent = t('volcanic_buy', { price: formatNumber(CAT_CATALOG.florestalis.rubyPrice) });
  florestalisBuyButton.disabled = gameState.rubies < CAT_CATALOG.florestalis.rubyPrice;
  document.querySelectorAll('[data-shop-tab]').forEach(button => button.classList.toggle('is-active', button.dataset.shopTab === shopTab));
  document.querySelector('#shop-cats').hidden = shopTab !== 'cats';
  document.querySelector('#shop-buildings').hidden = shopTab !== 'buildings';
  if (shopPanel.hidden) return;
  const signature = [currentLanguage, activeMountainId, shopTab, selectedBuildingId, gameState.buildings.length, gameState.loveTotemUnlocked].join(':');
  if (signature === shopRenderSignature) return;
  shopRenderSignature = signature;
  const list = document.querySelector('#building-list');
  list.replaceChildren();
  BUILDING_CATALOG.forEach(building => {
    if (building.id === 'love_totem' && !gameState.loveTotemUnlocked && !hasLoveTotem()) return;
    const owned = buildingIsOwned(building);
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'building-choice' + (selectedBuildingId === building.id ? ' is-selected' : '');
    item.dataset.action = 'select-building';
    item.dataset.buildingId = building.id;
    const image = document.createElement('img');
    image.src = building.image;
    image.alt = '';
    const name = document.createElement('span');
    name.textContent = t(building.id);
    const status = document.createElement('small');
    const farmCount = gameState.buildings.filter(item => item.id === 'farm' && item.mountain === activeMountainId).length;
    status.textContent = building.id === 'farm' ? `${farmCount}/2 · ${owned ? t('building_owned') : `${formatNumber(building.price)} ${t('silver')}`}` : building.id === 'love_totem' && gameState.loveTotemUnlocked && !owned ? t('love_totem_ready') : owned ? t(building.installed ? 'building_installed' : 'building_owned') : `${formatNumber(building.price)} ${t('silver')}`;
    item.append(image, name, status);
    list.append(item);
  });
  const detail = document.querySelector('#building-detail');
  const building = BUILDING_CATALOG.find(item => item.id === selectedBuildingId);
  detail.hidden = !building;
  if (!building) return;
  const owned = buildingIsOwned(building);
  document.querySelector('.building-art').src = building.image;
  document.querySelector('.building-art').alt = t(building.id);
  document.querySelector('[data-building-name]').textContent = t(building.id);
  const description = document.querySelector('[data-building-description]');
  description.hidden = building.id !== 'love_totem';
  description.textContent = building.id === 'love_totem' ? t('love_totem_description') : '';
  document.querySelector('[data-building-price]').textContent = owned ? t(building.installed ? 'building_installed' : 'building_owned') : building.id === 'love_totem' ? t('love_totem_ready') : `${formatNumber(building.price)} ${t('silver')}`;
  const purchaseButton = document.querySelector('#buy-building-button');
  purchaseButton.textContent = owned ? t(building.installed ? 'building_installed' : 'building_owned') : building.id === 'love_totem' ? t('place_love_totem') : t('building_buy', { price: formatNumber(building.price) });
  purchaseButton.disabled = owned || (building.id === 'love_totem' && !gameState.loveTotemUnlocked);
}
function renderMountainChoices() {
  if (!mountainChoices) return;
  const signature = currentLanguage + ':' + gameState.playerLevel + ':' + gameState.mountainousMetropolisUnlocked;
  if (signature === mountainChoicesSignature) return;
  mountainChoicesSignature = signature;
  const fragment = document.createDocumentFragment();
  MOUNTAIN_CATALOG.forEach(mountain => {
    const unlocked = mountain.id === 'metropolis' ? gameState.mountainousMetropolisUnlocked : gameState.playerLevel >= mountain.unlockLevel;
    const choice = document.createElement('button');
    choice.type = 'button';
    choice.className = 'location-choice ' + (mountain.id === 'burning' ? 'burning-choice' : mountain.id === 'metropolis' ? 'metropolis-choice' : mountain.id === 'greenfields' ? 'greenfields-choice' : 'arid-choice');
    choice.dataset.mountainId = mountain.id;
    choice.dataset.action = mountain.id === 'metropolis' && !unlocked ? 'locked-metropolis' : unlocked ? 'open-mountain' : 'locked-mountain';
    choice.disabled = mountain.id !== 'metropolis' && !unlocked;
    const art = document.createElement('div');
    art.className = 'location-art';
    const image = document.createElement('img');
    image.src = mountain.image;
    image.alt = '';
    art.append(image);
    if (mountain.element && mountain.elementImage) {
      const element = document.createElement('span');
      element.className = 'mountain-element';
      const elementImage = document.createElement('img');
      elementImage.src = mountain.elementImage;
      elementImage.alt = '';
      const elementName = document.createElement('span');
      elementName.textContent = mountain.element === 'Earth' ? t('earth') : mountain.element === 'Plant' ? t('plant') : t('fire');
      element.append(elementImage, elementName);
      art.append(element);
    }
    const title = document.createElement('span');
    title.textContent = t(mountain.id === 'metropolis' ? 'mountainous_metropolis' : mountain.id === 'burning' ? 'burning_mountain' : mountain.id === 'greenfields' ? 'greenfields_mountain' : 'arid_mountain');
    choice.append(art, title);
    if (mountain.id === 'metropolis' && !unlocked) {
      const lock = document.createElement('b');
      lock.className = 'mountain-lock';
      lock.textContent = '🔒';
      art.append(lock);
      choice.classList.add('locked-metropolis');
    }
    if (!unlocked && mountain.unlockLevel) {
      const requirement = document.createElement('small');
      requirement.className = 'mountain-level-requirement';
      requirement.textContent = t('unlock_level', { level: mountain.unlockLevel });
      choice.append(requirement);
    }
    fragment.append(choice);
  });
  for (let index = 0; index < 3; index += 1) {
    const coming = document.createElement('button');
    coming.type = 'button';
    coming.className = 'location-choice coming-choice';
    coming.dataset.action = 'coming';
    const question = document.createElement('b');
    question.textContent = '?';
    const label = document.createElement('span');
    label.textContent = t('coming_soon');
    coming.append(question, label);
    fragment.append(coming);
  }
  mountainChoices.replaceChildren(fragment);
}
function saveAndRender() {
  saveGame();
  renderGameState();
  showNextLevelUp();
}
function openOnlineProfile() {
  if (!onlineProfileModal.hidden) return;
  const form = document.querySelector('#online-profile-form');
  form.elements.username.value = gameState.onlineProfile?.username || '';
  const avatar = gameState.onlineProfile?.catType || 'rocky';
  form.querySelectorAll('input[name="avatar"]').forEach(input => {
    input.checked = input.value === avatar;
    input.closest('.profile-avatar-choice').classList.toggle('is-selected', input.checked);
  });
  onlineProfileModal.hidden = false;
  if (!gameState.onlineProfile) form.elements.username.focus();
}
function awardXp(amount) {
  gameState.xp += amount;
  while (gameState.xp >= 500 * (2 ** (gameState.playerLevel - 1))) {
    gameState.xp -= 500 * (2 ** (gameState.playerLevel - 1));
    gameState.playerLevel += 1;
    gameState.silver += LEVEL_UP_REWARD.silver;
    gameState.rubies += LEVEL_UP_REWARD.rubies;
    pendingLevelUps.push({
      level: gameState.playerLevel,
      rewards: { ...LEVEL_UP_REWARD },
      unlocks: [
        ...MOUNTAIN_CATALOG.filter(item => item.unlockLevel === gameState.playerLevel && item.unlockLevel > 1).map(item => item.name),
        ...LEVEL_UNLOCKS.filter(item => item.level === gameState.playerLevel).map(() => t('online_battles'))
      ]
    });
  }
}
function showNextLevelUp() {
  if (!levelUpScreen.hidden) return;
  if (pendingLevelUps.length === 0) {
    if (gameState.playerLevel >= 3 && !gameState.onlineProfile && onlineProfileModal.hidden) openOnlineProfile();
    return;
  }
  const result = pendingLevelUps.shift();
  document.querySelector('[data-level-up-number]').textContent = result.level;
  levelUpRewards.replaceChildren();
  [
    { image: 'Silver.png', amount: result.rewards.silver, name: t('silver') },
    { image: 'Ruby.png', amount: result.rewards.rubies, name: t('rubies') }
  ].forEach(reward => {
    const item = document.createElement('li');
    const icon = document.createElement('img');
    icon.src = reward.image;
    icon.alt = '';
    const text = document.createElement('span');
    text.textContent = '+' + reward.amount + ' ' + reward.name;
    item.append(icon, text);
    levelUpRewards.append(item);
  });
  result.unlocks.forEach(name => {
    const item = document.createElement('li');
    item.className = 'content-unlock';
    item.textContent = name;
    levelUpRewards.append(item);
  });
  levelUpScreen.hidden = false;
}
function applySavedGame(data) {
  if (!data || typeof data !== 'object') return;
  gameState.silver = Number.isFinite(data.silver) ? Math.max(0, data.silver + (data.currencySchema >= 3 ? 0 : (Number.isFinite(data.gold) ? data.gold : 0))) : 500;
  gameState.buildings = Array.isArray(data.buildings) ? data.buildings.filter(item => item && typeof item.id === 'string' && typeof item.mountain === 'string').map((item, index) => ({ ...item, uid: typeof item.uid === 'string' ? item.uid : `${item.id}-${item.mountain}-${index}` })) : [];
  gameState.buildings.filter(building => building.id === 'feline_stocks').forEach(building => {
    building.unlockedSlots = Math.max(5, Math.min(15, Number.isInteger(building.unlockedSlots) ? building.unlockedSlots : 5));
    building.stockedCats = Array.isArray(building.stockedCats) ? building.stockedCats.slice(0, 15) : [];
  });
  gameState.eggs = Array.isArray(data.eggs) ? data.eggs.filter(item => item && ['rocky','smokire','volcanic_lava','floralis','florestalis'].includes(item.type) && MOUNTAIN_CATALOG.some(mountain => mountain.id === item.mountain) && Number.isFinite(item.startedAt)) : [];
  gameState.breeds = cleanSavedBreeds(data.breeds);
  gameState.rubies = Number.isFinite(data.rubies) ? Math.max(0, data.rubies) : 20;
  gameState.food = Number.isFinite(data.food) ? Math.max(0, data.food) : 1000;
  gameState.playerLevel = Number.isInteger(data.playerLevel) && data.playerLevel > 0 ? data.playerLevel : 1;
  gameState.xp = Number.isFinite(data.xp) && data.xp >= 0 ? data.xp : 0;
  gameState.startersCupCompleted = gameState.startersCupCompleted || data.startersCupCompleted === true;
  gameState.rubyCupStage = Math.max(gameState.rubyCupStage, Number.isInteger(data.rubyCupStage) ? Math.max(0, Math.min(5, data.rubyCupStage)) : 0);
  gameState.metropolisCupStage = Math.max(gameState.metropolisCupStage, Number.isInteger(data.metropolisCupStage) ? Math.max(0, Math.min(10, data.metropolisCupStage)) : 0);
  gameState.totemCupStage = Math.max(gameState.totemCupStage, Number.isInteger(data.totemCupStage) ? Math.max(0, Math.min(10, data.totemCupStage)) : 0);
  gameState.loveTotemUnlocked = gameState.loveTotemUnlocked || data.loveTotemUnlocked === true;
  gameState.mountainousMetropolisUnlocked = gameState.mountainousMetropolisUnlocked || data.mountainousMetropolisUnlocked === true;
  gameState.onlineProfile = data.onlineProfile && typeof data.onlineProfile.username === 'string'
    ? { username: data.onlineProfile.username.trim().slice(0, 20), catType: CAT_CATALOG[data.onlineProfile.catType] ? data.onlineProfile.catType : 'rocky' }
    : null;
  gameState.trophies = Number.isInteger(data.trophies) ? Math.max(0, data.trophies) : 100;
  gameState.battleRoster = Array.isArray(data.battleRoster) ? data.battleRoster.filter(id => typeof id === 'string').slice(0, 2) : gameState.battleRoster;
  gameState.cats = [];
  const cats = Array.isArray(data.cats) ? data.cats : (data.catOwned === false ? [] : [{ id: 'rocky-legacy', level: data.catLevel, row: 4, column: 4 }]);
  cats.forEach((savedCat, index) => {
    activeMountainId = compatibleMountainFor(CAT_CATALOG[savedCat?.type] ? savedCat.type : 'rocky', MOUNTAIN_CATALOG.some(item => item.id === savedCat?.mountain) ? savedCat.mountain : 'arid');
    const level = Number.isInteger(savedCat?.level) && savedCat.level > 0 ? savedCat.level : 1;
    const preferredRow = Number.isInteger(savedCat?.row) ? savedCat.row : 4;
    const preferredColumn = Number.isInteger(savedCat?.column) ? savedCat.column : 4;
    let row = preferredRow;
    let column = preferredColumn;
    if (!(savedCat?.storedIn && activeMountainId === savedCat?.mountain) && (!isWalkable(row, column) || occupied(row, column))) {
      const free = findAvailableTile(preferredRow, preferredColumn);
      if (!free) return;
      [row, column] = free;
    }
    gameState.cats.push({
      id: typeof savedCat?.id === 'string' ? savedCat.id : 'rocky-' + index,
      type: CAT_CATALOG[savedCat?.type] ? savedCat.type : 'rocky',
      mountain: activeMountainId,
      storedIn: activeMountainId === savedCat?.mountain && typeof savedCat?.storedIn === 'string' ? savedCat.storedIn : null,
      storedSlot: activeMountainId === savedCat?.mountain && Number.isInteger(savedCat?.storedSlot) ? savedCat.storedSlot : undefined,
      level, rarity: CAT_CATALOG[savedCat?.type]?.rarity || 'Simple', rarityWeight: CAT_CATALOG[savedCat?.type]?.rarityWeight || 1, row, column,
      lastProducedAt: Number.isFinite(savedCat?.lastProducedAt) ? savedCat.lastProducedAt : Date.now()
    });
  });
  gameState.buildings.filter(building => building.id === 'feline_stocks').forEach(building => {
    building.stockedCats = building.stockedCats.map(catId => gameState.cats.some(cat => cat.id === catId && cat.storedIn === building.uid) ? catId : null);
  });
  ensureMountainBuildings();
  activeMountainId = 'arid';
  saveAndRender();
  if (currentScreen === 'mountain') buildMapGrid();
}
async function connectAccountSave() {
  const splash = document.querySelector('#loading-splash');
  const started = Date.now();
  let offlineBattleDelta = 0;
  let offlineBattleCount = 0;
  let offlineBattleXp = 0;
  try {
    const user = await window.websim?.getUser?.();
    if (user) {
      const response = await fetch('/api/save');
      if (response.ok) {
        const result = await response.json();
        accountSaveEnabled = true;
        if (result.save) applySavedGame(result.save);
        else saveGame();
        const claim = await fetch('/api/online/claim', { method: 'POST' });
        if (claim.ok) {
          const report = await claim.json();
          offlineBattleDelta = Number.isInteger(report.delta) ? report.delta : 0;
          offlineBattleCount = Number.isInteger(report.battles) ? report.battles : 0;
          offlineBattleXp = Number.isInteger(report.xp) ? report.xp : 0;
          if (Number.isInteger(report.trophies)) gameState.trophies = Math.max(0, report.trophies);
          if (offlineBattleXp) awardXp(offlineBattleXp);
          if (offlineBattleDelta || offlineBattleXp) saveGame();
          renderGameState();
        }
      }
    }
  } catch (error) {
    console.warn('Account save is unavailable; using this browser save.', error);
  }
  if (gameState.onlineProfile && gameState.playerLevel >= 3) publishOnlinePresence();
  const wait = Math.max(0, 1100 - (Date.now() - started));
  window.setTimeout(() => {
    splash.classList.add('is-leaving');
    window.setTimeout(() => splash.remove(), 380);
    if (gameState.playerLevel >= 3 && !gameState.onlineProfile) openOnlineProfile();
    if (offlineBattleCount) {
      const attackMessage = t(offlineBattleCount === 1 ? 'away_singular' : 'away_plural', { count: offlineBattleCount });
      const trophyMessage = offlineBattleDelta > 0
        ? t('you_won_trophies', { count: offlineBattleDelta })
        : offlineBattleDelta < 0 ? t('you_lost_trophies', { count: Math.abs(offlineBattleDelta) }) : t('trophy_unchanged');
      const xpMessage = offlineBattleXp ? ` ${t('xp_earned', { count: offlineBattleXp })}` : '';
      document.querySelector('#offline-report-message').textContent = `${attackMessage} ${trophyMessage}${xpMessage}`;
      offlineReportModal.hidden = false;
    }
  }, wait);
}
function renderLanguageOptions() {
  languageOptions.replaceChildren();
  languages.forEach(language => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'language-choice';
    button.dataset.action = 'select-language';
    button.dataset.language = language.code;
    button.textContent = language.name;
    languageOptions.append(button);
  });
}
function applyLanguage(language) {
  currentLanguage = translations[language] ? language : 'en';
  localStorage.setItem('catdance-language', currentLanguage);
  document.documentElement.lang = currentLanguage;
  document.querySelectorAll('[data-i18n]').forEach(node => { node.textContent = t(node.dataset.i18n); });
  document.querySelectorAll('[data-i18n-html]').forEach(node => { node.innerHTML = t(node.dataset.i18nHtml); });
  document.querySelectorAll('[data-i18n-aria]').forEach(node => { node.setAttribute('aria-label', t(node.dataset.i18nAria)); });
  document.querySelectorAll('[data-i18n-title]').forEach(node => { node.title = t(node.dataset.i18nTitle); });
  languageOptions.querySelectorAll('[data-language]').forEach(button => {
    button.classList.toggle('is-selected', button.dataset.language === currentLanguage);
  });
  renderGameState();
  if (!hatcherModal.hidden) renderHatcher();
  if (currentScreen === 'battle') renderBattle();
  if (currentScreen === 'mountain') buildMapGrid();
}
const CUBE_HATCH_TIMES = { rocky: 10_000, smokire: 120_000, volcanic_lava: 1_800_000, floralis: 300_000, florestalis: 45 * 60 * 1000 };
const CUBE_IMAGES = { rocky: 'uploads/Rocky_cat_cube.png', smokire: 'uploads/Smokire_cube.png', volcanic_lava: 'uploads/Volcanic_lava_cat_cube.png', floralis: 'uploads/Floralis_cube.png', florestalis: 'uploads/Florestalis_cube.png' };
function getBreedDuration(type) { return type === 'floralis' ? 120_000 : Math.ceil((CUBE_HATCH_TIMES[type] || CUBE_HATCH_TIMES.rocky) / 3); }
function addCube(type, mountain = activeMountainId) {
  gameState.eggs.push({ id: `cube-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type, mountain, startedAt: Date.now() });
}
function rubyHatchCost(egg, now = Date.now()) {
  return Math.floor(Math.max(0, now - egg.startedAt) / (2 * 60 * 60 * 1000)) + 1;
}
function hatchCube(egg, destinationMountain = activeMountainId) {
  if (!isCatCompatibleWithMountain(egg.type, destinationMountain)) return false;
  const previousMountain = activeMountainId;
  activeMountainId = destinationMountain;
  const tile = findAvailableTile();
  activeMountainId = previousMountain;
  if (!tile) return false;
  const cat = {
    id: `${egg.type}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    type: egg.type, mountain: destinationMountain, level: 1, rarity: CAT_CATALOG[egg.type].rarity || 'Simple', rarityWeight: CAT_CATALOG[egg.type].rarityWeight || 1,
    row: tile[0], column: tile[1], lastProducedAt: Date.now()
  };
  gameState.cats.push(cat);
  gameState.eggs = gameState.eggs.filter(item => item.id !== egg.id);
  awardXp(500);
  return cat;
}
async function animateHatchedCat(cat) {
  closeHatcher(); closeCatalogue(); closeCatPanel(); closeShop();
  movingCat = false; movingBuildingId = null;
  const image = document.querySelector('#hatch-transition-art');
  image.src = CUBE_IMAGES[cat.type];
  hatchTransition.hidden = false;
  hatchTransition.className = 'hatch-transition is-visible is-cube';
  await wait(850);
  hatchTransition.classList.add('is-white');
  await wait(500);
  image.src = CAT_CATALOG[cat.type].image;
  hatchTransition.classList.remove('is-cube');
  hatchTransition.classList.add('is-cat');
  hatchTransition.classList.remove('is-white');
  await wait(950);
  activeMountainId = cat.mountain;
  document.querySelector('.mountain-art').src = MOUNTAIN_CATALOG.find(item => item.id === activeMountainId).image;
  showScreen('mountain');
  buildMapGrid();
  hatchTransition.classList.remove('is-visible');
  await wait(650);
  hatchTransition.hidden = true;
  hatchTransition.className = 'hatch-transition';
  await wait(650);
  openCatalogue();
}
async function animateAddedCat(cat) {
  closeCatPanel();
  const image = document.querySelector('#hatch-transition-art');
  image.src = CAT_CATALOG[cat.type].image;
  hatchTransition.hidden = false;
  hatchTransition.className = 'hatch-transition is-visible is-cat';
  await wait(1200);
  hatchTransition.classList.remove('is-visible');
  await wait(600);
  hatchTransition.hidden = true;
  hatchTransition.className = 'hatch-transition';
}
function hatchCompletedCubes() {
  const now = Date.now();
  const completed = gameState.breeds.filter(item => now - item.startedAt >= getBreedDuration(item.type));
  if (completed.length) {
    gameState.breeds = gameState.breeds.filter(item => !completed.includes(item));
    completed.forEach(breed => addCube(breed.type, breed.mountain));
    saveAndRender();
  }
  if (!cubeMixerModal.hidden) renderCubeMixer();
  if (!hatcherModal.hidden) renderHatcher();
}
function openHatcher() { hatchCompletedCubes(); renderHatcher(); hatcherModal.hidden = false; }
function closeHatcher() { hatcherModal.hidden = true; }
function renderHatcher() {
  const list = document.querySelector('#hatcher-eggs');
  const eggs = gameState.eggs;
  document.querySelector('#hatcher-title').textContent = t('hatcher_title');
  hatcherModal.querySelector('.modal-close').setAttribute('aria-label', t('hatcher_close'));
  document.querySelector('#hatcher-empty').textContent = t('hatcher_empty');
  document.querySelector('.hatcher-move').textContent = t('hatcher_move');
  document.querySelector('#hatcher-empty').hidden = eggs.length > 0;
  list.replaceChildren();
  eggs.forEach(egg => {
    const remaining = Math.max(0, CUBE_HATCH_TIMES[egg.type] - (Date.now() - egg.startedAt));
    const cost = rubyHatchCost(egg);
    const card = document.createElement('article');
    card.className = 'hatcher-egg';
    const image = document.createElement('img');
    image.src = CUBE_IMAGES[egg.type]; image.alt = '';
    const info = document.createElement('div'); info.className = 'hatcher-egg-info';
    const title = document.createElement('h3'); title.textContent = t(egg.type === 'florestalis' ? 'cube_florestalis' : egg.type === 'floralis' ? 'cube_floralis' : egg.type === 'rocky' ? 'cube_rocky' : egg.type === 'smokire' ? 'cube_smokire' : 'cube_volcanic_lava');
    const timer = document.createElement('p'); timer.textContent = remaining ? t('cube_hatches_in', { duration: formatDuration(remaining) }) : t('cube_ready');
    info.append(title, timer);
    const hatch = document.createElement('button'); hatch.type = 'button'; hatch.className = 'cat-action hatch-now';
    hatch.dataset.action = 'hatch-cube'; hatch.dataset.cubeId = egg.id;
    const ready = remaining === 0;
    hatch.innerHTML = ready ? t('hatch_free') : `<img class="currency-icon" src="Ruby.png" alt="">${t(cost === 1 ? 'hatch_with_rubies' : 'hatch_with_rubies_plural', { cost })}`;
    hatch.dataset.ready = ready ? 'true' : 'false';
    hatch.disabled = !ready && gameState.rubies < cost;
    card.append(image, info, hatch); list.append(card);
  });
}
function playTone(frequency, duration = .12, type = 'sine', volume = .045) {
  if (!preferences.sounds) return;
  if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
  if (audioContext.state === 'suspended') audioContext.resume();
  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();
  oscillator.type = type;
  oscillator.frequency.value = frequency;
  gain.gain.setValueAtTime(volume, audioContext.currentTime);
  gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + duration);
  oscillator.connect(gain).connect(audioContext.destination);
  oscillator.start();
  oscillator.stop(audioContext.currentTime + duration);
}
function syncMusic() {
  if (!preferences.music) {
    Object.values(audioTracks).forEach(track => track.pause());
    return;
  }
  const nextTrack = currentScreen === 'mountain' ? (activeMountainId === 'metropolis' ? audioTracks.metropolis : audioTracks.mountain) : currentScreen === 'battle' ? audioTracks.battle : audioTracks.main;
  Object.values(audioTracks).forEach(track => { if (track !== nextTrack) track.pause(); });
  if (currentTrack !== nextTrack) {
    currentTrack?.pause();
    nextTrack.currentTime = 0;
    currentTrack = nextTrack;
  }
  nextTrack.play().catch(() => {});
}
function showScreen(name) {
  if (name !== currentScreen && !catPanel.hidden) closeCatPanel();
  currentScreen = name;
  document.querySelector('.mountain-screen').classList.toggle('is-burning', name === 'mountain' && activeMountainId === 'burning');
  document.querySelector('.mountain-world').classList.toggle('is-metropolis', name === 'mountain' && activeMountainId === 'metropolis');
  document.querySelector('.mountain-world').classList.toggle('is-greenfields', name === 'mountain' && activeMountainId === 'greenfields');
  screens.forEach(screen => {
    const active = screen.dataset.screen === name;
    screen.hidden = !active;
    screen.classList.toggle('is-active', active);
  });
  if (name === 'mountain') buildMapGrid();
  syncMusic();
}
function buildMapGrid() {
  const fragment = document.createDocumentFragment();
  const rows = activeMountainId === 'metropolis' ? 14 : mapRows;
  const columns = activeMountainId === 'metropolis' ? 20 : mapColumns;
  mapGrid.classList.toggle('is-metropolis', activeMountainId === 'metropolis');
  mapGrid.style.setProperty('--grid-columns', columns);
  mapGrid.style.setProperty('--grid-rows', rows);
  document.querySelector('.map-canvas').classList.toggle('is-metropolis-map', activeMountainId === 'metropolis');
  for (let row = 1; row <= rows; row++) {
    for (let column = 1; column <= columns; column++) {
      if (!isWalkable(row, column)) continue;
      const cell = document.createElement('button');
      cell.type = 'button';
      cell.className = 'grid-cell';
      cell.style.gridRow = String(row);
      cell.style.gridColumn = String(column);
      cell.dataset.row = row;
      cell.dataset.column = column;
      cell.setAttribute('aria-label', t('choose_tile'));
      fragment.append(cell);
    }
  }
  gameState.cats.filter(cat => !cat.storedIn && (cat.mountain || 'arid') === activeMountainId).forEach(cat => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'map-cat';
    button.style.gridRow = String(cat.row);
    button.style.gridColumn = String(cat.column);
    button.dataset.catId = cat.id;
    button.setAttribute('aria-label', catName() + ', ' + t('level') + ' ' + cat.level);
    const image = document.createElement('img');
    image.src = catData(cat).image;
    image.alt = '';
    button.append(image);
    if (cat.level > 1) {
      const badge = document.createElement('span');
      badge.className = 'map-cat-level';
      badge.textContent = cat.level;
      button.append(badge);
    }
    fragment.append(button);
  });
  gameState.buildings.filter(building => building.mountain === activeMountainId && Number.isInteger(building.row) && Number.isInteger(building.column)).forEach(building => {
    const catalogItem = BUILDING_CATALOG.find(item => item.id === building.id);
    if (!catalogItem) return;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'map-building';
    button.style.gridRow = String(building.row);
    button.style.gridColumn = String(building.column);
    button.dataset.buildingId = building.id;
    button.dataset.buildingUid = building.uid;
    button.dataset.mountainId = building.mountain;
    button.setAttribute('aria-label', t(building.id));
    const image = document.createElement('img');
    image.src = catalogItem.image;
    image.alt = t(building.id);
    button.append(image);
    if ((building.id === 'gym' && gymBoostActive()) || (building.id === 'love_totem' && loveTotemBoostActive())) {
      button.classList.add('gym-active');
      const sparkles = document.createElement('span');
      sparkles.className = 'gym-sparkles';
      sparkles.setAttribute('aria-hidden', 'true');
      sparkles.innerHTML = '<i>✦</i><i>✧</i><i>✦</i><i>✧</i><i>✦</i><i>✧</i>';
      button.append(sparkles);
    }
    fragment.append(button);
  });
  mapGrid.replaceChildren(fragment);
  mapGrid.classList.toggle('is-moving', movingCat || Boolean(movingBuildingId));
}
function openCatPanel(catId) {
  if (!gameState.cats.some(cat => cat.id === catId)) return;
  movingCat = false;
  movingBuildingId = null;
  mapGrid.classList.remove('is-moving');
  selectedCatId = catId;
  cataloguePreviewOnly = false;
  renderCatPanel();
  catPanel.hidden = false;
}
function closeCatPanel() {
  catPanel.hidden = true;
  selectedCatId = null;
  cataloguePreviewOnly = false;
}
function closeShop() { shopPanel.hidden = true; }
function openShop(buildingId = null) {
  closeCatPanel();
  shopTab = buildingId ? 'buildings' : 'cats';
  selectedBuildingId = buildingId;
  shopRenderSignature = '';
  shopPanel.hidden = false;
  renderShop();
}
function setMountainZoom(amount) {
  mountainZoom = Math.max(1, Math.min(2.2, mountainZoom + amount));
  document.querySelector('.mountain-world').style.setProperty('--mountain-zoom', mountainZoom);
}
function closeModal() {
  settingsModal.hidden = true;
  warningModal.hidden = true;
}
function flashSoundNote(message) {
  soundNote.textContent = message;
  soundNote.classList.add('visible');
  window.setTimeout(() => soundNote.classList.remove('visible'), 1800);
}
function placeCat(cat, row, column) {
  if (!isCatCompatibleWithMountain(cat.type, activeMountainId) || !isWalkable(row, column) || occupied(row, column, cat.id)) return false;
  cat.row = row;
  cat.column = column;
  return true;
}
function placeBuilding(building, row, column) {
  if (!isWalkable(row, column) || occupied(row, column, building.id)) return false;
  building.row = row;
  building.column = column;
  return true;
}
function produceSilver() {
  const timestamp = Date.now();
  let produced = 0;
  gameState.cats.forEach(cat => {
    if (cat.storedIn) return;
    const interval = productionInterval(cat);
    const elapsed = timestamp - cat.lastProducedAt;
    if (elapsed < interval) return;
    const count = Math.floor(elapsed / interval);
    cat.lastProducedAt += count * interval;
    gameState[catData(cat).resource] += count;
    produced += count;
  });
  gameState.buildings.filter(building => building.id === 'farm' && building.production?.endsAt > building.production?.lastAt).forEach(farm => {
    const production = farm.production;
    const until = Math.min(timestamp, production.endsAt);
    const elapsed = Math.max(0, until - production.lastAt);
    const count = Math.floor(elapsed * production.rate / 60000);
    if (count > 0) {
      gameState.food += count;
      production.lastAt += Math.floor(count * 60000 / production.rate);
      produced += count;
    }
  });
  if (produced) saveAndRender();
  if (currentScreen === 'mountain') {
    const gymOnMap = mapGrid.querySelector('.map-building[data-building-id="gym"]')?.classList.contains('gym-active') || false;
    const totemOnMap = mapGrid.querySelector('.map-building[data-building-id="love_totem"]')?.classList.contains('gym-active') || false;
    const hasTotemOnMap = gameState.buildings.some(building => building.id === 'love_totem' && building.mountain === activeMountainId);
    if (gymOnMap !== gymBoostActive(timestamp) || (hasTotemOnMap && totemOnMap !== loveTotemBoostActive(timestamp))) {
      buildMapGrid();
      if (hasTotemOnMap && !catPanel.hidden) renderCatPanel();
    }
  }
  if (!buildingMessageModal.hidden && buildingMessageModal.dataset.buildingId === 'gym') renderGymMessage();
  if (!buildingMessageModal.hidden && buildingMessageModal.dataset.buildingId === 'love_totem') renderLoveTotemMessage();
  if (!farmModal.hidden && selectedFarmUid) updateFarmCountdown();
}
const FARM_OPTIONS = [
  { cost:10, rate:1 }, { cost:100, rate:11 }, { cost:500, rate:65 },
  { cost:1000, rate:186 }, { cost:5000, rate:709 }, { cost:10000, rate:1992 }
];
function openFarm(uid) {
  selectedFarmUid = uid;
  renderFarmModal();
  farmModal.hidden = false;
}
function closeFarm() { farmModal.hidden = true; selectedFarmUid = null; }
function renderFarmModal() {
  const farm = gameState.buildings.find(item => item.uid === selectedFarmUid && item.id === 'farm');
  if (!farm) return closeFarm();
  updateFarmCountdown();
  const active = farm.production?.endsAt > Date.now();
  document.querySelector('#farm-options').innerHTML = FARM_OPTIONS.map(option => `<button class="farm-option" data-action="start-farm-production" data-cost="${option.cost}" data-rate="${option.rate}" ${active || gameState.silver < option.cost ? 'disabled' : ''}><span>${t('farm_rate_option', { amount: formatNumber(option.cost) })}</span><small>${t('farm_rate_details', { amount: formatNumber(option.rate) })}</small></button>`).join('');
}
function updateFarmCountdown() {
  const farm = gameState.buildings.find(item => item.uid === selectedFarmUid && item.id === 'farm');
  if (!farm) return;
  const remaining = Math.max(0, (farm.production?.endsAt || 0) - Date.now());
  document.querySelector('#farm-time').textContent = remaining > 0
    ? t('farm_producing', { amount: formatNumber(farm.production.rate), duration: formatDuration(remaining) })
    : t('farm_choose_rate');
  if (!remaining) document.querySelectorAll('.farm-option').forEach(button => { button.disabled = gameState.silver < Number(button.dataset.cost); });
}
function formatDuration(ms) {
  const totalSeconds = Math.ceil(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return t('duration_format', { hours, minutes, seconds });
}
function openLanguages() { languageModal.hidden = false; }
function closeLanguages() { languageModal.hidden = true; }

const RUBY_CUP_REWARDS = [
  { xp: 500, rubies: 0 },
  { xp: 6000, rubies: 1 },
  { xp: 10000, rubies: 5 },
  { xp: 70500, rubies: 10 },
  { xp: 100000, rubies: 50, smokire: 1 }
];
const TOTEM_CUP_REWARDS = [
  ...Array.from({ length: 3 }, () => ({ xp: 20000 })),
  ...Array.from({ length: 3 }, () => ({ xp: 40000, silver: 100000 })),
  ...Array.from({ length: 3 }, () => ({ xp: 80000, silver: 200000 })),
  { xp: 160000, silver: 400000, loveTotem: true }
];
const METROPOLIS_CUP_REWARDS = [
  ...Array.from({ length: 4 }, () => ({ xp: 500000, rubies: 0 })),
  ...Array.from({ length: 4 }, () => ({ xp: 1000000, rubies: 5 })),
  { xp: 1500000, rubies: 10 },
  { xp: 2000000, rubies: 0, mountain: 'metropolis' }
];
const newFeatureTranslations = {
  en: {
    shop: { gym:'Gym', gym_description:'All your cats deal 23% more damage for 5 hours. After activation, the Gym needs 12 hours before it can be used again.', gym_activate:'Activate · 23% stronger for 5 hours', gym_boost_active:'Boost active · {duration} left', gym_cooldown:'Ready in {duration}', gym_started:'Gym boost activated!', mountainous_metropolis:'Mountainous Metropolis' },
    battle: { metropolis_cup:'Metropolis Cup', metropolis_complete:'Complete', metropolis_stage:'Stage {number} / {total}', metropolis_cup_complete:'Metropolis Cup complete!', choose_two_cats_metropolis:'Choose 2 cats for Metropolis Cup', metropolis_locked_message:'You need to complete Metropolis Cup to unlock Mountainous Metropolis!' }
  },
  es: {
    shop: { gym:'Gimnasio', gym_description:'Todos tus gatos infligen un 23 % más de daño durante 5 horas. Tras activarlo, el gimnasio necesita 12 horas antes de volver a usarse.', gym_activate:'Activar · 23 % más de fuerza durante 5 horas', gym_boost_active:'Potenciador activo · quedan {duration}', gym_cooldown:'Disponible en {duration}', gym_started:'¡Potenciador del gimnasio activado!', mountainous_metropolis:'Metrópolis Montañosa' },
    battle: { metropolis_cup:'Copa Metrópolis', metropolis_complete:'Completada', metropolis_stage:'Fase {number} / {total}', metropolis_cup_complete:'¡Copa Metrópolis completada!', choose_two_cats_metropolis:'Elige 2 gatos para la Copa Metrópolis', metropolis_locked_message:'¡Debes completar la Copa Metrópolis para desbloquear la Metrópolis Montañosa!' }
  },
  pt: {
    shop: { gym:'Ginásio', gym_description:'Todos os seus gatos causam 23% mais dano durante 5 horas. Após a ativação, o ginásio precisa de 12 horas para poder ser usado novamente.', gym_activate:'Ativar · 23% mais força por 5 horas', gym_boost_active:'Bônus ativo · restam {duration}', gym_cooldown:'Disponível em {duration}', gym_started:'Bônus do ginásio ativado!', mountainous_metropolis:'Metrópole Montanhosa' },
    battle: { metropolis_cup:'Copa Metrópole', metropolis_complete:'Concluída', metropolis_stage:'Fase {number} / {total}', metropolis_cup_complete:'Copa Metrópole concluída!', choose_two_cats_metropolis:'Escolha 2 gatos para a Copa Metrópole', metropolis_locked_message:'Conclua a Copa Metrópole para desbloquear a Metrópole Montanhosa!' }
  },
  it: {
    shop: { gym:'Palestra', gym_description:'Tutti i tuoi gatti infliggono il 23% di danni in più per 5 ore. Dopo l’attivazione, la palestra deve attendere 12 ore prima di poter essere usata di nuovo.', gym_activate:'Attiva · +23% di forza per 5 ore', gym_boost_active:'Potenziamento attivo · restano {duration}', gym_cooldown:'Disponibile tra {duration}', gym_started:'Potenziamento della palestra attivato!', mountainous_metropolis:'Metropoli Montuosa' },
    battle: { metropolis_cup:'Coppa Metropoli', metropolis_complete:'Completata', metropolis_stage:'Fase {number} / {total}', metropolis_cup_complete:'Coppa Metropoli completata!', choose_two_cats_metropolis:'Scegli 2 gatti per la Coppa Metropoli', metropolis_locked_message:'Completa la Coppa Metropoli per sbloccare la Metropoli Montuosa!' }
  },
  de: {
    shop: { gym:'Fitnessstudio', gym_description:'Alle deine Katzen verursachen 5 Stunden lang 23 % mehr Schaden. Nach der Aktivierung kann das Studio erst nach 12 Stunden wieder benutzt werden.', gym_activate:'Aktivieren · 5 Stunden lang 23 % stärker', gym_boost_active:'Boost aktiv · noch {duration}', gym_cooldown:'Verfügbar in {duration}', gym_started:'Gym-Boost aktiviert!', mountainous_metropolis:'Bergmetropole' },
    battle: { metropolis_cup:'Metropolenpokal', metropolis_complete:'Abgeschlossen', metropolis_stage:'Stufe {number} / {total}', metropolis_cup_complete:'Metropolenpokal abgeschlossen!', choose_two_cats_metropolis:'Wähle 2 Katzen für den Metropolenpokal', metropolis_locked_message:'Schließe den Metropolenpokal ab, um die Bergmetropole freizuschalten!' }
  },
  nl: {
    shop: { gym:'Sportschool', gym_description:'Al je katten doen 5 uur lang 23% meer schade. Na activatie kan de sportschool pas na 12 uur opnieuw worden gebruikt.', gym_activate:'Activeren · 5 uur lang 23% sterker', gym_boost_active:'Boost actief · nog {duration}', gym_cooldown:'Beschikbaar over {duration}', gym_started:'Sportschoolboost geactiveerd!', mountainous_metropolis:'Bergmetropool' },
    battle: { metropolis_cup:'Metropoolbeker', metropolis_complete:'Voltooid', metropolis_stage:'Fase {number} / {total}', metropolis_cup_complete:'Metropoolbeker voltooid!', choose_two_cats_metropolis:'Kies 2 katten voor de Metropoolbeker', metropolis_locked_message:'Voltooi de Metropoolbeker om de Bergmetropool vrij te spelen!' }
  },
  sv: {
    shop: { gym:'Gym', gym_description:'Alla dina katter gör 23 % mer skada i 5 timmar. Efter aktivering kan gymmet användas igen efter 12 timmar.', gym_activate:'Aktivera · 23 % starkare i 5 timmar', gym_boost_active:'Förstärkning aktiv · {duration} kvar', gym_cooldown:'Redo om {duration}', gym_started:'Gymförstärkning aktiverad!', mountainous_metropolis:'Bergsmetropolen' },
    battle: { metropolis_cup:'Metropolcupen', metropolis_complete:'Klar', metropolis_stage:'Steg {number} / {total}', metropolis_cup_complete:'Metropolcupen är klar!', choose_two_cats_metropolis:'Välj 2 katter till Metropolcupen', metropolis_locked_message:'Slutför Metropolcupen för att låsa upp Bergsmetropolen!' }
  },
  ru: {
    shop: { gym:'Тренажёрный зал', gym_description:'Все ваши коты наносят на 23% больше урона в течение 5 часов. После активации зал можно использовать снова через 12 часов.', gym_activate:'Активировать · сила +23% на 5 часов', gym_boost_active:'Усиление действует · осталось {duration}', gym_cooldown:'Будет готово через {duration}', gym_started:'Усиление зала активировано!', mountainous_metropolis:'Горный мегаполис' },
    battle: { metropolis_cup:'Кубок мегаполиса', metropolis_complete:'Пройден', metropolis_stage:'Этап {number} / {total}', metropolis_cup_complete:'Кубок мегаполиса пройден!', choose_two_cats_metropolis:'Выберите 2 котов для Кубка мегаполиса', metropolis_locked_message:'Пройдите Кубок мегаполиса, чтобы открыть Горный мегаполис!' }
  },
  zh: {
    shop: { gym:'健身房', gym_description:'所有猫咪的伤害提高23%，持续5小时。激活后，健身房需等待12小时才能再次使用。', gym_activate:'激活 · 伤害提高23%，持续5小时', gym_boost_active:'强化生效中 · 剩余{duration}', gym_cooldown:'{duration}后可用', gym_started:'健身房强化已激活！', mountainous_metropolis:'山岳都市' },
    battle: { metropolis_cup:'大都会杯', metropolis_complete:'已完成', metropolis_stage:'第{number}/{total}阶段', metropolis_cup_complete:'大都会杯已完成！', choose_two_cats_metropolis:'选择2只猫参加大都会杯', metropolis_locked_message:'完成大都会杯即可解锁山岳都市！' }
  },
  ja: {
    shop: { gym:'ジム', gym_description:'すべてのネコの攻撃力が5時間、23%アップします。発動後、ジムは12時間再使用できません。', gym_activate:'発動 · 5時間攻撃力23%アップ', gym_boost_active:'強化中 · 残り{duration}', gym_cooldown:'{duration}後に使用可能', gym_started:'ジムの強化を発動しました！', mountainous_metropolis:'山岳メトロポリス' },
    battle: { metropolis_cup:'メトロポリスカップ', metropolis_complete:'完了', metropolis_stage:'ステージ {number} / {total}', metropolis_cup_complete:'メトロポリスカップ制覇！', choose_two_cats_metropolis:'メトロポリスカップに参加するネコを2匹選択', metropolis_locked_message:'メトロポリスカップをクリアすると山岳メトロポリスが解放されます！' }
  },
  ko: {
    shop: { gym:'체육관', gym_description:'모든 고양이의 공격력이 5시간 동안 23% 증가해요. 활성화 후 12시간이 지나야 다시 사용할 수 있어요.', gym_activate:'활성화 · 5시간 동안 공격력 23% 증가', gym_boost_active:'강화 효과 활성화 · {duration} 남음', gym_cooldown:'{duration} 후 사용 가능', gym_started:'체육관 강화 효과가 활성화됐어요!', mountainous_metropolis:'산악 메트로폴리스' },
    battle: { metropolis_cup:'메트로폴리스 컵', metropolis_complete:'완료', metropolis_stage:'스테이지 {number} / {total}', metropolis_cup_complete:'메트로폴리스 컵 완료!', choose_two_cats_metropolis:'메트로폴리스 컵에 참가할 고양이 2마리를 선택하세요', metropolis_locked_message:'메트로폴리스 컵을 완료하면 산악 메트로폴리스가 열려요!' }
  },
  ms: {
    shop: { gym:'Gim', gym_description:'Semua kucing anda memberikan 23% lebih banyak kerosakan selama 5 jam. Selepas diaktifkan, Gim perlu menunggu 12 jam sebelum boleh digunakan semula.', gym_activate:'Aktifkan · 23% lebih kuat selama 5 jam', gym_boost_active:'Peningkatan aktif · berbaki {duration}', gym_cooldown:'Sedia dalam {duration}', gym_started:'Peningkatan Gim diaktifkan!', mountainous_metropolis:'Metropolis Pergunungan' },
    battle: { metropolis_cup:'Piala Metropolis', metropolis_complete:'Selesai', metropolis_stage:'Peringkat {number} / {total}', metropolis_cup_complete:'Piala Metropolis selesai!', choose_two_cats_metropolis:'Pilih 2 ekor kucing untuk Piala Metropolis', metropolis_locked_message:'Selesaikan Piala Metropolis untuk membuka Metropolis Pergunungan!' }
  },
  hi: {
    shop: { gym:'जिम', gym_description:'आपकी सभी बिल्लियाँ 5 घंटे तक 23% अधिक नुकसान करेंगी। सक्रिय करने के बाद जिम 12 घंटे तक दोबारा इस्तेमाल नहीं किया जा सकता।', gym_activate:'सक्रिय करें · 5 घंटे तक 23% अधिक ताकत', gym_boost_active:'बूस्ट सक्रिय · {duration} शेष', gym_cooldown:'{duration} में तैयार', gym_started:'जिम बूस्ट सक्रिय हो गया!', mountainous_metropolis:'पर्वतीय महानगर' },
    battle: { metropolis_cup:'मेट्रोपोलिस कप', metropolis_complete:'पूरा', metropolis_stage:'चरण {number} / {total}', metropolis_cup_complete:'मेट्रोपोलिस कप पूरा हुआ!', choose_two_cats_metropolis:'मेट्रोपोलिस कप के लिए 2 बिल्लियाँ चुनें', metropolis_locked_message:'पर्वतीय महानगर अनलॉक करने के लिए मेट्रोपोलिस कप पूरा करें!' }
  }
};
Object.entries(newFeatureTranslations).forEach(([language, strings]) => {
  Object.assign(shopTranslations[language], strings.shop);
  Object.assign(battleText[language], strings.battle);
});
const rubyCupTranslations = {
  en: ['Ruby Cup', 'Ruby Cup complete!', 'Choose 2 cats for Ruby Cup', 'Stage {number} of 5', 'Stage {number} · 2 cats', '5 stages', 'Enter Ruby Cup'],
  es: ['Copa Rubí', '¡Copa Rubí completada!', 'Elige 2 gatos para la Copa Rubí', 'Fase {number} de 5', 'Fase {number} · 2 gatos', '5 fases', 'Entrar en la Copa Rubí'],
  pt: ['Copa Rubi', 'Copa Rubi concluída!', 'Escolha 2 gatos para a Copa Rubi', 'Fase {number} de 5', 'Fase {number} · 2 gatos', '5 fases', 'Entrar na Copa Rubi'],
  it: ['Coppa Rubino', 'Coppa Rubino completata!', 'Scegli 2 gatti per la Coppa Rubino', 'Fase {number} di 5', 'Fase {number} · 2 gatti', '5 fasi', 'Partecipa alla Coppa Rubino'],
  de: ['Rubin-Cup', 'Rubin-Cup abgeschlossen!', 'Wähle 2 Katzen für den Rubin-Cup', 'Stufe {number} von 5', 'Stufe {number} · 2 Katzen', '5 Stufen', 'Am Rubin-Cup teilnehmen'],
  nl: ['Robijnbeker', 'Robijnbeker voltooid!', 'Kies 2 katten voor de Robijnbeker', 'Fase {number} van 5', 'Fase {number} · 2 katten', '5 fasen', 'Deelnemen aan de Robijnbeker'],
  sv: ['Rubincupen', 'Rubincupen är klar!', 'Välj 2 katter till Rubincupen', 'Steg {number} av 5', 'Steg {number} · 2 katter', '5 steg', 'Gå med i Rubincupen'],
  ru: ['Рубиновый кубок', 'Рубиновый кубок завершён!', 'Выберите 2 котов для Рубинового кубка', 'Этап {number} из 5', 'Этап {number} · 2 кота', '5 этапов', 'Войти в Рубиновый кубок'],
  zh: ['红宝石杯', '红宝石杯已完成！', '选择2只猫参加红宝石杯', '第 {number} 阶段，共 5 阶段', '第 {number} 阶段 · 2只猫', '5个阶段', '参加红宝石杯'],
  ja: ['ルビーカップ', 'ルビーカップ制覇！', 'ルビーカップに参加するネコを2匹選択', 'ステージ {number} / 5', 'ステージ {number} · ネコ2匹', '全5ステージ', 'ルビーカップに参加'],
  ko: ['루비 컵', '루비 컵 완료!', '루비 컵에 참가할 고양이 2마리를 선택하세요', '스테이지 {number} / 5', '스테이지 {number} · 고양이 2마리', '총 5개 스테이지', '루비 컵 참가'],
  ms: ['Piala Ruby', 'Piala Ruby selesai!', 'Pilih 2 ekor kucing untuk Piala Ruby', 'Peringkat {number} daripada 5', 'Peringkat {number} · 2 ekor kucing', '5 peringkat', 'Sertai Piala Ruby'],
  hi: ['रूबी कप', 'रूबी कप पूरा हुआ!', 'रूबी कप के लिए 2 बिल्लियाँ चुनें', '5 में से चरण {number}', 'चरण {number} · 2 बिल्लियाँ', '5 चरण', 'रूबी कप में जाएँ']
};
Object.entries(rubyCupTranslations).forEach(([language, [name, complete, choose, stageNumber, stageProgress, fiveStages, enter]]) => {
  Object.assign(battleText[language], {
    ruby_cup: name,
    ruby_cup_complete: complete,
    choose_two_cats_ruby: choose,
    stage_number: stageNumber,
    stage_progress: stageProgress,
    five_stages: fiveStages,
    enter_ruby_cup: enter
  });
});
const battle = { phase: 'cups', cup: 'starters', selection: [], team: [], enemyTeam: [], activePlayer: 0, activeEnemy: 0, log: '', result: '', online: false, opponent: null, players: [], faintingSide: null, opponentTrophyDelta: null };
let onlineHeartbeatTimer;
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[char]); }
async function refreshOnlinePlayers() {
  try {
    const response = await fetch('/api/online');
    if (!response.ok) return;
    const data = await response.json();
    battle.players = data.players || [];
    if (Number.isInteger(data.trophies)) gameState.trophies = Math.max(0, data.trophies);
    renderBattle();
  } catch (error) { console.warn('Could not refresh online players.', error); }
}
async function publishOnlinePresence() {
  if (!gameState.onlineProfile) return;
  try {
    const featuredCat = gameState.cats.find(cat => cat.type === gameState.onlineProfile.catType) || gameState.cats[0];
    const defensiveCats = gameState.battleRoster.map(id => gameState.cats.find(cat => cat.id === id)).filter(Boolean);
    const roster = (defensiveCats.length === 2 ? defensiveCats : gameState.cats.slice(0, 2)).map(cat => ({ type: cat.type, level: cat.level }));
    const response = await fetch('/api/online', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...gameState.onlineProfile, catLevel: featuredCat?.level || 1, trophies: gameState.trophies, roster }) });
    if (response.ok && !onlineHeartbeatTimer) onlineHeartbeatTimer = window.setInterval(publishOnlinePresence, 30000);
  } catch (error) { console.warn('Could not update online presence.', error); }
}
async function openOnlineBattles() {
  battle.online = true; battle.opponent = null; battle.result = ''; battle.phase = 'online-list';
  showScreen('battle'); renderBattle(); await publishOnlinePresence(); await refreshOnlinePlayers();
}
function startOnlineBattle(opponent) {
  if (gameState.cats.length < 2) { flashSoundNote(t('need_two_cats')); return; }
  battle.online = true; battle.opponent = opponent; battle.result = ''; battle.selection = [];
  battle.selection = gameState.battleRoster.filter(id => gameState.cats.some(cat => cat.id === id)).slice(0, 2);
  battle.phase = 'online-select'; renderBattle();
}
async function beginOnlineBattle() {
  const chosen = battle.selection.map(id => gameState.cats.find(cat => cat.id === id)).filter(Boolean);
  if (chosen.length !== 2 || !battle.opponent) return;
  gameState.battleRoster = chosen.map(cat => cat.id);
  saveGame();
  battle.team = chosen.map(battleCat);
  const fallbackCat = { type: battle.opponent.catType || 'rocky', level: battle.opponent.level || 1 };
  const roster = Array.isArray(battle.opponent.roster) && battle.opponent.roster.length
    ? battle.opponent.roster.slice(0, 2) : [fallbackCat, fallbackCat];
  while (roster.length < 2) roster.push(roster[0] || fallbackCat);
  battle.enemyTeam = roster.slice(0, 2).map((cat, index) => battleCat({ id: `online-enemy-${index}`, type: cat.type, level: Math.max(1, cat.level || 1) }, index));
  battle.activePlayer = 0; battle.activeEnemy = 0; battle.round = 1;
  await publishOnlinePresence();
  startBattleTurns();
}
async function settleOnlineBattle(won) {
  if (!battle.online || !battle.opponent || battle.result) return;
  battle.result = won ? 'win' : 'loss';
  battle.opponentTrophyDelta = won ? -Math.min(Number.isInteger(battle.opponent.trophies) ? battle.opponent.trophies : 15, 15) : 20;
  gameState.trophies = Math.max(0, gameState.trophies + (won ? 20 : -15));
  if (won) awardXp(400);
  saveAndRender();
  try {
    const response = await fetch('/api/online', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ opponentId: battle.opponent.id, won }) });
    if (response.ok) {
      const data = await response.json();
      if (Number.isInteger(data.trophies)) gameState.trophies = data.trophies;
      if (Number.isInteger(data.opponentDelta)) battle.opponentTrophyDelta = data.opponentDelta;
      saveGame();
    }
  } catch (error) { console.warn('Could not sync battle trophies.', error); }
  renderGameState(); battle.phase = 'online-result'; renderBattle();
}
function battleAttacksFor(cat) { return catData(cat).attacks; }
function battleAttackName(attack) { return attack.nameKey ? t(attack.nameKey) : attack.name || t(attack.key); }
function catBattlePower(cat) {
  const catalog = catData(cat);
  const strongestAttack = Math.max(0, ...catalog.attacks.map(attack => attack.damage));
  return catalog.hp * cat.level + strongestAttack;
}
function battleCat(cat, index) {
  const type = CAT_CATALOG[cat.type] ? cat.type : 'rocky';
  const hp = Math.round(CAT_CATALOG[type].hp * cat.level * (gameState.cats.some(owned => owned.id === cat.id) && loveTotemBoostActive() ? 1.15 : 1));
  return { id: cat.id, type, level: cat.level, hp, maxHp: hp, alive: true, index };
}
function renderBattle() {
  if (!battleContent) return;
  if (battle.phase === 'menu') {
    battleContent.classList.remove('is-fighting');
    battleContent.innerHTML = `<div class="battle-menu"><button class="cup-card" data-action="open-cups"><img src="uploads/Battle_icon.png" alt=""><span><b>${t('cups')}</b></span><strong>›</strong></button><button class="cup-card online-cup-card" data-action="online-battles"><img src="uploads/Battle_icon.png" alt=""><span><b>${t('online_battles')}</b><small><img class="currency-icon" src="Trophy.png" alt=""> ${gameState.trophies}</small></span><strong>›</strong></button></div>`;
    return;
  }
  if (battle.phase === 'online-list') {
    battleContent.classList.remove('is-fighting');
    const players = battle.players;
    const cards = players.length ? players.map(player => `<button class="online-player" data-action="challenge-player" data-player-id="${escapeHtml(player.id)}"><img src="${CAT_CATALOG[player.catType]?.image || CAT_CATALOG.rocky.image}" alt=""><span><b>${escapeHtml(player.username)}</b><small><img class="currency-icon" src="Trophy.png" alt=""> ${player.trophies} · ${t('level_short')} ${player.level || 1}</small></span><strong>${t('battle')}</strong></button>`).join('') : `<div class="online-empty"><b>${t('no_player_profiles')}</b><small>${t('check_back_players')}</small></div>`;
    battleContent.innerHTML = `<div class="online-battles-head"><h1>${t('online_battles')}</h1><span><img class="currency-icon" src="Trophy.png" alt=""> ${gameState.trophies}</span></div><div class="online-player-list">${cards}</div><button class="battle-back" data-action="battle-menu">← ${t('battle')}</button>`;
    return;
  }
  if (battle.phase === 'online-result') {
    battleContent.classList.remove('is-fighting');
    const won = battle.result === 'win';
    const opponentDelta = battle.opponentTrophyDelta ?? (won ? -15 : 20);
    const opponentChange = t(opponentDelta < 0 ? 'opponent_lost' : 'opponent_gained', { username: escapeHtml(battle.opponent.username), count: Math.abs(opponentDelta) });
    battleContent.innerHTML = `<div class="battle-result"><img src="uploads/Battle_icon.png" alt=""><h1>${t(won ? 'victory' : 'defeat')}</h1><p>${won ? '+400 XP · ' : ''}${won ? '+20' : '−15'} <img class="currency-icon" src="Trophy.png" alt=""> · ${t('total_trophies', { count: gameState.trophies })}</p><p>${opponentChange}</p><button class="button button-pink" data-action="online-battles">${t('online_battles')}</button></div>`;
    return;
  }
  battleContent.classList.toggle('is-fighting', ['fight', 'choose', 'enemy-turn', 'attack-animation', 'faint-animation'].includes(battle.phase));
  if (battle.phase === 'cups') {
    const startersCup = gameState.startersCupCompleted
      ? `<div class="cup-card starters-cup-card is-locked"><img src="uploads/Rocky_Cat.png" alt=""><span><b>${t('starters_cup')}</b><small>${t('cup_complete')}</small></span></div>`
      : `<button class="cup-card starters-cup-card" data-action="open-cup"><img src="uploads/Rocky_Cat.png" alt=""><span><b>${t('starters_cup')}</b><small>${t('two_battles')}</small></span><strong>›</strong></button>`;
    const rubyCup = gameState.rubyCupStage >= 5
      ? `<div class="cup-card ruby-cup-card is-locked"><img src="Ruby.png" alt=""><span><b>${t('ruby_cup')}</b><small>${t('ruby_cup_complete')}</small></span></div>`
      : `<button class="cup-card ruby-cup-card" data-action="open-ruby-cup"><img src="Ruby.png" alt=""><span><b>${t('ruby_cup')}</b><small>${t('stage_progress', { number: gameState.rubyCupStage + 1 })}</small></span><strong>›</strong></button>`;
    const totemCup = gameState.totemCupStage >= 10
      ? `<div class='cup-card totem-cup-card is-locked'><img src='uploads/Love_Totem.png' alt=''><span><b>${t('totem_cup')}</b><small>${t('totem_cup_complete')}</small></span></div>`
      : `<button class='cup-card totem-cup-card' data-action='open-totem-cup'><img src='uploads/Love_Totem.png' alt=''><span><b>${t('totem_cup')}</b><small>${t('totem_stage', { number: gameState.totemCupStage + 1 })}</small></span><strong>›</strong></button>`;
    const metropolisCup = gameState.metropolisCupStage >= 10
      ? `<div class="cup-card metropolis-cup-card is-locked"><img src="uploads/Mountainous_Metropolis.png" alt=""><span><b>${t('metropolis_cup')}</b><small>${t('metropolis_complete')}</small></span></div>`
      : `<button class="cup-card metropolis-cup-card" data-action="open-metropolis-cup"><img src="uploads/Mountainous_Metropolis.png" alt=""><span><b>${t('metropolis_cup')}</b><small>${t('metropolis_stage', { number: gameState.metropolisCupStage + 1, total: 10 })}</small></span><strong>›</strong></button>`;
    battleContent.innerHTML = `<button class="battle-back" data-action="battle-menu">← ${t('battle')}</button><h1>${t('cups')}</h1><div class="cup-list">${startersCup}${rubyCup}${totemCup}${metropolisCup}</div>`;
  } else if (battle.phase === 'select' || battle.phase === 'online-select') {
    const owned = [...gameState.cats].sort((a, b) => catBattlePower(b) - catBattlePower(a));
    const onlineSelect = battle.phase === 'online-select';
    const requiredCats = onlineSelect || ['ruby','totem','metropolis'].includes(battle.cup) ? 2 : 1;
    const selectTitle = onlineSelect ? t('choose_two_cats', { opponent: escapeHtml(battle.opponent?.username || t('enemy_cat')) }) : battle.cup === 'metropolis' ? t('choose_two_cats_metropolis') : battle.cup === 'totem' ? t('choose_two_cats_totem') : battle.cup === 'ruby' ? t('choose_two_cats_ruby') : t('choose_battle_cat');
    const startAction = onlineSelect ? 'start-selected-online' : battle.cup === 'ruby' ? 'start-ruby-cup' : battle.cup === 'totem' ? 'start-totem-cup' : battle.cup === 'metropolis' ? 'start-metropolis-cup' : 'start-battle';
    battleContent.innerHTML = `<button class="battle-back" data-action="${onlineSelect ? 'online-battles' : 'battle-cups'}">← ${t('back_cups')}</button><h1>${selectTitle}</h1><div class="battle-cat-choices">${owned.map(cat => `<button class="battle-cat-choice ${battle.selection.includes(cat.id) ? 'selected' : ''}" data-action="select-battle-cat" data-cat-id="${cat.id}"><img src="${catData(cat).image}" alt=""><span>${catName(cat)} · ${t('level_short')} ${cat.level}</span>${battle.selection.includes(cat.id) ? '<b>✓</b>' : ''}</button>`).join('') || `<p>${t('no_battle_cats')}</p>`}</div><button class="button button-pink battle-start" data-action="${startAction}" ${battle.selection.length < requiredCats ? 'disabled' : ''}>${onlineSelect ? t('battle') : t('start_cup')}</button>`;
  } else if (battle.phase === 'fight' || battle.phase === 'choose' || battle.phase === 'enemy-turn' || battle.phase === 'attack-animation' || battle.phase === 'faint-animation') {
    const player = battle.team[battle.activePlayer];
    const enemy = battle.enemyTeam[battle.activeEnemy];
    const pct = cat => Math.max(0, cat.hp / cat.maxHp * 100);
    battleContent.innerHTML = `<div class="battle-fight-wrap">
      <div class="battle-round">${battle.online ? `${t('online_battles')} · <img class="currency-icon" src="Trophy.png" alt=""> ${gameState.trophies}` : battle.cup === 'totem' ? t('totem_stage', { number: battle.round || gameState.totemCupStage + 1 }) : battle.cup === 'metropolis' ? t('metropolis_stage', { number: battle.round || gameState.metropolisCupStage + 1, total: 10 }) : battle.cup === 'ruby' ? t('stage_number', { number: battle.round || gameState.rubyCupStage + 1 }) : t('battle_number',{number:battle.round || 1})}</div>
      <div class="battle-hp-row">
        <div class="battle-hp-card player-hp-card"><div class="fighter-label">${catName(player)} · ${t('level_short')} ${player.level}</div><div class="fighter-hp"><i style="width:${pct(player)}%"></i></div><small>${player.hp} / ${player.maxHp} ${t('hp')}</small></div>
        <div class="battle-hp-card enemy-hp-card"><div class="fighter-label">${battle.online ? escapeHtml(battle.opponent.username) : catName(enemy)} · ${t('level_short')} ${enemy.level}</div><div class="fighter-hp"><i style="width:${pct(enemy)}%"></i></div><small>${enemy.hp} / ${enemy.maxHp} ${t('hp')}</small></div>
      </div>
      <div class="battle-stage">
        <div class="stage-cat player-stage-cat ${battle.faintingSide === 'player' ? 'is-fainting' : ''}"><img src="${catData(player).image}" alt=""><span>${catName(player)}</span></div>
        <div class="battle-vs">VS</div>
        <div class="stage-cat enemy-stage-cat ${battle.faintingSide === 'enemy' ? 'is-fainting' : ''}"><img src="${catData(enemy).image}" alt=""><span>${battle.online ? escapeHtml(battle.opponent.username) : catName(enemy)}</span></div>
      </div>
      <div class="battle-message">${battle.phase === 'choose' ? t('choose_next_cat') : (battle.log || t('your_turn'))}</div>
      ${battle.phase === 'fight' ? `<div class="battle-attacks"><h2>${t('choose_attack')}</h2>${battleAttacksFor(player).map((attack,index) => `<button class="battle-attack" data-action="battle-attack" data-attack="${index}"><img class="attack-element" src="${attack.element}" alt=""><span>${battleAttackName(attack)}</span><small>${battleDamageRange(attack, player.level, true)} ${t('hp')}</small></button>`).join('')}</div>` : battle.phase === 'choose' ? `<div class="battle-cat-choices">${battle.team.map((cat,index) => cat.alive && index !== battle.activePlayer ? `<button class="battle-cat-choice" data-action="switch-battle-cat" data-index="${index}"><img src="${catData(cat).image}" alt=""><span>${catName(cat)} · ${t('level_short')} ${cat.level}</span></button>` : '').join('')}</div>` : ''}
    </div>`;
    battleContent.classList.add('is-fighting');
  } else {
    battleContent.classList.remove('is-fighting');
    const rubyCup = battle.cup === 'ruby';
    const totemCup = battle.cup === 'totem';
    const metropolisCup = battle.cup === 'metropolis';
    const won = ['result-win', 'result-cup', 'ruby-result-win', 'ruby-result-cup', 'metropolis-result-win', 'metropolis-result-cup', 'totem-result-win', 'totem-result-cup'].includes(battle.phase);
    const completed = battle.phase === 'result-cup' || battle.phase === 'ruby-result-cup' || (totemCup && battle.phase === 'totem-result-cup') || (metropolisCup && battle.phase === 'metropolis-result-cup');
    const reward = won ? (rubyCup ? RUBY_CUP_REWARDS[(battle.round || 1) - 1] : totemCup ? TOTEM_CUP_REWARDS[(battle.round || 1) - 1] : metropolisCup ? METROPOLIS_CUP_REWARDS[(battle.round || 1) - 1] : null) : null;
    const rewardLine = reward ? `<p>${formatNumber(reward.xp)} XP${reward.silver ? ` · ${formatNumber(reward.silver)} <img class=\"currency-icon\" src=\"Silver.png\" alt=''>` : ''}${reward.rubies ? ` · ${formatNumber(reward.rubies)} <img class="currency-icon" src="Ruby.png" alt="">` : ''}${reward.loveTotem ? ` · ${t('love_totem_reward')}` : ''}${reward.mountain ? ` · ${t('mountainous_metropolis')}` : ''}${reward.smokire ? ` · 1 <img class="currency-icon" src="uploads/Smokire.png" alt=""> ${t('smokire_name')}` : ''}</p>` : '';
    const resultTitle = completed ? (rubyCup ? t('ruby_cup_complete') : totemCup ? t('totem_cup_complete') : metropolisCup ? t('metropolis_cup_complete') : t('cup_complete')) : won ? t('battle_win') : t('battle_loss');
    const resultAction = completed ? 'battle-cups' : won ? (rubyCup ? 'next-ruby-stage' : totemCup ? 'next-totem-stage' : metropolisCup ? 'next-metropolis-stage' : 'next-battle') : 'retry-cup';
    const resultButton = completed ? t('finish') : won ? (rubyCup || totemCup || metropolisCup ? t('next_stage') : t('continue_battle')) : t('retry-cup');
    battleContent.innerHTML = `<div class="battle-result"><img src="${rubyCup ? 'Ruby.png' : totemCup ? 'uploads/Love_Totem.png' : metropolisCup ? 'uploads/Mountainous_Metropolis.png' : 'uploads/Battle_icon.png'}" alt=""><h1>${resultTitle}</h1>${rewardLine}${!rubyCup && !totemCup && !metropolisCup && (completed || won) ? `<p>${completed ? t('cup_reward') : t('first_win_reward')}</p><p>+20 <img class="currency-icon" src="Trophy.png" alt=""> · ${t('total_trophies', { count: gameState.trophies })}</p>` : ''}<button class="button button-pink" data-action="${resultAction}">${resultButton}</button></div>`;
  }
}
function beginBattle(number) {
  battle.cup = 'starters';
  if (gameState.startersCupCompleted) return;
  const firstLevel = battle.selection.map(id => gameState.cats.find(cat => cat.id === id)).filter(Boolean);
  if (!firstLevel.length) return;
  battle.team = firstLevel.map(battleCat);
  const firstEnemyLevel = Math.max(1, firstLevel[0].level - 1 - Math.floor(Math.random() * 2));
  const enemyLevels = firstLevel.length > 1
    ? [firstEnemyLevel, Math.max(firstEnemyLevel + 1, firstLevel[1].level + 1 + Math.floor(Math.random() * 2))]
    : [firstEnemyLevel];
  battle.enemyTeam = enemyLevels.map((level, index) => battleCat({ id: 'enemy-' + index, level }, index));
  battle.activePlayer = 0; battle.activeEnemy = 0; battle.round = number;
  showScreen('battle'); startBattleTurns();
}
function beginRubyBattle(stage = gameState.rubyCupStage + 1) {
  if (gameState.rubyCupStage >= 5 || stage !== gameState.rubyCupStage + 1 || stage < 1 || stage > 5) return;
  const chosen = battle.selection.map(id => gameState.cats.find(cat => cat.id === id)).filter(Boolean);
  if (chosen.length !== 2) return;
  battle.cup = 'ruby';
  battle.team = chosen.map(battleCat);
  const enemyLevels = [stage * 2, stage * 2 + 1];
  battle.enemyTeam = enemyLevels.map((level, index) => battleCat({
    id: `ruby-enemy-${stage}-${index}`,
    type: stage >= 4 && index === 1 ? 'smokire' : 'rocky',
    level
  }, index));
  battle.activePlayer = 0; battle.activeEnemy = 0; battle.round = stage;
  showScreen('battle'); startBattleTurns();
}
function beginTotemBattle(stage = gameState.totemCupStage + 1) {
  if (gameState.totemCupStage >= 10 || stage !== gameState.totemCupStage + 1 || stage < 1 || stage > 10) return;
  const chosen = battle.selection.map(id => gameState.cats.find(cat => cat.id === id)).filter(Boolean);
  if (chosen.length !== 2) return;
  battle.cup = 'totem';
  battle.team = chosen.map(battleCat);
  const species = Object.keys(CAT_CATALOG);
  const enemyTypes = [species[(stage - 1) % species.length], species[(stage + 1) % species.length]];
  const teamLevel = Math.round(chosen.reduce((sum, cat) => sum + cat.level, 0) / chosen.length);
  const level = Math.max(1, teamLevel + Math.floor((stage - 1) / 3) - 1);
  battle.enemyTeam = enemyTypes.map((type, index) => battleCat({ id: `totem-enemy-${stage}-${index}`, type, level: level + index }, index));
  battle.activePlayer = 0; battle.activeEnemy = 0; battle.round = stage;
  showScreen('battle'); startBattleTurns();
}
function beginMetropolisBattle(stage = gameState.metropolisCupStage + 1) {
  if (gameState.metropolisCupStage >= 10 || stage !== gameState.metropolisCupStage + 1 || stage < 1 || stage > 10) return;
  const chosen = battle.selection.map(id => gameState.cats.find(cat => cat.id === id)).filter(Boolean);
  if (chosen.length !== 2) return;
  battle.cup = 'metropolis';
  battle.team = chosen.map(battleCat);
  const species = Object.keys(CAT_CATALOG);
  const enemyTypes = [species[((stage - 1) * 2) % species.length], species[((stage - 1) * 2 + 1) % species.length]];
  const teamLevel = Math.round(chosen.reduce((sum, cat) => sum + cat.level, 0) / chosen.length);
  const level = Math.max(1, teamLevel + Math.floor((stage - 1) / 4) - 1);
  battle.enemyTeam = enemyTypes.map((type, index) => battleCat({ id: `metropolis-enemy-${stage}-${index}`, type, level: level + index }, index));
  battle.activePlayer = 0; battle.activeEnemy = 0; battle.round = stage;
  showScreen('battle'); startBattleTurns();
}
function addRubyCupSmokire() {
  addCube('smokire', 'burning');
}
function startBattleTurns() {
  battle.phase = Math.random() < 0.5 ? 'fight' : 'enemy-turn';
  battle.log = battle.phase === 'fight' ? t('your_turn') : t('enemy_turn');
  renderBattle();
  if (battle.phase === 'enemy-turn') window.setTimeout(() => { if (battle.phase === 'enemy-turn') enemyTurn(); }, 250);
}
function battleDamageMultiplier(level = 1) {
  const normalizedLevel = Math.max(1, Number.isFinite(level) ? level : 1);
  return 1 + 0.2 * (normalizedLevel - 1) / (normalizedLevel + 9);
}
function battleDamageRange(attack, level = 1, boosted = false) {
  const multiplier = battleDamageMultiplier(level);
  const boost = boosted && gymBoostActive() ? 1.23 : 1;
  const low = Math.max(0, Math.floor((Math.floor(attack.damage / 2) - 15) * multiplier * boost));
  const high = Math.floor((Math.floor(attack.damage / 2) + 15) * multiplier * boost);
  return `${low}–${high}`;
}
function battleDamage(attack, level = 1, boosted = false) {
  const baseDamage = Math.floor(attack.damage / 2) + Math.floor(Math.random() * 31) - 15;
  return Math.max(0, Math.floor(baseDamage * battleDamageMultiplier(level) * (boosted && gymBoostActive() ? 1.23 : 1)));
}
function wait(ms) { return new Promise(resolve => window.setTimeout(resolve, ms)); }
async function animateBattleAttack(side, attack) {
  const stage = battleContent.querySelector('.battle-stage');
  if (!stage) return;
  const target = stage.querySelector(side === 'player' ? '.enemy-stage-cat' : '.player-stage-cat');
  const projectile = document.createElement('img');
  projectile.className = 'attack-projectile from-' + side;
  projectile.src = attack.element;
  projectile.alt = '';
  stage.append(projectile);
  await wait(330);
  projectile.remove();
  target?.classList.add('is-hit');
  await wait(420);
  target?.classList.remove('is-hit');
}
async function animateBattleFaint(side) {
  battle.phase = 'faint-animation';
  battle.faintingSide = null;
  renderBattle();
  await wait(270);
  battle.faintingSide = side;
  renderBattle();
  await wait(650);
  battle.faintingSide = null;
}
async function enemyTurn() {
  const player = battle.team[battle.activePlayer];
  if (!player || !player.alive) return;
  const opponent = battle.enemyTeam[battle.activeEnemy];
  const attacks = battleAttacksFor(opponent);
  const attack = attacks[Math.floor(Math.random() * attacks.length)];
  battle.phase = 'enemy-turn';
  battle.log = `${catName(opponent)} used ${battleAttackName(attack)}…`;
  renderBattle();
  await animateBattleAttack('enemy', attack);
  const damage = battleDamage(attack, opponent.level);
  player.hp = Math.max(0, player.hp - damage);
  battle.log = `${catName(opponent)} used ${battleAttackName(attack)} · ${damage} damage`;
  if (!player.hp) {
    player.alive = false;
    await animateBattleFaint('player');
    const nextPlayer = battle.team.findIndex(cat => cat.alive);
    if (nextPlayer >= 0) {
      battle.activePlayer = nextPlayer;
      battle.phase = 'enemy-turn';
      battle.log = t('fainted',{cat:t('your_cat')});
      renderBattle();
      window.setTimeout(() => { if (battle.phase === 'enemy-turn') enemyTurn(); }, 300);
      return;
    }
    if (battle.online) { await settleOnlineBattle(false); return; }
    battle.phase = 'result-loss';
  } else battle.phase = 'fight';
  renderBattle();
}
async function playerAttack(index) {
  if (battle.phase !== 'fight') return;
  const attack = battleAttacksFor(battle.team[battle.activePlayer])[index];
  const enemy = battle.enemyTeam[battle.activeEnemy];
  if (!attack || !enemy) return;
  battle.phase = 'attack-animation';
  battle.log = `${catName(battle.team[battle.activePlayer])} used ${battleAttackName(attack)}…`;
  renderBattle();
  await animateBattleAttack('player', attack);
  const damage = battleDamage(attack, battle.team[battle.activePlayer].level, true);
  enemy.hp = Math.max(0, enemy.hp - damage);
  battle.log = `${catName(battle.team[battle.activePlayer])} used ${battleAttackName(attack)} · ${damage} damage`;
  if (!enemy.hp) {
    enemy.alive = false;
    await animateBattleFaint('enemy');
    if (battle.activeEnemy < battle.enemyTeam.length - 1) {
      battle.activeEnemy += 1;
      battle.log = t('fainted',{cat:t('enemy_cat')});
      battle.phase = 'enemy-turn';
      renderBattle();
      window.setTimeout(() => { if (battle.phase === 'enemy-turn') enemyTurn(); }, 300);
      return;
    }
    if (battle.online) { await settleOnlineBattle(true); return; }
    if (battle.cup === 'ruby') {
      const stage = battle.round;
      const reward = RUBY_CUP_REWARDS[stage - 1];
      if (!reward || gameState.rubyCupStage >= stage) return;
      gameState.rubyCupStage = stage;
      awardXp(reward.xp);
      gameState.rubies += reward.rubies;
      if (reward.smokire) addRubyCupSmokire();
      battle.phase = stage === 5 ? 'ruby-result-cup' : 'ruby-result-win';
      saveAndRender(); renderBattle(); return;
    }
    if (battle.cup === 'totem') {
      const stage = battle.round;
      const reward = TOTEM_CUP_REWARDS[stage - 1];
      if (!reward || gameState.totemCupStage >= stage) return;
      gameState.totemCupStage = stage;
      awardXp(reward.xp);
      gameState.silver += reward.silver || 0;
      if (reward.loveTotem) gameState.loveTotemUnlocked = true;
      battle.phase = stage === 10 ? 'totem-result-cup' : 'totem-result-win';
      saveAndRender(); renderBattle(); return;
    }
    if (battle.cup === 'metropolis') {
      const stage = battle.round;
      const reward = METROPOLIS_CUP_REWARDS[stage - 1];
      if (!reward || gameState.metropolisCupStage >= stage) return;
      gameState.metropolisCupStage = stage;
      awardXp(reward.xp);
      gameState.rubies += reward.rubies;
      if (reward.mountain) gameState.mountainousMetropolisUnlocked = true;
      battle.phase = stage === 10 ? 'metropolis-result-cup' : 'metropolis-result-win';
      saveAndRender(); renderBattle(); return;
    }
    gameState.trophies += 20;
    if (battle.round === 1) {
      awardXp(100);
      saveAndRender();
      battle.phase = 'result-win';
    } else {
      battle.phase = 'result-cup';
      gameState.startersCupCompleted = true;
      awardXp(1000); gameState.rubies += 10; saveAndRender();
    }
    renderBattle(); return;
  }
  battle.phase = 'enemy-turn'; renderBattle();
  window.setTimeout(() => { if (battle.phase === 'enemy-turn') enemyTurn(); }, 250);
}

mapGrid.addEventListener('click', event => {
  const buildingButton = event.target.closest('.map-building');
  if (buildingButton && !movingCat && !movingBuildingId) {
    if (buildingButton.dataset.buildingId === 'farm') {
      openFarm(buildingButton.dataset.buildingUid);
      return;
    }
    if (buildingButton.dataset.buildingId === 'cube_hatcher') {
      openHatcher();
      return;
    }
    if (buildingButton.dataset.buildingId === 'feline_stocks') {
      openFelineStocks(buildingButton.dataset.buildingUid);
      return;
    }
    if (buildingButton.dataset.buildingId === 'cube_mixer') {
      openCubeMixer(activeMountainId);
      return;
    }
    if (buildingButton.dataset.buildingId === 'gym') {
      openBuildingMessage('gym', buildingButton.dataset.buildingUid);
      return;
    }
    movingBuildingId = buildingButton.dataset.buildingUid;
    mapGrid.classList.add('is-moving');
    flashSoundNote(t('choose_tile'));
    return;
  }
  const cell = event.target.closest('.grid-cell');
  if (cell && movingBuildingId) {
    const building = gameState.buildings.find(item => item.uid === movingBuildingId && item.mountain === activeMountainId);
    if (!building) return;
    const row = Number(cell.dataset.row);
    const column = Number(cell.dataset.column);
    if (occupied(row, column, building.uid)) {
      flashSoundNote(t('tile_occupied'));
      return;
    }
    placeBuilding(building, row, column);
    movingBuildingId = null;
    saveAndRender();
    buildMapGrid();
    playTone(520, .08, 'triangle', .035);
    return;
  }
  const catButton = event.target.closest('.map-cat');
  if (catButton) {
    openCatPanel(catButton.dataset.catId);
    return;
  }
  if (!cell || !movingCat) return;
  const cat = getSelectedCat();
  if (!cat) return;
  const row = Number(cell.dataset.row);
  const column = Number(cell.dataset.column);
  if (occupied(row, column, cat.id)) {
    flashSoundNote(t('tile_occupied'));
    return;
  }
  placeCat(cat, row, column);
  movingCat = false;
  mapGrid.classList.remove('is-moving');
  saveAndRender();
  buildMapGrid();
  playTone(520, .08, 'triangle', .035);
});
mapGrid.addEventListener('keydown', event => {
  if (!movingCat || !event.target.closest('.map-cat')) return;
  const delta = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }[event.key];
  const cat = getSelectedCat();
  if (!delta || !cat) return;
  event.preventDefault();
  if (placeCat(cat, cat.row + delta[0], cat.column + delta[1])) {
    const catId = cat.id;
    saveAndRender();
    buildMapGrid();
    mapGrid.querySelector('[data-cat-id="' + catId + '"]')?.focus();
  }
});

function syncSettings() {
  musicToggle.checked = preferences.music;
  soundToggle.checked = preferences.sounds;
}
document.addEventListener('click', async event => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const action = button.dataset.action;
  if (action !== 'settings' && action !== 'close-modal') playTone(action === 'mountains' ? 660 : 520, .11, 'triangle');
  if (action === 'continue-level-up') {
    levelUpScreen.hidden = true;
    showNextLevelUp();
  } else if (action === 'play') {
    if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
    showScreen('regions');
  } else if (action === 'settings') {
    syncSettings();
    settingsModal.hidden = false;
    warningModal.hidden = true;
  } else if (action === 'close-offline-report') {
    offlineReportModal.hidden = true;
    showNextLevelUp();
  } else if (action === 'close-farm') {
    closeFarm();
  } else if (action === 'close-hatcher') {
    closeHatcher();
  } else if (action === 'close-building-message') {
    closeBuildingMessage();
  } else if (action === 'close-feline-stocks') {
    closeFelineStocks();
  } else if (action === 'close-cube-mixer') {
    closeCubeMixer();
  } else if (action === 'mixer-select-cat') {
    const parentIndex = Number(button.dataset.parentIndex);
    const otherIndex = parentIndex === 0 ? 1 : 0;
    const catId = button.dataset.catId;
    if ((parentIndex !== 0 && parentIndex !== 1) || mixerSelection[otherIndex] === catId) return;
    mixerSelection[parentIndex] = mixerSelection[parentIndex] === catId ? null : catId;
    renderCubeMixer();
  } else if (action === 'breed-cats') {
    breedSelectedCats();
  } else if (action === 'speed-up-breeding') {
    speedUpBreeding(button.dataset.breedId);
  } else if (action === 'move-feline-stocks') {
    const uid = felineStocksModal.dataset.buildingUid;
    closeFelineStocks();
    const building = gameState.buildings.find(item => item.uid === uid && item.mountain === activeMountainId);
    if (building) { movingBuildingId = building.uid; mapGrid.classList.add('is-moving'); flashSoundNote(t('choose_tile')); }
  } else if (action === 'stock-add') {
    selectedStockSlot = Number(button.dataset.stockSlot);
    renderFelineStocks();
  } else if (action === 'stock-unlock') {
    const building = gameState.buildings.find(item => item.uid === felineStocksModal.dataset.buildingUid && item.id === 'feline_stocks');
    if (!building || building.unlockedSlots >= 15) { flashSoundNote(t('stocks_full')); return; }
    if (gameState.rubies < 5) { flashSoundNote(t('stocks_not_enough')); return; }
    gameState.rubies -= 5;
    building.unlockedSlots++;
    saveAndRender();
    renderFelineStocks();
  } else if (action === 'stock-select-cat') {
    const building = gameState.buildings.find(item => item.uid === felineStocksModal.dataset.buildingUid && item.id === 'feline_stocks');
    const cat = gameState.cats.find(item => item.id === button.dataset.catId && !item.storedIn && (item.mountain || 'arid') === building?.mountain);
    const slot = selectedStockSlot;
    if (!building || !cat || !Number.isInteger(slot) || slot >= building.unlockedSlots) return;
    building.stockedCats[slot] = cat.id;
    cat.storedIn = building.uid;
    cat.storedSlot = slot;
    cat.lastProducedAt = Date.now();
    selectedStockSlot = null;
    saveAndRender();
    buildMapGrid();
    renderFelineStocks();
  } else if (action === 'stock-take-out') {
    const building = gameState.buildings.find(item => item.uid === felineStocksModal.dataset.buildingUid && item.id === 'feline_stocks');
    const slot = Number(button.dataset.stockSlot);
    const catId = building?.stockedCats?.[slot];
    const cat = gameState.cats.find(item => item.id === catId && item.storedIn === building?.uid);
    if (!building || !cat) return;
    const tile = findAvailableTile(4, 4);
    if (!tile) { flashSoundNote(t('no_space')); return; }
    cat.storedIn = null;
    delete cat.storedSlot;
    cat.lastProducedAt = Date.now();
    [cat.row, cat.column] = tile;
    building.stockedCats[slot] = null;
    saveAndRender();
    buildMapGrid();
    renderFelineStocks();
  } else if (action === 'move-message-building') {
    const uid = button.dataset.buildingUid;
    const building = gameState.buildings.find(item => item.uid === uid && item.mountain === activeMountainId);
    closeBuildingMessage();
    if (building) { movingBuildingId = building.uid; mapGrid.classList.add('is-moving'); flashSoundNote(t('choose_tile')); }
  } else if (action === 'open-hatcher-queue') {
    closeBuildingMessage();
    openHatcher();
  } else if (action === 'activate-gym') {
    const gym = gameState.buildings.find(item => item.id === 'gym');
    const now = Date.now();
    if (!gym || gymBoostActive(now) || (gym.readyAt || 0) > now) return;
    gym.activeUntil = now + 5 * 60 * 60 * 1000;
    gym.readyAt = now + 12 * 60 * 60 * 1000;
    saveAndRender();
    buildMapGrid();
    renderGymMessage();
    flashSoundNote(t('gym_started'));
  } else if (action === 'activate-love-totem') {
    const totem = gameState.buildings.find(item => item.id === 'love_totem');
    const now = Date.now();
    if (!totem || gameState.rubies < 1 || loveTotemBoostActive(now) || (totem.readyAt || 0) > now) return;
    gameState.rubies -= 1;
    totem.activeUntil = now + 6 * 60 * 60 * 1000;
    totem.readyAt = now + 17 * 60 * 60 * 1000;
    saveAndRender();
    buildMapGrid();
    renderLoveTotemMessage();
    flashSoundNote(t('love_totem_started'));
  } else if (action === 'move-hatcher') {
    const hatcher = gameState.buildings.find(item => item.id === 'cube_hatcher' && item.mountain === activeMountainId);
    closeHatcher();
    if (hatcher) { movingBuildingId = hatcher.uid; mapGrid.classList.add('is-moving'); flashSoundNote(t('choose_tile')); }
  } else if (action === 'open-catalogue') {
    openCatalogue();
  } else if (action === 'close-catalogue') {
    closeCatalogue();
    closeCatPanel();
  } else if (action === 'zoom-in') {
    setMountainZoom(.2);
  } else if (action === 'zoom-out') {
    setMountainZoom(-.2);
  } else if (action === 'catalogue-cat') {
    openCatalogueCat(button.dataset.catType);
  } else if (action === 'hatch-cube') {
    const egg = gameState.eggs.find(item => item.id === button.dataset.cubeId);
    if (!egg) return;
    if (hatchTransitionBusy) return;
    pendingHatchEggId = egg.id;
    document.querySelector('#hatch-mountain-title').textContent = t('choose_hatch_mountain');
    document.querySelector('[data-action="close-hatch-mountain"]').setAttribute('aria-label', t('hatch_cancel'));
    document.querySelector('[data-mountain="arid"].hatch-mountain-choice span').textContent = t('hatch_mountain_arid');
    document.querySelector('[data-mountain="burning"].hatch-mountain-choice span').textContent = t('hatch_mountain_burning');
    const metropolisHatchChoice = document.querySelector('[data-mountain="metropolis"].hatch-mountain-choice');
    metropolisHatchChoice.hidden = !gameState.mountainousMetropolisUnlocked;
    metropolisHatchChoice.querySelector('span').textContent = t('mountainous_metropolis');
    document.querySelector('[data-mountain="greenfields"].hatch-mountain-choice span').textContent = t('greenfields_mountain');
    hatchMountainModal.querySelectorAll('.hatch-mountain-choice').forEach(choice => {
      const mountainId = choice.dataset.mountain;
      choice.hidden = !isCatCompatibleWithMountain(egg.type, mountainId) || (mountainId === 'metropolis' && !gameState.mountainousMetropolisUnlocked);
    });
    hatchMountainModal.hidden = false;
  } else if (action === 'close-hatch-mountain') {
    pendingHatchEggId = null;
    hatchMountainModal.hidden = true;
  } else if (action === 'hatch-to-mountain') {
    const egg = gameState.eggs.find(item => item.id === pendingHatchEggId);
    const destination = button.dataset.mountain;
    if (!egg || !['arid','burning','metropolis','greenfields'].includes(destination) || !isCatCompatibleWithMountain(egg.type, destination) || (destination === 'metropolis' && !gameState.mountainousMetropolisUnlocked)) return;
    if (hatchTransitionBusy) return;
    const ready = Date.now() - egg.startedAt >= CUBE_HATCH_TIMES[egg.type];
    const cost = ready ? 0 : rubyHatchCost(egg);
    if (gameState.rubies < cost) { flashSoundNote(t('hatch_no_rubies')); return; }
    gameState.rubies -= cost;
    const cat = hatchCube(egg, destination);
    if (!cat) {
      gameState.rubies += cost;
      flashSoundNote(t('no_space'));
      return;
    }
    pendingHatchEggId = null;
    hatchMountainModal.hidden = true;
    hatchTransitionBusy = true;
    saveAndRender(); buildMapGrid();
    await animateHatchedCat(cat);
    hatchTransitionBusy = false;
  } else if (action === 'farm-move') {
    const farm = gameState.buildings.find(item => item.uid === selectedFarmUid);
    closeFarm();
    if (farm) { movingBuildingId = farm.uid; mapGrid.classList.add('is-moving'); flashSoundNote(t('choose_tile')); }
  } else if (action === 'start-farm-production') {
    const farm = gameState.buildings.find(item => item.uid === selectedFarmUid);
    const cost = Number(button.dataset.cost);
    const rate = Number(button.dataset.rate);
    if (!farm || !FARM_OPTIONS.some(option => option.cost === cost && option.rate === rate) || gameState.silver < cost) return;
    gameState.silver -= cost;
    farm.production = { rate, startsAt: Date.now(), lastAt: Date.now(), endsAt: Date.now() + 24 * 60 * 60 * 1000 };
    saveAndRender();
    renderFarmModal();
  } else if (action === 'home') {
    showScreen('home');
  } else if (action === 'regions') {
    showScreen('regions');
  } else if (action === 'mountains') {
    renderMountainChoices();
    showScreen('mountains');
  } else if (action === 'battle') {
    battle.online = false; battle.opponent = null; battle.result = ''; battle.phase = 'menu'; showScreen('battle'); renderBattle();
  } else if (action === 'battle-menu') {
    battle.online = false; battle.opponent = null; battle.result = ''; battle.phase = 'menu'; renderBattle();
  } else if (action === 'online-battles') {
    if (gameState.playerLevel >= 3) gameState.onlineProfile ? openOnlineBattles() : openOnlineProfile();
  } else if (action === 'challenge-player') {
    const opponent = battle.players.find(player => player.id === button.dataset.playerId);
    if (opponent) startOnlineBattle(opponent);
  } else if (action === 'open-cup') {
    if (gameState.startersCupCompleted) return;
    battle.cup = 'starters';
    battle.phase = 'select'; battle.selection = []; renderBattle();
  } else if (action === 'open-ruby-cup') {
    if (gameState.rubyCupStage >= 5) return;
    battle.cup = 'ruby'; battle.phase = 'select'; battle.selection = []; renderBattle();
  } else if (action === 'open-totem-cup') {
    if (gameState.totemCupStage >= 10) return;
    battle.cup = 'totem'; battle.phase = 'select'; battle.selection = []; renderBattle();
  } else if (action === 'open-metropolis-cup') {
    if (gameState.metropolisCupStage >= 10) return;
    battle.cup = 'metropolis'; battle.phase = 'select'; battle.selection = []; renderBattle();
  } else if (action === 'open-cups') {
    battle.online = false; battle.phase = 'cups'; renderBattle();
  } else if (action === 'battle-cups') {
    battle.online = false; battle.result = ''; battle.phase = 'cups'; renderBattle();
  } else if (action === 'select-battle-cat') {
    const id = button.dataset.catId;
    if (battle.selection.includes(id)) battle.selection = battle.selection.filter(item => item !== id);
    else if (battle.selection.length < 2) battle.selection.push(id);
    renderBattle();
  } else if (action === 'start-battle') {
    if (battle.selection.length) beginBattle(1);
  } else if (action === 'start-ruby-cup') {
    beginRubyBattle();
  } else if (action === 'start-totem-cup') {
    beginTotemBattle();
  } else if (action === 'start-metropolis-cup') {
    beginMetropolisBattle();
  } else if (action === 'start-selected-online') {
    beginOnlineBattle();
  } else if (action === 'battle-attack') {
    playerAttack(Number(button.dataset.attack));
  } else if (action === 'switch-battle-cat') {
    const index = Number(button.dataset.index);
    if (battle.team[index]?.alive) { battle.activePlayer = index; battle.phase = 'fight'; battle.log = t('your_turn'); renderBattle(); }
  } else if (action === 'next-battle') {
    beginBattle(2);
  } else if (action === 'next-ruby-stage') {
    beginRubyBattle(gameState.rubyCupStage + 1);
  } else if (action === 'next-totem-stage') {
    beginTotemBattle(gameState.totemCupStage + 1);
  } else if (action === 'next-metropolis-stage') {
    beginMetropolisBattle(gameState.metropolisCupStage + 1);
  } else if (action === 'retry-cup') {
    battle.phase = 'select'; battle.selection = []; renderBattle();
  } else if (action === 'open-mountain' || action === 'arid-mountain') {
    activeMountainId = button.dataset.mountainId || 'arid';
    const mountain = MOUNTAIN_CATALOG.find(item => item.id === activeMountainId);
    document.querySelector('.mountain-art').src = mountain.image;
    document.querySelector('.mountain-screen').setAttribute('aria-label', t(mountain.id === 'metropolis' ? 'mountainous_metropolis' : mountain.id === 'burning' ? 'burning_mountain' : mountain.id === 'greenfields' ? 'greenfields_mountain' : 'arid_mountain') + ' · ' + t('mountain_ground'));
    renderGameState();
    showScreen('mountain');
    playTone(784, .22, 'sine', .06);
  } else if (action === 'locked-metropolis') {
    flashSoundNote(t('metropolis_locked_message'));
  } else if (action === 'back-mountains') {
    showScreen('mountains');
  } else if (action === 'coming') {
    settingsModal.hidden = true;
    warningModal.hidden = false;
  } else if (action === 'shop') {
    openShop();
  } else if (action === 'shop-tab') {
    shopTab = button.dataset.shopTab === 'buildings' ? 'buildings' : 'cats';
    renderShop();
  } else if (action === 'select-building') {
    selectedBuildingId = button.dataset.buildingId;
    shopTab = 'buildings';
    renderShop();
  } else if (action === 'buy-building') {
    const building = BUILDING_CATALOG.find(item => item.id === selectedBuildingId);
    if (!building || building.installed || buildingIsOwned(building)) return;
    if (building.id === 'love_totem' && !gameState.loveTotemUnlocked) return;
    if (gameState.silver < building.price) {
      flashSoundNote(t('not_enough_silver'));
      return;
    }
    const tile = findAvailableTile(2, 4);
    if (!tile) {
      flashSoundNote(t('no_space'));
      return;
    }
    gameState.silver -= building.price;
    gameState.buildings.push({ id: building.id, uid: `${building.id}-${activeMountainId}-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, mountain: activeMountainId, row: tile[0], column: tile[1] });
    if (building.id === 'love_totem') gameState.loveTotemUnlocked = false;
    saveAndRender();
    buildMapGrid();
  } else if (action === 'buy-cat') {
    const type = shopCatType();
    const offered = CAT_CATALOG[type];
    if (gameState.silver < offered.price) {
      flashSoundNote(t('not_enough_silver'));
    } else {
      gameState.silver -= offered.price;
      addCube(type);
      saveAndRender();
      buildMapGrid();
      closeShop();
      flashSoundNote(t('cube_sent_to_hatcher'));
    }
  } else if (action === 'buy-metropolis-floralis') {
    if (activeMountainId !== 'metropolis') return;
    const offered = CAT_CATALOG.floralis;
    if (gameState.silver < offered.price) { flashSoundNote(t('not_enough_silver')); return; }
    gameState.silver -= offered.price;
    addCube('floralis', 'metropolis');
    saveAndRender(); buildMapGrid(); closeShop();
    flashSoundNote(t('cube_sent_to_hatcher'));
  } else if (action === 'buy-metropolis-rocky') {
    if (activeMountainId !== 'metropolis') return;
    const offered = CAT_CATALOG.rocky;
    if (gameState.silver < offered.price) {
      flashSoundNote(t('not_enough_silver'));
    } else {
      gameState.silver -= offered.price;
      addCube('rocky', 'metropolis');
      saveAndRender();
      buildMapGrid();
      closeShop();
      flashSoundNote(t('cube_sent_to_hatcher'));
    }
  } else if (action === 'buy-volcanic-cat') {
    if (!isCatCompatibleWithMountain('volcanic_lava', activeMountainId)) return;
    const data = CAT_CATALOG.volcanic_lava;
    if (gameState.rubies < data.rubyPrice) { flashSoundNote(t('mixer_not_enough_rubies')); return; }
    const cat = createOwnedCat('volcanic_lava', activeMountainId);
    if (!cat) { flashSoundNote(t('no_space')); return; }
    gameState.rubies -= data.rubyPrice;
    saveAndRender();
    buildMapGrid();
    closeShop();
    await animateAddedCat(cat);
    openCatPanel(cat.id);
  } else if (action === 'buy-florestalis-cat') {
    if (!isCatCompatibleWithMountain('florestalis', activeMountainId)) return;
    const data = CAT_CATALOG.florestalis;
    if (gameState.rubies < data.rubyPrice) { flashSoundNote(t('mixer_not_enough_rubies')); return; }
    const cat = createOwnedCat('florestalis', activeMountainId);
    if (!cat) { flashSoundNote(t('no_space')); return; }
    gameState.rubies -= data.rubyPrice;
    saveAndRender();
    buildMapGrid();
    closeShop();
    await animateAddedCat(cat);
    openCatPanel(cat.id);
  } else if (action === 'close-shop') {
    closeShop();
  } else if (action === 'move-cat') {
    const cat = getSelectedCat();
    if (!cat) return;
    closeCatalogue();
    movingCat = true;
    movingBuildingId = null;
    closeCatPanel();
    selectedCatId = cat.id;
    buildMapGrid();
    flashSoundNote(t('choose_tile'));
  } else if (action === 'feed-cat') {
    const cat = getSelectedCat();
    if (!cat) return;
    const cost = 5 * 2 ** (cat.level - 1);
    if (gameState.food < cost) {
      flashSoundNote(t('not_enough_food'));
    } else {
      gameState.food -= cost;
      cat.level += 1;
      awardXp(100);
      saveAndRender();
      buildMapGrid();
      playTone(784, .18, 'sine', .06);
      flashSoundNote(t('level_reached', { level: cat.level }));
    }
  } else if (action === 'sell-cat') {
    const cat = getSelectedCat();
    if (!cat) return;
    awardXp(500 * (cat.rarityWeight || 1));
    const refund = catData(cat).sell;
    gameState.silver += refund;
    gameState.cats = gameState.cats.filter(item => item.id !== cat.id);
    closeCatPanel();
    saveAndRender();
    buildMapGrid();
    flashSoundNote(t('sold_cat', { cat: catName(cat), price: refund }));
  } else if (action === 'open-languages') {
    renderLanguageOptions();
    openLanguages();
  } else if (action === 'select-language') {
    applyLanguage(button.dataset.language);
    closeLanguages();
  } else if (action === 'close-languages') {
    closeLanguages();
  } else if (action === 'close-cat') {
    closeCatPanel();
  } else if (action === 'close-modal') {
    closeModal();
  }
});

document.querySelector('#online-profile-form').addEventListener('change', event => {
  if (event.target.name !== 'avatar') return;
  document.querySelectorAll('.profile-avatar-choice').forEach(choice => {
    choice.classList.toggle('is-selected', choice.contains(event.target));
  });
});
document.querySelector('#online-username').addEventListener('input', event => event.currentTarget.setCustomValidity(''));
document.querySelector('#online-profile-form').addEventListener('submit', event => {
  event.preventDefault();
  if (gameState.playerLevel < 3) return;
  const form = event.currentTarget;
  const username = form.elements.username.value.trim().replace(/\s+/g, ' ');
  if (username.length < 2) {
    form.elements.username.setCustomValidity('Use at least 2 characters.');
    form.elements.username.reportValidity();
    return;
  }
  form.elements.username.setCustomValidity('');
  gameState.onlineProfile = { username: username.slice(0, 20), catType: CAT_CATALOG[form.elements.avatar.value] ? form.elements.avatar.value : 'rocky' };
  onlineProfileModal.hidden = true;
  saveAndRender();
  publishOnlinePresence();
  if (currentScreen === 'battle') openOnlineBattles();
});

musicToggle.addEventListener('change', () => {
  preferences.music = musicToggle.checked;
  localStorage.setItem('catdance-music', preferences.music ? 'on' : 'off');
  syncMusic();
  flashSoundNote(t(preferences.music ? 'music_on' : 'music_off'));
});
soundToggle.addEventListener('change', () => {
  preferences.sounds = soundToggle.checked;
  localStorage.setItem('catdance-sounds', preferences.sounds ? 'on' : 'off');
  if (preferences.sounds) playTone(660, .13, 'triangle');
  flashSoundNote(t(preferences.sounds ? 'sounds_on' : 'sounds_off'));
});
[settingsModal, warningModal, languageModal, farmModal, offlineReportModal].forEach(modal => modal.addEventListener('click', event => {
  if (event.target === modal) {
    if (modal === farmModal) closeFarm();
    else if (modal === offlineReportModal) { offlineReportModal.hidden = true; showNextLevelUp(); }
    else if (modal === languageModal) closeLanguages();
    else closeModal();
  }
}));
catPanel.addEventListener('click', event => { if (event.target === catPanel) closeCatPanel(); });
shopPanel.addEventListener('click', event => { if (event.target === shopPanel) closeShop(); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    if (!hatchMountainModal.hidden) { pendingHatchEggId = null; hatchMountainModal.hidden = true; }
    closeModal();
    closeLanguages();
    closeCatPanel();
    closeShop();
    closeFarm();
  }
});
window.addEventListener('resize', () => {
  if (currentScreen === 'mountain') buildMapGrid();
});
renderLanguageOptions();
applyLanguage(currentLanguage);
saveGame();
window.setInterval(produceSilver, 1000);
window.setInterval(hatchCompletedCubes, 1000);
window.addEventListener('load', connectAccountSave, { once: true });
