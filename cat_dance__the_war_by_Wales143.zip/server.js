export const schema = `
  CREATE TABLE IF NOT EXISTS catdance_saves (
    user_id TEXT PRIMARY KEY,
    save_json TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS catdance_online_players (
    user_id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    cat_type TEXT NOT NULL DEFAULT 'rocky',
    cat_level INTEGER NOT NULL DEFAULT 1,
    trophies INTEGER NOT NULL DEFAULT 100,
    seen_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS catdance_online_seen ON catdance_online_players(seen_at);
  CREATE TABLE IF NOT EXISTS catdance_online_rosters (
    user_id TEXT PRIMARY KEY,
    roster_json TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS catdance_battle_inbox (
    user_id TEXT PRIMARY KEY,
    trophies_delta INTEGER NOT NULL DEFAULT 0,
    battle_count INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS catdance_battle_xp_inbox (
    user_id TEXT PRIMARY KEY,
    xp_delta INTEGER NOT NULL DEFAULT 0
  );
`;

let battleInboxSchemaReady = false;
async function ensureBattleInboxSchema(DB) {
  if (battleInboxSchemaReady) return;
  try {
    await DB.prepare("ALTER TABLE catdance_battle_inbox ADD COLUMN battle_count INTEGER NOT NULL DEFAULT 0").run();
  } catch (error) {
    if (!String(error?.message || error).toLowerCase().includes("duplicate column name: battle_count")) throw error;
  }
  battleInboxSchemaReady = true;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const userId = request.headers.get("x-websim-user-id");
    if (url.pathname === "/api/online") {
      if (request.method === "GET") {
        const players = await env.DB.prepare(
          "SELECT user_id AS id, username, cat_type AS catType, cat_level AS level, trophies FROM catdance_online_players WHERE (? IS NULL OR user_id != ?) ORDER BY trophies DESC"
        ).bind(userId, userId).all();
        const self = userId ? await env.DB.prepare(
          "SELECT trophies FROM catdance_online_players WHERE user_id = ?"
        ).bind(userId).first() : null;
        const rosterRows = await env.DB.prepare("SELECT user_id, roster_json FROM catdance_online_rosters").all();
        const rosters = new Map((rosterRows.results || []).map(row => [row.user_id, row.roster_json]));
        const onlinePlayers = (players.results || []).map(player => {
          let roster = [];
          try { roster = JSON.parse(rosters.get(player.id) || "[]"); } catch {}
          return { ...player, roster };
        });
        onlinePlayers.sort((a, b) => b.trophies - a.trophies);
        return Response.json({ players: onlinePlayers, trophies: self?.trophies ?? null, signedIn: !!userId });
      }
      if (request.method === "POST") {
        if (!userId) return Response.json({ error: "Sign in to appear online" }, { status: 401 });
        let body;
        try { body = await request.json(); } catch { return Response.json({ error: "Invalid profile" }, { status: 400 }); }
        const username = String(body.username || request.headers.get("x-websim-username") || "Player").trim().slice(0, 20);
        const catType = ["smokire", "volcanic_lava", "floralis", "florestalis"].includes(body.catType) ? body.catType : "rocky";
        const catLevel = Number.isInteger(body.catLevel) ? Math.max(1, Math.min(100, body.catLevel)) : 1;
        const trophies = Number.isInteger(body.trophies) ? Math.max(0, Math.min(1000000, body.trophies)) : 100;
        await env.DB.prepare(
          "INSERT INTO catdance_online_players (user_id, username, cat_type, cat_level, trophies, seen_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, cat_type = excluded.cat_type, cat_level = excluded.cat_level, seen_at = excluded.seen_at"
        ).bind(userId, username, catType, catLevel, trophies, Date.now()).run();
        const roster = Array.isArray(body.roster) ? body.roster.slice(0, 2).map(cat => ({
          type: ["smokire", "volcanic_lava", "floralis", "florestalis"].includes(cat?.type) ? cat.type : "rocky",
          level: Number.isInteger(cat?.level) ? Math.max(1, Math.min(100, cat.level)) : 1
        })) : [];
        await env.DB.prepare("INSERT INTO catdance_online_rosters (user_id, roster_json) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET roster_json = excluded.roster_json")
          .bind(userId, JSON.stringify(roster)).run();
        return Response.json({ ok: true });
      }
      if (request.method === "PUT") {
        if (!userId) return Response.json({ error: "Sign in to record a battle" }, { status: 401 });
        await ensureBattleInboxSchema(env.DB);
        let body;
        try { body = await request.json(); } catch { return Response.json({ error: "Invalid result" }, { status: 400 }); }
        const opponentId = String(body.opponentId || "");
        const won = body.won === true;
        if (!opponentId || opponentId === userId) return Response.json({ error: "Invalid opponent" }, { status: 400 });
        const opponent = await env.DB.prepare("SELECT user_id, trophies FROM catdance_online_players WHERE user_id = ?").bind(opponentId).first();
        if (!opponent) return Response.json({ error: "Opponent is no longer online" }, { status: 409 });
        const own = await env.DB.prepare("SELECT trophies FROM catdance_online_players WHERE user_id = ?").bind(userId).first();
        const ownDelta = won ? 20 : -Math.min(own?.trophies ?? 100, 15);
        const opponentDelta = won ? -Math.min(opponent.trophies, 15) : 20;
        const statements = [
          env.DB.prepare("UPDATE catdance_online_players SET trophies = MAX(0, trophies + ?), seen_at = ? WHERE user_id = ?").bind(ownDelta, Date.now(), userId),
          env.DB.prepare("UPDATE catdance_online_players SET trophies = MAX(0, trophies + ?), seen_at = ? WHERE user_id = ?").bind(opponentDelta, Date.now(), opponentId),
          env.DB.prepare("INSERT INTO catdance_battle_inbox (user_id, trophies_delta, battle_count) VALUES (?, ?, 1) ON CONFLICT(user_id) DO UPDATE SET trophies_delta = trophies_delta + excluded.trophies_delta, battle_count = battle_count + 1").bind(opponentId, opponentDelta)
        ];
        if (!won) statements.push(env.DB.prepare("INSERT INTO catdance_battle_xp_inbox (user_id, xp_delta) VALUES (?, 400) ON CONFLICT(user_id) DO UPDATE SET xp_delta = xp_delta + excluded.xp_delta").bind(opponentId));
        await env.DB.batch(statements);
        const [self, updatedOpponent] = await Promise.all([
          env.DB.prepare("SELECT trophies FROM catdance_online_players WHERE user_id = ?").bind(userId).first(),
          env.DB.prepare("SELECT trophies FROM catdance_online_players WHERE user_id = ?").bind(opponentId).first()
        ]);
        return Response.json({ ok: true, trophies: self?.trophies ?? 100, opponentTrophies: updatedOpponent?.trophies ?? 0, opponentDelta });
      }
      return new Response("Method not allowed", { status: 405, headers: { Allow: "GET, POST, PUT" } });
    }

    if (url.pathname === "/api/online/claim" && request.method === "POST") {
      if (!userId) return Response.json({ delta: 0, trophies: 100 });
      await ensureBattleInboxSchema(env.DB);
      const row = await env.DB.prepare("SELECT trophies_delta, battle_count FROM catdance_battle_inbox WHERE user_id = ?").bind(userId).first();
      const xpRow = await env.DB.prepare("SELECT xp_delta FROM catdance_battle_xp_inbox WHERE user_id = ?").bind(userId).first();
      await env.DB.prepare("DELETE FROM catdance_battle_inbox WHERE user_id = ?").bind(userId).run();
      await env.DB.prepare("DELETE FROM catdance_battle_xp_inbox WHERE user_id = ?").bind(userId).run();
      const self = await env.DB.prepare("SELECT trophies FROM catdance_online_players WHERE user_id = ?").bind(userId).first();
      return Response.json({ delta: row?.trophies_delta || 0, battles: row?.battle_count || 0, xp: xpRow?.xp_delta || 0, trophies: self?.trophies ?? null });
    }

    if (url.pathname !== "/api/save") return new Response("Not found", { status: 404 });
    if (!userId) return Response.json({ error: "Sign in to save progress" }, { status: 401 });

    if (request.method === "GET") {
      const row = await env.DB.prepare(
        "SELECT save_json FROM catdance_saves WHERE user_id = ?"
      ).bind(userId).first();
      return Response.json({ save: row ? JSON.parse(row.save_json) : null });
    }

    if (request.method === "PUT") {
      let save;
      try { save = await request.json(); }
      catch { return Response.json({ error: "Invalid save data" }, { status: 400 }); }
      if (!save || typeof save !== "object" || Array.isArray(save)) {
        return Response.json({ error: "Invalid save data" }, { status: 400 });
      }
      const saveJson = JSON.stringify(save);
      if (saveJson.length > 100000) return Response.json({ error: "Save is too large" }, { status: 413 });
      await env.DB.prepare(
        "INSERT INTO catdance_saves (user_id, save_json, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP) " +
        "ON CONFLICT(user_id) DO UPDATE SET save_json = excluded.save_json, updated_at = CURRENT_TIMESTAMP"
      ).bind(userId, saveJson).run();
      return Response.json({ ok: true });
    }

    return new Response("Method not allowed", { status: 405, headers: { Allow: "GET, PUT" } });
  }
};
